#!/usr/bin/python
# -*- coding: utf8 -*-

import xbmc, xbmcgui, xbmcaddon, json, time, xbmcvfs
from urllib.request import urlopen


LABEL_TEXT_1 = 101
LABEL_TEXT_2 = 102
LABEL_TEXT_3 = 103
LABEL_TEXT_4 = 104
LABEL_TEXT_5 = 105
LABEL_TEXT_6 = 106
LABEL_TEXT_7 = 107
BANNER = 301
LOADING = 302
LOGO = 303
ALBUM = 304
COVER = 305
FOTO = 306
CANCEL_DIALOG      = ( 9, 10, 92, 216, 247, 257, 275, 61467, 61448, )
ACTION_SELECT_ITEM = 7
ACTION_MOUSE_START = 100
SELECT_ITEM = (ACTION_SELECT_ITEM, ACTION_MOUSE_START)


__addon__           = xbmcaddon.Addon()
__addon_id__        = __addon__.getAddonInfo('id')
__addonpath__       = xbmcvfs.translatePath(__addon__.getAddonInfo('path'))


class Radio(xbmcgui.WindowXMLDialog):
    
    def __init__(self, xml, cwd, default):
        xbmcgui.WindowXMLDialog.__init__(self)


    def onInit(self):
        self.setup_all()


    def onAction(self, action):
        if (action.getId() in CANCEL_DIALOG):
            self.player.stop()
            self.close()
    
    
    def setup_all(self):
        self.timestamp = int(time.time())
        if __addon__.getSetting("skin") == "2":
            xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
        else:
            self.getControl(BANNER).setVisible(False)
        stream = "https://ice.actve.net/fm-evropa2-128"
        listitem = xbmcgui.ListItem(label = "Evropa 2", path=stream)
        listitem.setInfo("Music", infoLabels={"Title": "Evropa 2"})
        self.player = xbmc.Player()
        self.player.play(stream, listitem, windowed = True)
        time.sleep(7)
        if __addon__.getSetting("skin") != "2":
            self.getControl(LOADING).setVisible(False)
            self.getControl(BANNER).setVisible(True)
        else:
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        self.getControl(LOGO).setVisible(False)
        self.getControl(ALBUM).setImage("album.jpg")
        self.reload()


    def reload(self):
        monitor = xbmc.Monitor()
        while self.player.isPlayingAudio():
            if __addon__.getSetting("skin") != "2":
                self.getControl(LABEL_TEXT_6).setLabel(xbmc.getInfoLabel('System.Date()'))
                self.getControl(LABEL_TEXT_5).setLabel(xbmc.getInfoLabel('System.Time()'))
            if self.timestamp <= int(time.time()):
                self.load_data()
            monitor.waitForAbort(2)


    def load_data(self):
        url = urlopen("https://rds.actve.net/v1/metadata/channel/evropa2?coverSize=360").read()
        data = json.loads(url)
        if data["status"] == "ok":
            img = data["cover"]
            cover = self.getControl(COVER)
            title = self.getControl(LABEL_TEXT_1)
            artist = self.getControl(LABEL_TEXT_2)
            show = self.getControl(LABEL_TEXT_3)
            moderator = self.getControl(LABEL_TEXT_4)
            cover.setImage(img)
            title.setLabel(data["title"])
            album = data["album"]
            if album != "":
                artist.setLabel(data["artist"] + " - " + album)
            else:
                artist.setLabel(data["artist"])
            show.setLabel(data["showName"] + " (" + data["showStart"] + " - " + data["showEnd"] + ")")
            moderator.setLabel(data["moderatorName"])
            if __addon__.getSetting("skin") == "1":
                playlist = self.getControl(LABEL_TEXT_7)
                playlist_list = []
                for x in data["history"][1:7]:
                    playlist_list.append("[B]" + x["songStart"][-8:-3] + "[/B]  " + x["songTitle"] + " - " + x["songArtist"])
                text_playlist = "        ".join(playlist_list)
                playlist.setLabel(text_playlist)
                img2 = data["moderatorMotiveURL"]
                if "mod-bot" not in img2:
                    self.getControl(FOTO).setVisible(True)
                    foto = self.getControl(FOTO)
                    foto.setImage(img2)
                else:
                    self.getControl(FOTO).setVisible(False)
            self.timestamp = data["starttime"] + data["duration"]


