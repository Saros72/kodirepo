#!/usr/bin/python
# -*- coding: utf8 -*-

import resources.lib.evropa2 as evropa2
import xbmcaddon

__addon__           = xbmcaddon.Addon()
__addon_id__        = __addon__.getAddonInfo('id')
__addonpath__       = xbmc.translatePath(__addon__.getAddonInfo('path'))
if __addon__.getSetting("skin") == "0":
    ui = evropa2.Radio("default.xml", __addonpath__, "default")
    ui.doModal()
    del ui
elif __addon__.getSetting("skin") == "1":
    ui = evropa2.Radio("evropa_2.xml", __addonpath__, "default")
    ui.doModal()
    del ui
elif __addon__.getSetting("skin") == "2":
    ui = evropa2.Radio("windows.xml", __addonpath__, "default")
    ui.doModal()
    del ui
else:
    import resources.lib.default_player as default_player
    default_player.run()
