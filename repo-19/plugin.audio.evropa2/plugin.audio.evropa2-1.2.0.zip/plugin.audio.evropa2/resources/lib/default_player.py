# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
from urllib.request import urlopen
import os, json, time, sys


fanart = os.path.join(xbmc.translatePath('special://home/addons/plugin.audio.evropa2'),'fanart.jpg')


def get_info():
    url = urlopen("https://rds.actve.net/v1/metadata/channel/evropa2?coverSize=320").read()
    data = json.loads(url)
    if data["status"] == "ok":
        thumb = data["cover"]
        song = data["title"]
        artist = data["artist"]
        album = data["album"]
        timestamp = data["starttime"] + data["duration"]
        duration = data["duration"]
        comment = data["showName"]
        return artist,song,thumb,timestamp,duration,album, comment


class Radio:

    def PlayRadio(self):
        self.timestamp = int(time.time())
        listitem = xbmcgui.ListItem()
        stream="https://ice.actve.net/fm-evropa2-128"
        player = xbmc.Player()
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), False , listitem=listitem)
        artist,song,thumb,timestamp,duration,album,comment = get_info()
        listitem.setInfo("music", {"title": song, "artist": artist, "album": album, "comment": comment})
        listitem.setArt({"thumb": thumb, "fanart": fanart})
        player.play(stream, listitem, windowed = True)
        xbmc.Monitor().waitForAbort(8)
        xbmc.executebuiltin("ActivateWindow(home)")
        while not xbmc.Monitor().abortRequested() and player.isPlayingAudio():
            try:
                if self.timestamp <= int(time.time()):
                    artist,song,thumb,timestamp,duration,album, comment = get_info()
                    listitem.setInfo("music", {"title": song, "artist": artist, "album": album, "comment": comment})
                    listitem.setArt({"thumb": thumb, "fanart": fanart})
                    player.updateInfoTag(listitem)
                    self.timestamp = timestamp
                else:
                    listitem.setInfo("music", {"title": song, "artist": artist, "album": album, "comment": comment})
                    listitem.setArt({"thumb": thumb, "fanart": fanart})
                    player.updateInfoTag(listitem)
            except:
                pass
            xbmc.Monitor().waitForAbort(4)


def run():
    r = Radio()
    r.PlayRadio()