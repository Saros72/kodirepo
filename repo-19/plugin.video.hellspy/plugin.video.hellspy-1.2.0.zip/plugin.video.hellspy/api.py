# -*- coding: utf-8 -*-

API_KEY = '1f0150a5f78d4adc2407911989fdb66c'

BASE_URL = 'https://api.themoviedb.org/3'

LANG = 'cs-CZ'

HEADERS = {
  'User-Agent': "Mozilla/5.0 (Linux; Android 15; Mi A3 Build/AP4A.250105.002) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.6778.200 Mobile Safari/537.36",
  'Accept-Encoding': "gzip, deflate, br, zstd",
  'sec-ch-ua-platform': "\"Android\"",
  'sec-ch-ua': "\"Android WebView\";v=\"131\", \"Chromium\";v=\"131\", \"Not_A Brand\";v=\"24\"",
  'sec-ch-ua-mobile': "?1",
  'origin': "https://www.hellspy.to",
  'x-requested-with': "org.lineageos.jelly",
  'sec-fetch-site': "same-site",
  'sec-fetch-mode': "cors",
  'sec-fetch-dest': "empty",
  'referer': "https://www.hellspy.to/",
  'accept-language': "cs-CZ,cs;q=0.9,en-US;q=0.8,en;q=0.7",
  'priority': "u=1, i"
}

GENRE_DICT = {
    28: "Akční", 12: "Dobrodružný", 16: "Animovaný", 35: "Komedie",
    80: "Krimi", 99: "Dokument", 18: "Drama", 10751: "Rodinný",
    14: "Fantasy", 36: "Historický", 27: "Horor", 10402: "Hudební",
    9648: "Mysteriózní", 10749: "Romantický", 878: "Sci-Fi", 10770: "TV film",
    53: "Thriller", 10752: "Válečný", 37: "Western",
    # Seriálové specifické
    10759: "Akční & Dobrodružný", 10762: "Dětský", 10763: "Zpravodajství",
    10764: "Reality-TV", 10765: "Sci-Fi & Fantasy", 10766: "Telenovela",
    10767: "Talk-show", 10768: "Válečný & Politika"
}