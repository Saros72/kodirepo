# -*- coding: utf-8 -*-


import routing
import xbmcgui
import xbmc
import xbmcaddon
import os
import xbmcvfs
import requests
import traceback
from xbmcgui import ListItem, Dialog
from xbmcplugin import addDirectoryItem, endOfDirectory, setResolvedUrl, setContent
from urllib.parse import quote, unquote
from api import *


addon = xbmcaddon.Addon()
plugin = routing.Plugin()
icon_path = addon.getAddonInfo('icon')
history_path = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
try:
    history_path = history_path.decode("utf-8")
except:
    pass
history_file = os.path.join(history_path, "history.txt")


def save_history(q):
    try:
        if not os.path.exists(history_path):
            os.makedirs(history_path)
    except Exception as e:
        traceback.print_exc()
    if os.path.exists(history_file):
        lh = open(history_file, "r").read().splitlines()
        if q not in lh:
            if len(lh) == 20:
                del lh[-1]
            lh.insert(0, q)
            f = open(history_file, "w")
            for item in lh:
                f.write("%s\n" % item)
            f.close()
    else:
        f = open(history_file, "w")
        f.write(q)
        f.close()


def get_stream(video_id, video_hash):
    stream = None
    try:
        response = requests.get("https://api.hellspy.to/gw/video/" + video_id + "/" + video_hash + "/download", headers=HEADERS, allow_redirects=False)
        if response.status_code in (301, 302, 303, 307, 308):
            stream = response.headers.get("Location")
    except:
        pass
    return stream


def video_list(query):
    try:
        data = requests.get("https://api.hellspy.to/gw/search?query=" + quote(query) + "&offset=0&limit=50", headers=HEADERS).json()
        if data != []:
            return data
        else:
            return []
    except:
        return []


def format_size(size_bytes):
    for unit in ['B', 'kB', 'MB', 'GB', 'TB']:
        if size_bytes < 1024:
            return f"{size_bytes:.2f} {unit}"
        size_bytes /= 1024
    return f"{size_bytes:.2f} PB"


@plugin.route('/play_video/<video_title>/<video_id>/<video_hash>')
def play_video(video_title, video_id, video_hash):
    stream = get_stream(video_id, video_hash)
    listItem = ListItem(video_title, path=stream)   
    setResolvedUrl(plugin.handle, True, listItem)


@plugin.route("/history")
def history():
    name_list = []
    if os.path.exists(history_file):
        name_list = open(history_file, "r", encoding="utf-8").read().splitlines()
    for video_name in name_list:
        li = ListItem(label=video_name)
        li.setArt({'icon': 'special://home/addons/plugin.video.hellspy/img/history.png'})
        addDirectoryItem(plugin.handle, plugin.url_for(search_video, video_name, "0"), li, True)
    endOfDirectory(plugin.handle)


@plugin.route("/search_video/<query>/<updL>")
def search_video(query, updL):
    data = video_list(query)

    # Seřadit výsledky podle velikosti souboru (od největšího)
    items = sorted(data.get("items", []), key=lambda x: x.get("size", 0), reverse=True)

    for item in items:
        title = item.get("title", "Neznámý název")
        size = format_size(item.get("size", 0))
        video_name = f"{title} ({size})"
        video_id = item.get("id", "0")
        video_hash = item.get("fileHash", "0")

        li = ListItem(label=video_name)
        infotag = li.getVideoInfoTag()
        infotag.setDuration(item.get("duration", 0))
        li.setProperty('IsPlayable', 'true')
        li.setArt({
            'icon': icon_path,
            'thumb': icon_path
        })

        addDirectoryItem(
            plugin.handle,
            plugin.url_for(play_video, video_name, video_id, video_hash),
            li,
            False
        )

    endOfDirectory(plugin.handle, updateListing=int(updL))


@plugin.route("/ask/<inp>/<updL>")
def ask(inp, updL):
    query = Dialog().input("Zadejte název filmu nebo seriálu", defaultt = inp.replace("**inp**", ""))
    if not query:
        return
    save_history(query)
    endOfDirectory(plugin.handle)
    xbmc.executebuiltin('Container.Update(%s)' % plugin.url_for(search_video, query, updL))


def create_listitem(data, label, poster_override=None, fanart_override=None):
    li = ListItem(label)

    is_episode = 'episode_number' in data
    is_tvshow = 'first_air_date' in data
    is_movie = 'release_date' in data

    if is_episode:
        title = data.get('name', label)
        original_title = title
        year = (data.get('air_date') or '0000')[:4]
        overview = data.get('overview', '')
        rating = float(data.get('vote_average', 0.0))
        votes = int(data.get('vote_count', 0))
        poster_path = data.get('still_path')
        poster = poster_override or (f"https://image.tmdb.org/t/p/w500{poster_path}" if poster_path else '')
        fanart = fanart_override or poster

        genre_str = ''
        tvshow = label.split(' s')[0]
        season = data.get('season_number')
        episode = data.get('episode_number')

        li.setInfo('video', {
            'title': title,
            'tvshowtitle': tvshow,
            'season': season,
            'episode': episode,
            'episodename': title,
            'genre': genre_str,
            'year': int(year),
            'plot': overview,
            'rating': rating,
            'votes': votes,
            'mediatype': 'episode'
        })

    elif is_movie:
        title = data.get('title', label)
        original_title = data.get('original_title', title)
        year = (data.get('release_date') or '0000')[:4]
        overview = data.get('overview', '')
        rating = float(data.get('vote_average', 0.0))
        votes = int(data.get('vote_count', 0))
        poster_path = data.get('poster_path')
        fanart_path = data.get('backdrop_path')
        poster = f"https://image.tmdb.org/t/p/w500{poster_path}" if poster_path else ''
        fanart = f"https://image.tmdb.org/t/p/w1280{fanart_path}" if fanart_path else ''
        genre_ids = data.get('genre_ids', [])
        genre_names = [GENRE_DICT.get(gid, '') for gid in genre_ids]
        genre_str = ' / '.join(filter(None, genre_names))

        li.setInfo('video', {
            'title': title,
            'originaltitle': original_title,
            'genre': genre_str,
            'year': int(year),
            'plot': overview,
            'rating': rating,
            'votes': votes,
            'mediatype': 'movie'
        })

    elif is_tvshow:
        title = data.get('name', label)
        original_title = data.get('original_name', title)
        year = (data.get('first_air_date') or '0000')[:4]
        overview = data.get('overview', '')
        rating = float(data.get('vote_average', 0.0))
        votes = int(data.get('vote_count', 0))
        poster_path = data.get('poster_path')
        fanart_path = data.get('backdrop_path')
        poster = f"https://image.tmdb.org/t/p/w500{poster_path}" if poster_path else ''
        fanart = f"https://image.tmdb.org/t/p/w1280{fanart_path}" if fanart_path else ''
        genre_ids = data.get('genre_ids', [])
        genre_names = [GENRE_DICT.get(gid, '') for gid in genre_ids]
        genre_str = ' / '.join(filter(None, genre_names))

        li.setInfo('video', {
            'title': title,
            'originaltitle': original_title,
            'genre': genre_str,
            'year': int(year),
            'plot': overview,
            'rating': rating,
            'votes': votes,
            'mediatype': 'tvshow'
        })

    else:
        li.setInfo('video', {'title': label})

    li.setArt({
        'thumb': poster,
        'icon': poster,
        'poster': poster,
        'fanart': fanart
    })

    return li


@plugin.route('/tmdb_search/<media_type>/')
def tmdb_search(media_type):
    mt = {"movie": "filmu", "tv": "seriálu"}
    query = Dialog().input("Zadejte název " + mt[media_type])
    if not query:
        return
    url = f"{BASE_URL}/search/{media_type}?api_key={API_KEY}&language={LANG}&query={quote(query)}"
    results = requests.get(url).json().get('results', [])
    for item in results:
        title = item.get('title') or item.get('name')
        li = create_listitem(item, title)
        if media_type == 'tv':
            url = plugin.url_for(show_seasons, tv_id=item['id'], name=title)
            cm_items = [(
            'Hledat',
            f'RunPlugin({plugin.url_for(ask, inp=title, updL="0")})'
        )]
            li.addContextMenuItems(cm_items)
            addDirectoryItem(plugin.handle, url, li, True)
        else:
            cm_items = [(
            'Hledat',
            f'RunPlugin({plugin.url_for(ask, inp=title, updL="0")})'
        )]
            li.addContextMenuItems(cm_items)
            addDirectoryItem(plugin.handle, plugin.url_for(search_video, title, "0"), li, True)

    if media_type == 'tv':
        setContent(plugin.handle, 'tvshows')
    else:
        setContent(plugin.handle, 'movies')

    endOfDirectory(plugin.handle)

    if addon.getSetting("modview") == "true":
        try:
            xbmc.executebuiltin("Container.SetViewMode(%s)" % addon.getSetting('modview_id'))
        except:
            pass


@plugin.route('/list/<media_type>/<category>/')
@plugin.route('/list/<media_type>/<category>/<page>/')
def tmdb_list_items(media_type, category, page='1'):
    url = f"{BASE_URL}/{media_type}/{category}?api_key={API_KEY}&language={LANG}&page={page}"
    data = requests.get(url).json()
    for item in data.get('results', []):
        title = item.get('title') or item.get('name')
        if media_type == "movie":
            year = item.get("release_date", "")[:4]
            search_title = f"{title} {year}" if year else title
        else:
            search_title = title
        li = create_listitem(item, title)
        if media_type == 'tv':
            url = plugin.url_for(show_seasons, tv_id=item['id'], name=title)
            cm_items = [(
            'Hledat',
            f'RunPlugin({plugin.url_for(ask, inp=title, updL="0")})'
        )]
            li.addContextMenuItems(cm_items)
            addDirectoryItem(plugin.handle, url, li, True)
        else:
            cm_items = [(
            'Hledat',
            f'RunPlugin({plugin.url_for(ask, inp=title, updL="0")})'
        )]
            li.addContextMenuItems(cm_items)
            addDirectoryItem(plugin.handle, plugin.url_for(search_video, search_title, "0"), li, True)

    if media_type == 'tv':
        setContent(plugin.handle, 'tvshows')
    else:
        setContent(plugin.handle, 'movies')

    if int(page) < data.get('total_pages', 1):
        next_page = int(page) + 1
        li = ListItem("Další strana")
        addDirectoryItem(plugin.handle, plugin.url_for(tmdb_list_items, media_type=media_type, category=category, page=str(next_page)), li, True)
    endOfDirectory(plugin.handle)

    if addon.getSetting("modview") == "true":
        try:
            xbmc.executebuiltin("Container.SetViewMode(%s)" % addon.getSetting('modview_id'))
        except:
            pass


@plugin.route('/genres/<media_type>/')
def genres(media_type):
    url = f"{BASE_URL}/genre/{media_type}/list?api_key={API_KEY}&language={LANG}"
    genres = requests.get(url).json().get('genres', [])
    for genre in genres:
        li = ListItem(genre['name'])
        url = plugin.url_for(filter_by_genre, media_type=media_type, genre_id=str(genre['id']))
        addDirectoryItem(plugin.handle, url, li, True)
    endOfDirectory(plugin.handle)


@plugin.route('/filter/<media_type>/genre/<genre_id>/')
@plugin.route('/filter/<media_type>/genre/<genre_id>/<page>/')
def filter_by_genre(media_type, genre_id, page='1'):
    url = f"{BASE_URL}/discover/{media_type}?api_key={API_KEY}&language={LANG}&sort_by=popularity.desc&with_genres={genre_id}&page={page}"
    data = requests.get(url).json()
    for item in data.get('results', []):
        title = item.get('title') or item.get('name')
        if media_type == "movie":
            year = item.get("release_date", "")[:4]
            search_title = f"{title} {year}" if year else title
        else:
            search_title = title
        li = create_listitem(item, title)
        if media_type == 'tv':
            cm_items = [(
            'Hledat',
            f'RunPlugin({plugin.url_for(ask, inp=title, updL="0")})'
        )]
            li.addContextMenuItems(cm_items)
            url = plugin.url_for(show_seasons, tv_id=item['id'], name=title)
            addDirectoryItem(plugin.handle, url, li, True)
        else:
            cm_items = [(
            'Hledat',
            f'RunPlugin({plugin.url_for(ask, inp=title, updL="0")})'
        )]
            li.addContextMenuItems(cm_items)
            addDirectoryItem(plugin.handle, plugin.url_for(search_video, search_title, "0"), li, True)

    if media_type == 'tv':
        setContent(plugin.handle, 'tvshows')
    else:
        setContent(plugin.handle, 'movies')

    if int(page) < data.get('total_pages', 1):
        next_page = int(page) + 1
        li = ListItem("Další strana")
        addDirectoryItem(plugin.handle, plugin.url_for(filter_by_genre, media_type=media_type, genre_id=genre_id, page=str(next_page)), li, True)
    endOfDirectory(plugin.handle)

    if addon.getSetting("modview") == "true":
        try:
            xbmc.executebuiltin("Container.SetViewMode(%s)" % addon.getSetting('modview_id'))
        except:
            pass


@plugin.route('/tv/show/<tv_id>/<name>/')
def show_seasons(tv_id, name):
    url = f"{BASE_URL}/tv/{tv_id}?api_key={API_KEY}&language={LANG}"
    data = requests.get(url).json()
    fanart_path = data.get('backdrop_path')
    fanart = f"https://image.tmdb.org/t/p/w1280{fanart_path}" if fanart_path else ''

    for season in data.get('seasons', []):
        if season['season_number'] == 0:
            continue

        season_number = season['season_number']
        li = ListItem(season['name'])

        poster_path = season.get('poster_path')
        poster = f"https://image.tmdb.org/t/p/w500{poster_path}" if poster_path else ''

        li.setArt({
            'thumb': poster,
            'icon': poster,
            'poster': poster,
            'fanart': fanart
        })

        url = plugin.url_for(show_episodes, tv_id=tv_id, season_number=season_number, series_name=name)
        addDirectoryItem(plugin.handle, url, li, True)

    endOfDirectory(plugin.handle)


@plugin.route('/tv/<tv_id>/season/<season_number>/<series_name>/')
def show_episodes(tv_id, season_number, series_name):
    url = f"{BASE_URL}/tv/{tv_id}/season/{season_number}?api_key={API_KEY}&language={LANG}"
    data = requests.get(url).json()
    poster_path = data.get('poster_path')
    poster = f"https://image.tmdb.org/t/p/w500{poster_path}" if poster_path else ''

    fanart_path = data.get('backdrop_path') or ''
    fanart = f"https://image.tmdb.org/t/p/w1280{fanart_path}" if fanart_path else ''

    for ep in data.get('episodes', []):
        s = int(season_number)
        e = ep['episode_number']
        title = f"{series_name} s{s:02}e{e:02} - {ep['name']}"
        li = create_listitem(ep, title, poster_override=poster, fanart_override=fanart)
        cm_items = [(
            'Hledat episodu',
            f'RunPlugin({plugin.url_for(ask, inp=f"{series_name} s{s:02}e{e:02}", updL="0")})'
        )]
        li.addContextMenuItems(cm_items)
        addDirectoryItem(plugin.handle, plugin.url_for(search_video, f"{series_name} s{s:02}e{e:02}", "0"), li, True)

    setContent(plugin.handle, 'episodes')

    endOfDirectory(plugin.handle)

    if addon.getSetting("modview") == "true":
        try:
            xbmc.executebuiltin("Container.SetViewMode(%s)" % addon.getSetting('modview_id'))
        except:
            pass


@plugin.route('/tmdb_menu/<media_type>/')
def tmdb_menu(media_type):

    # Jedna ikona podle typu média
    if media_type == "movie":
        art_icon = "special://home/addons/plugin.video.hellspy/img/movies.png"
    else:
        art_icon = "special://home/addons/plugin.video.hellspy/img/series.png"

    # --- HLEDAT ---
    li = ListItem("Hledat na TMDb")
    li.setArt({"icon": art_icon, "thumb": art_icon})
    addDirectoryItem(plugin.handle, plugin.url_for(tmdb_search, media_type=media_type), li, True)

    # --- TOP RATED ---
    li = ListItem("Nejlépe hodnocené")
    li.setArt({"icon": art_icon, "thumb": art_icon})
    addDirectoryItem(plugin.handle, plugin.url_for(tmdb_list_items, media_type=media_type, category='top_rated'), li, True)

    # --- POPULAR ---
    li = ListItem("Populární")
    li.setArt({"icon": art_icon, "thumb": art_icon})
    addDirectoryItem(plugin.handle, plugin.url_for(tmdb_list_items, media_type=media_type, category='popular'), li, True)

    # --- NOVINKY ---
    li = ListItem("Novinky")
    li.setArt({"icon": art_icon, "thumb": art_icon})
    addDirectoryItem(
        plugin.handle,
        plugin.url_for(
            tmdb_list_items,
            media_type=media_type,
            category="now_playing" if media_type == "movie" else "on_the_air"
        ),
        li,
        True
    )

    # --- ŽÁNRY ---
    li = ListItem("Žánry")
    li.setArt({"icon": art_icon, "thumb": art_icon})
    addDirectoryItem(plugin.handle, plugin.url_for(genres, media_type=media_type), li, True)

    endOfDirectory(plugin.handle)


@plugin.route('/')
def index():
    items = [
        ("Hledat na Hellspy", plugin.url_for(ask, inp = '**inp**', updL='1'), "special://home/addons/plugin.video.hellspy/img/search.png"),
        ("Historie hledání", plugin.url_for(history), "special://home/addons/plugin.video.hellspy/img/history.png"),
        ("TMDb - Filmy", plugin.url_for(tmdb_menu, media_type='movie'), "special://home/addons/plugin.video.hellspy/img/movies.png"),
        ("TMDb - Seriály", plugin.url_for(tmdb_menu, media_type='tv'), "special://home/addons/plugin.video.hellspy/img/series.png")
    ]

    for label, url, icon_file in items:
        li = ListItem(label)
        li.setArt({
            'icon': icon_file,
            'thumb': icon_file
        })
        addDirectoryItem(plugin.handle, url, li, True)

    endOfDirectory(plugin.handle)


if __name__ == '__main__':
    plugin.run()