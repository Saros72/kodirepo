#-*-coding:utf8;-*-

import requests, xbmcaddon, xbmcgui, json, os, xbmcvfs
from datetime import datetime


addon = xbmcaddon.Addon(id='service.iptv.web.server')
channels = {}
headers = {"User-Agent": "okhttp/3.12.12"}
pin = addon.getSetting("poda_pin")
kd = {"0": "h265", "1": "h264"}
if addon.getSetting("poda_adaptive") == "true":
    adaptive = "%2Cvast%2Cclientvast%2Cadaptive2%2Cwebvtt"
else:
    adaptive = "%2Cvast%2Cclientvast%2Cwebvtt"
profile = xbmcvfs.translatePath(addon.getAddonInfo('profile')).encode().decode("utf-8")
poda_data = os.path.join(profile, "poda_data.json")
try:
    with open(poda_data, 'r') as openfile:
        data = json.load(openfile)
    deviceId = data["deviceId"]
    passwordId = data["password"]
except:
    deviceId = ""
    passwordId = ""


def get_sessid():
    phpsessid = ""
    req = requests.get("https://poda.moderntv.eu/api/device-login?deviceId=" + str(deviceId) + "&password=" + str(passwordId) + "&version=2.44.16&lang=cs&unit=default&capabilities=" + adaptive, headers = headers).json()
    if req["status"] == 1:
        phpsessid = req["PHPSESSID"]
        requests.get("https://poda.moderntv.eu/api/pin-unlock?pin=" + str(pin) + "&PHPSESSID=" + phpsessid, headers = headers).json()
    return phpsessid


sessid = get_sessid()
if sessid != "":
    req = requests.get("https://poda.moderntv.eu/api/get-stream-qualities?PHPSESSID=" + sessid).json()
    q = []
    for x in req["qualities"]:
        if x["allowed"] == 1:
            q.append(x["id"])
    q.sort()
    quality = str(q[-1])
    req = requests.get("https://poda.moderntv.eu/api/playlist?quality=" + quality + "&capabilities=" + kd[addon.getSetting("poda_codec")] + adaptive + "&force=true&format=m3u8&type=&logosize=96&whitelogo=true&drm=&subtitles=1&PHPSESSID=" + sessid, headers = headers).json()
    if req["status"] == 1:
        groups = req["groups"]
        for d in req["channels"]:
            if d["locked"] == "none":
                url = d["url"]
                channels[d["id"]] = {"name": d["name"], "url": d["url"], "logo": d["logoUrl"], "type": d["type"], "group": groups[d["group"]]}


def get_catchup(id, utc, utcend):
    id = id.split(".")[0]
    date_time_start = datetime.fromtimestamp(int(utc) + 1)
    d_start = date_time_start.strftime("%Y-%m-%d+%H:%M:%S")
    url =  "http://sledovanietv.sk/download/noAccess-cs.m3u8"
    sessid = get_sessid()
    if sessid != "":
        req = requests.get("https://poda.moderntv.eu/api/epg?time=" + d_start + "&duration=0&detail=0&channels=" + id + "&PHPSESSID=" + sessid, headers = headers).json()
        if req["status"] == 1:
            eventId = req["channels"][id][0]["eventId"]
            req = requests.get("https://poda.moderntv.eu/api/get-stream-qualities?PHPSESSID=" + sessid).json()
            q = []
            for x in req["qualities"]:
                if x["allowed"] == 1:
                    q.append(x["id"])
            q.sort()
            quality = str(q[-1])
            req = requests.get("https://poda.moderntv.eu/api/event-timeshift?format=m3u8&quality=" + quality + "&capabilities=" + kd[addon.getSetting("poda_codec")] + adaptive + "&force=true&eventId=" + eventId + "&overrun=1&PHPSESSID=" + sessid, headers = headers).json()
            if req["status"] == 1:
                url = req["url"]
    return url
