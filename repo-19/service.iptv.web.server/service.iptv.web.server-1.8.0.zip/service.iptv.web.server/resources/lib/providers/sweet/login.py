#-*-coding:utf8;-*-

import requests, xbmcaddon, xbmcgui, os, xbmcvfs, xbmc, json, uuid


icon = os.path.join(xbmcvfs.translatePath('special://home/addons/service.iptv.web.server'),'resources', 'lib', 'providers', 'sweet', 'icon.jpeg')
addon = xbmcaddon.Addon()
email = addon.getSetting("sweet_username")
password = addon.getSetting("sweet_password")
profile = xbmcvfs.translatePath(addon.getAddonInfo('profile')).encode().decode("utf-8")
sweet_channels = os.path.join(profile, "sweet_channels.json")
sweet_token = os.path.join(profile, "sweet_token.json")
addon_dir = xbmcvfs.translatePath( addon.getAddonInfo('path') )
addon_icon = os.path.join(addon_dir, "icon.png")
UUID = str(uuid.uuid4())
UA ='Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:105.0) Gecko/20100101 Firefox/105.0'


def main():
    channels = {}
    headers = {'Host': 'api.sweet.tv', 'user-agent': UA, 'accept': 'application/json, text/plain, */*', 'accept-language': 'pl', 'x-device': '1;22;0;2;3.2.57', 'origin': 'https://sweet.tv', 'dnt': '1', 'referer': 'https://sweet.tv/'}
    data = {'device': {'type': 'DT_Web_Browser', 'application': {'type': 'AT_SWEET_TV_Player'}, 'model': UA, 'firmware': {'versionCode': 1, 'versionString': '3.2.57'}, 'uuid': UUID, 'supported_drm': {'widevine_modular': True}, 'screen_info': {'aspectRatio': 6, 'width': 1366, 'height': 768}}, 'email': email, 'password': password}
    req = requests.post("https://api.sweet.tv/SigninService/Email.json", json = data, headers = headers).json()
    if req["result"] == "OK":
        req["UUID"] = UUID
        json_object = json.dumps(req, indent=4)
        with open(sweet_token, "w") as outfile:
            outfile.write(json_object)
        headers["authorization"] = "Bearer " + req["access_token"]
        data = {'need_epg': False, 'need_list': True, 'need_categories': False, 'need_offsets': False, 'need_hash': False, 'need_icons': False, 'need_big_icons': False,}
        req = requests.post("https://api.sweet.tv/TvService/GetChannels.json", json = data, headers = headers).json()
        if req["status"] == "OK":
            for ch in req["list"]:
                channels[str(ch["id"])] = {"name": ch["name"].replace(" HD", ""), "logo": ch["icon_url"]}
            json_object = json.dumps(channels, indent=4)
            with open(sweet_channels, "w") as outfile:
                outfile.write(json_object)
            xbmcgui.Dialog().notification("Sweet TV", "Přihlášení úspěšné", icon = icon)
            xbmc.sleep(4000)
            xbmcgui.Dialog().notification("IPTV Web Server", "Restartujte KODI", icon = addon_icon)
        else:
            xbmcgui.Dialog().notification("Sweet TV", req["result"], icon = icon)
    else:
        xbmcgui.Dialog().notification("Sweet TV", req["result"], icon = icon)


if __name__ == "__main__":
    main()