#-*-coding:utf8;-*-

import requests, xbmcaddon, xbmcgui, json, os, xbmcvfs
from datetime import datetime


addon = xbmcaddon.Addon(id='service.iptv.web.server')
icon = os.path.join(xbmcvfs.translatePath('special://home/addons/service.iptv.web.server'),'resources', 'lib', 'providers', 'poda', 'icon.png')
channels = {}
headers = {"User-Agent": "okhttp/3.12.12"}
pin = addon.getSetting("poda_pin")
kd = {"0": "h265", "1": "h264"}
if addon.getSetting("poda_adaptive") == "true":
    adaptive = "%2Cvast%2Cclientvast%2Cadaptive2%2Cwebvtt"
else:
    adaptive = "%2Cvast%2Cclientvast%2Cwebvtt"
profile = xbmcvfs.translatePath(addon.getAddonInfo('profile')).encode().decode("utf-8")
poda_data = os.path.join(profile, "poda_data.json")
try:
    with open(poda_data, 'r') as openfile:
        data = json.load(openfile)
    deviceId = data["deviceId"]
    passwordId = data["password"]
except:
    deviceId = ""
    passwordId = ""


def get_sessid():
    phpsessid = ""
    req = requests.get("https://poda.moderntv.eu/api/device-login?deviceId=" + str(deviceId) + "&password=" + str(passwordId) + "&version=2.44.16&lang=cs&unit=default&capabilities=" + adaptive, headers = headers).json()
    if req["status"] == 1:
        phpsessid = req["PHPSESSID"]
        requests.get("https://poda.moderntv.eu/api/pin-unlock?pin=" + str(pin) + "&PHPSESSID=" + phpsessid, headers = headers).json()
    return phpsessid


sessid = get_sessid()
if sessid != "":
    req = requests.get("https://poda.moderntv.eu/api/get-stream-qualities?PHPSESSID=" + sessid).json()
    q = []
    for x in req["qualities"]:
        if x["allowed"] == 1:
            q.append(x["id"])
    q.sort()
    quality = str(q[-1])
    req = requests.get("https://poda.moderntv.eu/api/playlist?quality=" + quality + "&capabilities=" + kd[addon.getSetting("poda_codec")] + adaptive + "&force=true&format=m3u8&type=&logosize=96&whitelogo=true&drm=&subtitles=1&PHPSESSID=" + sessid, headers = headers).json()
    if req["status"] == 1:
        groups = req["groups"]
        for d in req["channels"]:
            if d["locked"] == "none":
                url = d["url"]
                channels[d["id"]] = {"name": d["name"], "url": d["url"], "logo": d["logoUrl"], "type": d["type"], "group": groups[d["group"]]}


def get_catchup(id, utc, utcend):
    id = id.split(".")[0]
    date_time_start = datetime.fromtimestamp(int(utc) + 60)
    d_start = date_time_start.strftime("%Y-%m-%d+%H:%M:%S")
    url =  "http://sledovanietv.sk/download/noAccess-cs.m3u8"
    sessid = get_sessid()
    if sessid != "":
        req = requests.get("https://poda.moderntv.eu/api/epg?time=" + d_start + "&duration=1439&detail=poster&channels=" + id + "&PHPSESSID=" + sessid, headers = headers).json()
        if req["status"] == 1:
            eventId = req["channels"][id][0]["eventId"]
            req = requests.get("https://poda.moderntv.eu/api/event-timeshift?format=m3u8&quality=" + quality + "&capabilities=" + kd[addon.getSetting("poda_codec")] + adaptive + "&force=true&eventId=" + eventId + "&overrun=1&PHPSESSID=" + sessid, headers = headers).json()
            if req["status"] == 1:
                url = req["url"]
    return url


def get_vod_stream(id):
    id = id.split(".")[0]
    url =  "http://sledovanietv.sk/download/noAccess-cs.m3u8"
    sessid = get_sessid()
    if sessid != "":
        req = requests.get("https://poda.moderntv.eu/api/record-timeshift?format=m3u8&quality=" + quality + "&capabilities=" + kd[addon.getSetting("poda_codec")] + adaptive + "&force=true&recordId=" + str(id) + "&overrun=1&PHPSESSID=" + sessid, headers = headers).json()
        if req["status"] == 1:
            url = req["url"]
    return url


def vod_favorites():
    records = {}
    sessid = get_sessid()
    if sessid != "":
        req = requests.get("https://poda.moderntv.eu/api/get-pvr/?detail=description,poster,backdrop&backdropSize=1280&posterSize=234&PHPSESSID=" + sessid, headers = headers).json()
        if req["status"] == 1 and req["records"] != []:
            for r in req["records"]:
#                if r["enabled"] == 1:
                    try:
                        year = " (" + str(r["event"]["year"]) + ")"
                    except:
                        year = ""
                    try:
                        logo = r["event"]["poster"]
                    except:
                        logo = ""
                    records[str(r["id"])] = {"name": r["title"] + year, "logo": logo}
    return records


def restart_pvr():
    try:
        addon_pvr = xbmcaddon.Addon('pvr.iptvsimple')
        addon_pvr.setSetting('catchupEnabled', 'true')
    except:
        pass


def add_record(id, utc, utcend):
    idd = ""
    for x, y in channels.items():
        if y["name"] == id:
            idd = x
    if idd != "":
        date_time_start = datetime.fromtimestamp(int(utc) + 60)
        d_start = date_time_start.strftime("%Y-%m-%d+%H:%M:%S")
        sessid = get_sessid()
        if sessid != "":
            req = requests.get("https://poda.moderntv.eu/api/epg?time=" + d_start + "&duration=1439&detail=poster&channels=" + idd + "&PHPSESSID=" + sessid, headers = headers).json()
            if req["status"] == 1:
                eventId = req["channels"][idd][0]["eventId"]
                req = requests.get("https://poda.moderntv.eu/api/record-event?eventId=" + eventId + "&PHPSESSID=" + sessid, headers = headers).json()
                if req["status"] == 1:
                    restart_pvr()
                    xbmcgui.Dialog().notification("PODA.tv", "Přidáno", icon = icon)


def del_record(title):
    epgId = ""
    records = vod_favorites()
    for x,y in records.items():
        if y["name"] == title:
            epgId = x
    if epgId != "":
        sessid = get_sessid()
        if sessid != "":
            req = requests.get("https://poda.moderntv.eu/api/delete-record?recordId=" + epgId + "&PHPSESSID=" + sessid, headers = headers).json()
            if req["status"] == 1:
                restart_pvr()
                xbmcgui.Dialog().notification("PODA.tv", "Odebráno", icon = icon)
