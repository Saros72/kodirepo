# -*- coding: utf-8 -*-


import requests, xbmcaddon, xbmcgui, os, xbmcvfs, xbmc, json


icon = os.path.join(xbmcvfs.translatePath('special://home/addons/service.iptv.web.server'),'resources', 'lib', 'providers', 'sweet', 'icon.jpeg')
addon = xbmcaddon.Addon()
profile = xbmcvfs.translatePath(addon.getAddonInfo('profile')).encode().decode("utf-8")
sweet_token = os.path.join(profile, "sweet_token.json")
sweet_channels = os.path.join(profile, "sweet_channels.json")


try:
    with open(sweet_token, 'r') as openfile:
        data = json.load(openfile)
    refresh_token = data["refresh_token"]
    UUID = str(data["UUID"])
except:
    refresh_token = ""
    UUID = "07d2453f-0031-4573-95d5-16b3237eb497"
UA ='Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:105.0) Gecko/20100101 Firefox/105.0'
headers = {'Host': 'api.sweet.tv', 'user-agent': UA, 'accept': 'application/json, text/plain, */*', 'accept-language': 'cs', 'x-device': '1;22;0;2;3.2.57', 'origin': 'https://sweet.tv', 'dnt': '1', 'referer': 'https://sweet.tv/'}


def get_token():
    data = {'device': {'type': 'DT_Web_Browser', 'application': {'type': 'AT_SWEET_TV_Player'}, 'model': UA, 'firmware': {'versionCode': 1, 'versionString': '3.2.57'}, 'uuid': UUID, 'supported_drm': {'widevine_modular': True}, 'screen_info': {'aspectRatio': 6, 'width': 1366, 'height': 768}}, 'refresh_token': refresh_token}
    req = requests.post("https://api.sweet.tv/AuthenticationService/Token.json", json = data, headers = headers).json()
    try:
        if req["result"] == "OK":
            return req["access_token"]
        else:
            return ""
    except:
        return ""


def main():
    access_token = get_token()
    data = {'device': {'type': 'DT_Web_Browser', 'application': {'type': 'AT_SWEET_TV_Player'}, 'model': UA, 'firmware': {'versionCode': 1, 'versionString': '3.2.57'}, 'uuid': UUID, 'supported_drm': {'widevine_modular': True}, 'screen_info': {'aspectRatio': 6, 'width': 1366, 'height': 768}}, 'refresh_token': refresh_token}
    headers["authorization"] = "Bearer " + access_token
    req = requests.post("https://api.sweet.tv/SigninService/Logout.json", json = data, headers = headers).json()
    try:
        if req["result"] == "OK":
            xbmcvfs.delete(sweet_token)
            xbmcvfs.delete(sweet_channels)
            xbmcgui.Dialog().notification("Sweet TV", "Odhlášení úspěšné", icon = icon)
        else:
            xbmcgui.Dialog().notification("Sweet TV", req["result"], icon = icon)
    except:
        xbmcgui.Dialog().notification("Sweet TV", req["message"], icon = icon)


if __name__ == "__main__":
    main()