#-*-coding:utf8;-*-

import requests, xbmcaddon, xbmcgui, json


addon = xbmcaddon.Addon(id='service.iptv.web.server')
channels = {}


token = xbmcaddon.Addon().getSetting("reb_token")
id = xbmcaddon.Addon().getSetting("reb_id")
headers = {"Content-Type": "application/json", "Authorization": "Bearer " + token, "x-television-client-id": id, "Host": "bbxnet.api.iptv.rebit.sk", "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0"}
if token != "":
    req = requests.get("https://bbxnet.api.iptv.rebit.sk/television/channels", headers = headers)
    if req.status_code == 200:
        for r in req.json()["data"]:
            channels[r["channel"]] = ((r["title"], r["id"]))


def get_stream(id):
    url = "http://sledovanietv.sk/download/noAccess-cs.m3u8"
    try:
        url = requests.get("https://bbxnet.api.iptv.rebit.sk/television/channels/" + str(id) + "/play", headers = headers).json()["data"]["link"]
    except:
        url = "http://sledovanietv.sk/download/noAccess-cs.m3u8"
    return url