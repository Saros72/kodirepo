import tvgo
tvgo.reg_device()