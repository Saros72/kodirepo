import requests, xbmcaddon, xbmcgui, os, xbmcvfs, sys, xbmc
from urllib.parse import urlparse
from urllib3.util.retry import Retry
from requests.adapters import HTTPAdapter
from datetime import datetime


UA = "okhttp/3.12.12"
addon = xbmcaddon.Addon(id='service.iptv.web.server')
user = addon.getSetting("tm_username")
password = addon.getSetting("tm_password")
icon = os.path.join(xbmcvfs.translatePath('special://home/addons/service.iptv.web.server'),'resources', 'lib', 'providers', 'tm', 'icon.png')
addon_dir = xbmcvfs.translatePath( addon.getAddonInfo('path') )
addon_icon = os.path.join(addon_dir, "icon.png")
dev_id = "ab2731523db7"
dev_name = "ANDROID-PHONE"
session = requests.Session()
session.mount('https://', HTTPAdapter(max_retries=Retry(total=5, backoff_factor=0.1, status_forcelist=[500, 502, 503, 504])))


def login(dev_type):
    addon = xbmcaddon.Addon(id='service.iptv.web.server')
    params={"dsid": dev_id, "deviceName": dev_name, "deviceType": dev_type, "osVersion": "0.0.0", "appVersion": "0.0.0", "language": "CZ"}
    headers={'Origin': 'https://www.magiogo.cz', 'Pragma': 'no-cache', 'Referer': 'https://www.magiogo.cz/', 'User-Agent': UA, 'Sec-Fetch-Mode': 'cors', 'Sec-Fetch-Site': 'cross-site'}
    req = requests.post("https://czgo.magio.tv/v2/auth/init", params=params, headers=headers).json()
    accessToken = req["token"]["accessToken"]
    params = {"loginOrNickname": user, "password": password}
    headers = {"authorization": "Bearer " + accessToken, 'Origin': 'https://www.magiogo.cz', 'Pragma': 'no-cache', 'Referer': 'https://www.magiogo.cz/', 'Sec-Fetch-Mode': 'cors', 'Sec-Fetch-Site': 'cross-site', 'User-Agent': UA}
    req = requests.post("https://czgo.magio.tv/v2/auth/login", json = params, headers = headers).json()
    if req["success"] == True:
        return req["token"]["accessToken"], req["token"]["refreshToken"]
    else:
        xbmcgui.Dialog().notification("T-Mobile TV GO", str(req["errorMessage"]), icon = icon)


def reg_device():
    addon = xbmcaddon.Addon(id='service.iptv.web.server')
    accesstoken, refreshtoken = login("OTT_ANDROID")
    params={"list": "LIVE", "queryScope": "LIVE"}
    headers = {"authorization": "Bearer " + accesstoken, 'Origin': 'https://www.magiogo.cz', 'Pragma': 'no-cache', 'Referer': 'https://www.magiogo.cz/', 'Sec-Fetch-Mode': 'cors', 'Sec-Fetch-Site': 'cross-site', 'User-Agent': UA}
    id = requests.get("https://czgo.magio.tv/v2/television/channels", params = params, headers = headers).json()["items"][0]["channel"]["channelId"]
    params={"service": "LIVE", "name": dev_name, "devtype": "OTT_ANDROID", "id": id, "prof": "p5", "ecid": "", "drm": "verimatrix"}
    headers = {"authorization": "Bearer " + accesstoken, 'Origin': 'https://www.magiogo.cz', 'Pragma': 'no-cache', 'Referer': 'https://www.magiogo.cz/', 'Sec-Fetch-Mode': 'cors', 'Sec-Fetch-Site': 'cross-site', 'User-Agent': UA}
    req = requests.get("https://czgo.magio.tv/v2/television/stream-url", params = params, headers = headers).json()
    if req["success"] == True:
        accesstoken, refreshtoken = login("OTT_LINUX_4302")
        addon.setSetting(id="tm_accesstoken", value= accesstoken)
        addon.setSetting(id="tm_refreshtoken", value= refreshtoken)
        xbmcgui.Dialog().notification("T-Mobile TV GO", "Přihlášení úspěšné", icon = icon)
    else:
        xbmcgui.Dialog().notification("T-Mobile TV GO", req["errorMessage"].replace("exceeded-max-device-count", "Překročen maximální počet zařízení"), icon = icon)


def get_stream(id):
    url = "http://sledovanietv.sk/download/noAccess-cs.m3u8"
    addon = xbmcaddon.Addon(id='service.iptv.web.server')
    accesstoken = addon.getSetting("tm_accesstoken")
    refreshtoken = addon.getSetting("tm_refreshtoken")
    params={"refreshToken": refreshtoken}
    headers={'Origin': 'https://www.magiogo.cz', 'Pragma': 'no-cache', 'Referer': 'https://www.magiogo.cz/', 'User-Agent': UA, 'Sec-Fetch-Mode': 'cors', 'Sec-Fetch-Site': 'cross-site'}
    req = session.post("https://czgo.magio.tv/v2/auth/tokens", json = params, headers = headers).json()
    if req["success"] == True:
        accesstoken = req["token"]["accessToken"]
        refreshtoken = req["token"]["refreshToken"]
        addon.setSetting(id="tm_accesstoken", value= accesstoken)
        addon.setSetting(id="tm_refreshtoken", value= refreshtoken)
        params={"service": "LIVE", "name": dev_name, "devtype": "OTT_LINUX_4302", "id": int(id.split(".")[0]), "prof": "p5", "ecid": "", "drm": "verimatrix"}
        headers = {"authorization": "Bearer " + accesstoken, 'Origin': 'https://www.magiogo.cz', 'Pragma': 'no-cache', 'Referer': 'https://www.magiogo.cz/', 'Sec-Fetch-Mode': 'cors', 'Sec-Fetch-Site': 'cross-site', 'User-Agent': UA}
        req = session.get("https://czgo.magio.tv/v2/television/stream-url", params = params, headers = headers).json()
        if req["success"] == True:
            url = req["url"]
            headers = {"Host": urlparse(url).netloc, "User-Agent": UA, "Connection": "Keep-Alive"}
            req = session.get(url, headers = headers, allow_redirects=False)
            url = req.headers["location"]
        else:
            url = "http://sledovanietv.sk/download/noAccess-cs.m3u8"
    else:
        url = "http://sledovanietv.sk/download/noAccess-cs.m3u8"
    return url


def get_channels():
    addon = xbmcaddon.Addon(id='service.iptv.web.server')
    accesstoken = addon.getSetting("tm_accesstoken")
    refreshtoken = addon.getSetting("tm_refreshtoken")
    dev_name = "ANDROID-PHONE"
    params={"refreshToken": refreshtoken}
    headers={'Origin': 'https://www.magiogo.cz', 'Pragma': 'no-cache', 'Referer': 'https://www.magiogo.cz/', 'User-Agent': UA, 'Sec-Fetch-Mode': 'cors', 'Sec-Fetch-Site': 'cross-site'}
    req = session.post("https://czgo.magio.tv/v2/auth/tokens", json = params, headers = headers).json()
    if req["success"] == True:
        accesstoken = req["token"]["accessToken"]
        refreshtoken = req["token"]["refreshToken"]
        addon.setSetting(id="tm_accesstoken", value= accesstoken)
        addon.setSetting(id="tm_refreshtoken", value= refreshtoken)
    params={"list": "LIVE", "queryScope": "LIVE"}
    headers = {"authorization": "Bearer " + accesstoken, 'Origin': 'https://www.magiogo.cz', 'Pragma': 'no-cache', 'Referer': 'https://www.magiogo.cz/', 'Sec-Fetch-Mode': 'cors', 'Sec-Fetch-Site': 'cross-site', 'User-Agent': UA}
    ch = {}
    try:
        req = session.get("https://czgo.magio.tv/home/categories?language=cz", headers = headers).json()["categories"]
        categories = {}
        for cc in req:
            for c in cc["channels"]:
                categories[c["channelId"]] = cc["name"]
        req = session.get("https://czgo.magio.tv/v2/television/channels", params = params, headers = headers).json()["items"]
        for c in req:
            group = categories[c["channel"]["channelId"]]
            ch[str(c["channel"]["channelId"])] = {"name": c["channel"]["name"], "logo": c["channel"]["logoUrl"], "group": group}
    except:
        ch = {}
    return ch


def get_devices():
    addon = xbmcaddon.Addon(id='service.iptv.web.server')
    accesstoken, refreshtoken = login("OTT_ANDROID")
    params={"refreshToken": refreshtoken}
    headers={'Origin': 'https://www.magiogo.cz', 'Pragma': 'no-cache', 'Referer': 'https://www.magiogo.cz/', 'User-Agent': UA, 'Sec-Fetch-Mode': 'cors', 'Sec-Fetch-Site': 'cross-site'}
    req = session.post("https://czgo.magio.tv/v2/auth/tokens", json = params, headers = headers).json()
    if req["success"] == True:
        accesstoken = req["token"]["accessToken"]
    else:
        xbmcgui.Dialog().notification("T-Mobile TV GO",req["errorMessage"], icon = icon)
        return
    headers = {"authorization": "Bearer " + accesstoken, 'Origin': 'https://www.magiogo.cz', 'Pragma': 'no-cache', 'Referer': 'https://www.magiogo.cz/', 'Sec-Fetch-Mode': 'cors', 'Sec-Fetch-Site': 'cross-site', 'User-Agent': UA}
    req = requests.get("https://czgo.magio.tv/v2/home/my-devices", headers = headers).json()
    devices = []
    try:
            devices.append((req["thisDevice"]["name"] + " (Toto zařízení)", req["thisDevice"]["id"]))
    except:
            pass
    try:
        for d in req["smallScreenDevices"]:
            devices.append((d["name"], d["id"]))
    except:
            pass
    try:
        for d in req["stbAndBigScreenDevices"]:
            devices.append((d["name"], d["id"]))
    except:
            pass
    choose = xbmcgui.Dialog().select("Odebrat zařízení", [i[0] for i in devices])

    if choose == -1: return
    else:
        dev_id = devices[choose][1]
    req = requests.get("https://czgo.magio.tv/home/deleteDevice?id=" + str(dev_id), headers = headers).json()
    if req["success"] == True:
        xbmcgui.Dialog().notification("T-Mobile TV GO", "Odebráno", icon = icon)
        if choose == 0:
            addon.setSetting(id="tm_accesstoken", value="")
            addon.setSetting(id="tm_refreshtoken", value="")
    else:
        xbmcgui.Dialog().notification("T-Mobile TV GO", req["errorMessage"], icon = icon)


def get_catchup(id, utc, utcend):
    id = int(id.split(".")[0])
    addon = xbmcaddon.Addon(id='service.iptv.web.server')
    accesstoken = addon.getSetting("tm_accesstoken")
    refreshtoken = addon.getSetting("tm_refreshtoken")
    params={"refreshToken": refreshtoken}
    headers={'Origin': 'https://www.magiogo.cz', 'Pragma': 'no-cache', 'Referer': 'https://www.magiogo.cz/', 'User-Agent': UA, 'Sec-Fetch-Mode': 'cors', 'Sec-Fetch-Site': 'cross-site'}
    req = session.post("https://czgo.magio.tv/v2/auth/tokens", json = params, headers = headers).json()
    if req["success"] == True:
        accesstoken = req["token"]["accessToken"]
        refreshtoken = req["token"]["refreshToken"]
        addon.setSetting(id="tm_accesstoken", value= accesstoken)
        addon.setSetting(id="tm_refreshtoken", value= refreshtoken)
        params={"service": "ARCHIVE", "name": dev_name, "devtype": "OTT_ANDROID", "id": int(id), "prof": "p5", "ecid": "", "drm": "verimatrix"}
        headers = {"authorization": "Bearer " + accesstoken, 'Origin': 'https://www.magiogo.cz', 'Pragma': 'no-cache', 'Referer': 'https://www.magiogo.cz/', 'Sec-Fetch-Mode': 'cors', 'Sec-Fetch-Site': 'cross-site', 'User-Agent': UA}
        date_time_start = datetime.fromtimestamp(int(utc))
        d_start = date_time_start.strftime("%Y-%m-%dT%H:%M:%S")
        date_time_end = datetime.fromtimestamp(int(utcend))
        d_end = date_time_end.strftime("%Y-%m-%dT%H:%M:%S")
        req = session.get("https://czgo.magio.tv/v2/television/epg?filter=channel.id==" + str(id) + "%20and%20startTime=ge=" + d_start + ".000Z%20and%20endTime=le=" + d_end + ".000Z&limit=10&offset=0&lang=CZ", params = params, headers = headers).json()
        if req["success"] == True:
            scheduleId = str(req["items"][0]["programs"][0]["scheduleId"])
            params={"service": "ARCHIVE", "name": dev_name, "devtype": "OTT_LINUX_4302", "id": int(scheduleId), "prof": "p5", "ecid": "", "drm": "verimatrix"}
            headers = {"authorization": "Bearer " + accesstoken, 'Origin': 'https://www.magiogo.cz', 'Pragma': 'no-cache', 'Referer': 'https://www.magiogo.cz/', 'Sec-Fetch-Mode': 'cors', 'Sec-Fetch-Site': 'cross-site', 'User-Agent': UA}
            req = session.get("https://czgo.magio.tv/v2/television/stream-url", params = params, headers = headers).json()
            if req["success"] == True:
                url = req["url"]
            else:
                url = "http://sledovanietv.sk/download/noAccess-cs.m3u8"
        else:
            url = "http://sledovanietv.sk/download/noAccess-cs.m3u8"
    else:
        url = "http://sledovanietv.sk/download/noAccess-cs.m3u8"
    return url