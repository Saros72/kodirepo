import tvgo
tvgo.get_devices()