import maggo
maggo.reg_device()