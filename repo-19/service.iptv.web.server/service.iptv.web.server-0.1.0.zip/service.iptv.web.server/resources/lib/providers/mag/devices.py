import maggo
maggo.get_devices()