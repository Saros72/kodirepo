#-*-coding:utf8;-*-

import requests, xbmcaddon, xbmcgui, json


addon = xbmcaddon.Addon(id='service.iptv.web.server')
channels = {}


token = xbmcaddon.Addon().getSetting("tel_token")
if token != "":
    data = {"device_token": token}
    req = requests.post("https://backoffice0-vip.tv.itself.cz/api/device/getSources/", json = data, headers = {"Content-Type": "application/json"}).json()
    if req["success"] == True:
        for c in req["channels"]:
            channels[c["id"]] = ((c["name"], c["content_sources"][0]["stream_profile_urls"]["adaptive"]))

