#-*-coding:utf8;-*-

import requests, xbmcaddon, xbmcgui, json, xbmc, os, xbmcvfs


addon = xbmcaddon.Addon()
username = addon.getSetting("reb_username")
password = addon.getSetting("reb_password")
icon = os.path.join(xbmcvfs.translatePath('special://home/addons/service.iptv.web.server'),'resources', 'lib', 'providers', 'reb', 'icon.png')
addon_dir = xbmcvfs.translatePath( addon.getAddonInfo('path') )
addon_icon = os.path.join(addon_dir, "icon.png")
profile = xbmcvfs.translatePath(addon.getAddonInfo('profile')).encode().decode("utf-8")
rebit_token = os.path.join(profile, "rebit_token.json")


def main():
    headers = {"Content-Type": "application/json", "Host": "bbxnet.api.iptv.rebit.sk", "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0"}
    data = {"username": username, "password": password}
    req = requests.post("https://bbxnet.api.iptv.rebit.sk/auth/auth", json = data, headers = headers)
    if req.status_code == 200 or req.status_code == 201:
        token = req.json()["data"]["access_token"]
        headers = {"Content-Type": "application/json", "Authorization": "Bearer " + token, "Host": "bbxnet.api.iptv.rebit.sk", "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:70.0) Gecko/20100101 Firefox/70.0"}
        data = {"title": "PC-LINUX", "type": "computer", "child_lock_code": "0000"}
        req = requests.post("https://bbxnet.api.iptv.rebit.sk/television/client", json = data, headers = headers)
        if req.status_code == 200 or req.status_code == 201:
            id = req.json()["data"]["id"]
            data = {"token": token, "id": id}
            json_object = json.dumps(data, indent=4)
            with open(rebit_token, "w") as outfile:
                outfile.write(json_object)
            xbmcgui.Dialog().notification("REBIT.tv", "Přihlášení úspěšné", icon = icon)
            xbmc.sleep(4000)
            xbmcgui.Dialog().notification("IPTV Web Server", "Restartujte KODI", icon = addon_icon)
        else:
            xbmcgui.Dialog().notification("REBIT.tv", req.json()["message"], icon = icon)
    else:
        xbmcgui.Dialog().notification("REBIT.tv", req.json()["message"], icon = icon)