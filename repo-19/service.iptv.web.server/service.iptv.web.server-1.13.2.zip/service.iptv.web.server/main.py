# -*- coding: utf-8 -*-


import routing, xbmcgui, xbmcaddon, xbmcvfs, os, json, xbmcplugin, requests, socket


plugin = routing.Plugin()
addon = xbmcaddon.Addon()
profile = xbmcvfs.translatePath(addon.getAddonInfo('profile')).encode().decode("utf-8")
addon_dir = xbmcvfs.translatePath( addon.getAddonInfo('path') )
addon_icon = os.path.join(addon_dir, "icon.png")
own_channels_path = os.path.join(profile, "custom_channels.json")
o2ids = os.path.join(profile, "o2_ids.json")


@plugin.route('/touchtv_login')
def touchtv_login():
    from resources.lib.providers.touchtv import login
    login.main()


@plugin.route('/sweet_logout')
def sweet_logout():
    from resources.lib.providers.sweet import logout
    logout.main()


@plugin.route('/sweet_login')
def sweet_login():
    from resources.lib.providers.sweet import login
    login.main()


@plugin.route('/orange_login')
def orange_login():
    from resources.lib.providers.orange import login
    login.main()


@plugin.route('/poda_pair')
def poda_pair():
    from resources.lib.providers.poda import pair
    pair.pairing()


@plugin.route('/kuki_login')
def kuki_login():
    from resources.lib.providers.kuki import login
    login.main()


@plugin.route('/tmobile_devices')
def tmobile_devices():
    from resources.lib.providers.tm import tvgo
    tvgo.get_devices()


@plugin.route('/tmobile_login')
def tmobile_login():
    from resources.lib.providers.tm import tvgo
    tvgo.reg_device()


@plugin.route('/magio_devices')
def mag_devices():
    from resources.lib.providers.mag import maggo
    maggo.get_devices()


@plugin.route('/magio_login')
def mag_login():
    from resources.lib.providers.mag import maggo
    maggo.reg_device()


@plugin.route('/rebit_login')
def rebit_login():
    from resources.lib.providers.reb import login
    login.main()


@plugin.route('/telly_login')
def telly_login():
    from resources.lib.providers.tel import login
    login.main()


@plugin.route('/stvsk_login')
def stvsk_login():
    from resources.lib.providers.stvsk import login
    login.main()


@plugin.route('/stvcz_login')
def stvcz_login():
    from resources.lib.providers.stvcz import login
    login.main()


@plugin.route('/o2_login')
def o2_login():
    from resources.lib.providers.o2 import login
    login.main()


def save_own_channels(i, s, p):
    try:
        with open(own_channels_path, 'r') as openfile:
            data = json.load(openfile)
    except:
        data = {}
    data[i] = {"select": s, "playlist": p}
    json_object = json.dumps(data, indent=4)
    with open(own_channels_path, "w") as outfile:
        outfile.write(json_object)
    try:
        addon_pvr = xbmcaddon.Addon('pvr.iptvsimple')
        addon_pvr.setSetting('catchupEnabled', 'true')
    except:
        pass


@plugin.route('/own_playlist_restore')
def own_playlist_restore():
    try:
        xbmcvfs.delete(own_channels_path)
        addon_pvr = xbmcaddon.Addon('pvr.iptvsimple')
        addon_pvr.setSetting('catchupEnabled', 'true')
        xbmcgui.Dialog().notification("IPTV Web Server", "Obnoveno", icon = addon_icon)
    except:
        pass


def getNetworkIp():
    HOST = xbmcaddon.Addon().getSetting("localhost")
    if HOST == "0":
        i = "localhost"
    else:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            i = s.getsockname()[0]
            s.close()
        except:
            i = "localhost"
    return i


@plugin.route('/own_playlist_save')
def own_playlist_save():
    dialog = xbmcgui.Dialog()
    fd = dialog.browse(3, 'Vyberte umístění', "files")
    if fd != "":
        try:
            ip = getNetworkIp()
            url = "http://" + str(ip) + ":" + str(xbmcaddon.Addon().getSetting("port")) + "/own/playlist"
            req = requests.get(url).text
            if req != "":
                with open(fd + "own_playlist.m3u", "w", encoding="utf-8") as outfile:
                    outfile.write(req)
                xbmcgui.Dialog().notification("IPTV Web Server", "Uloženo", icon = addon_icon)
            else:
                xbmcgui.Dialog().notification("IPTV Web Server", "Žádné kanály", icon = addon_icon)
        except:
            xbmcgui.Dialog().notification("IPTV Web Server", "Nelze uložit", icon = addon_icon)


@plugin.route('/own_playlist_o2')
def own_playlist_o2():
    icon = os.path.join(xbmcvfs.translatePath('special://home/addons/service.iptv.web.server'),'resources', 'lib', 'providers', 'o2', 'icon.png')
    try:
        with open(o2ids, 'r') as openfile:
            data = json.load(openfile)
    except:
        xbmcgui.Dialog().notification("O2 TV", "Žádné kanály", icon = icon)
        return
    channels = []
    for x,y in data.items():
        channels.append(y["name"])
    try:
        with open(own_channels_path, 'r') as openfile:
            select = json.load(openfile)["o2tv"]["select"]
        ch_preselect = []
        for x,y in data.items():
            if x in select:
                i = channels.index(y["name"])
                ch_preselect.append(i)
    except:
        ch_preselect = []
    dialog = xbmcgui.Dialog()
    d = dialog.multiselect("O2 TV", channels, preselect=ch_preselect)
    if d is None:
        pass
    else:
        channels_select = []
        for index in d:
            ii = list(data)[index]
            channels_select.append(ii)
        playlist = {}
        for x,y in data.items():
            if x in channels_select:
                playlist[x] = y
        save_own_channels("o2tv", channels_select, playlist)


@plugin.route('/own_playlist_tmobile')
def own_playlist_tmobile():
    icon = os.path.join(xbmcvfs.translatePath('special://home/addons/service.iptv.web.server'),'resources', 'lib', 'providers', 'tm', 'icon.png')
    from resources.lib.providers.tm import tvgo
    data  = tvgo.get_channels()
    channels = []
    for x,y in data.items():
        channels.append(y["name"])
    if channels == []:
        xbmcgui.Dialog().notification("T-Mobile TV GO", "Žádné kanály", icon = icon)
        return
    try:
        with open(own_channels_path, 'r') as openfile:
            select = json.load(openfile)["tmobile"]["select"]
        ch_preselect = []
        for x,y in data.items():
            if x in select:
                i = channels.index(y["name"])
                ch_preselect.append(i)
    except:
        ch_preselect = []
    dialog = xbmcgui.Dialog()
    d = dialog.multiselect("T-Mobile TV GO", channels, preselect=ch_preselect)
    if d is None:
        pass
    else:
        channels_select = []
        for index in d:
            ii = list(data)[index]
            channels_select.append(ii)
        playlist = {}
        for x,y in data.items():
            if x in channels_select:
                playlist[x] = y
        save_own_channels("tmobile", channels_select, playlist)


@plugin.route('/own_playlist_mag')
def own_playlist_mag():
    icon = os.path.join(xbmcvfs.translatePath('special://home/addons/service.iptv.web.server'),'resources', 'lib', 'providers', 'mag', 'icon.png')
    from resources.lib.providers.mag import maggo
    data  = maggo.get_channels()
    channels = []
    for x,y in data.items():
        channels.append(y["name"])
    if channels == []:
        xbmcgui.Dialog().notification("Magio GO", "Žádné kanály", icon = icon)
        return
    try:
        with open(own_channels_path, 'r') as openfile:
            select = json.load(openfile)["mag"]["select"]
        ch_preselect = []
        for x,y in data.items():
            if x in select:
                i = channels.index(y["name"])
                ch_preselect.append(i)
    except:
        ch_preselect = []
    dialog = xbmcgui.Dialog()
    d = dialog.multiselect("Magio GO", channels, preselect=ch_preselect)
    if d is None:
        pass
    else:
        channels_select = []
        for index in d:
            ii = list(data)[index]
            channels_select.append(ii)
        playlist = {}
        for x,y in data.items():
            if x in channels_select:
                playlist[x] = y
        save_own_channels("mag", channels_select, playlist)


@plugin.route('/own_playlist_stvcz')
def own_playlist_stvcz():
    icon = os.path.join(xbmcvfs.translatePath('special://home/addons/service.iptv.web.server'),'resources', 'lib', 'providers', 'stvcz', 'icon.png')
    from resources.lib.providers.stvcz import scz
    data  = scz.channels
    channels = []
    for x,y in data.items():
        channels.append(y["name"])
    if channels == []:
        xbmcgui.Dialog().notification("SledovaniTV.cz", "Žádné kanály", icon = icon)
        return
    try:
        with open(own_channels_path, 'r') as openfile:
            select = json.load(openfile)["stvcz"]["select"]
        ch_preselect = []
        for x,y in data.items():
            if x in select:
                i = channels.index(y["name"])
                ch_preselect.append(i)
    except:
        ch_preselect = []
    dialog = xbmcgui.Dialog()
    d = dialog.multiselect("SledovaniTV.cz", channels, preselect=ch_preselect)
    if d is None:
        pass
    else:
        channels_select = []
        for index in d:
            ii = list(data)[index]
            channels_select.append(ii)
        playlist = {}
        for x,y in data.items():
            if x in channels_select:
                playlist[x] = y
        save_own_channels("stvcz", channels_select, playlist)


@plugin.route('/own_playlist_poda')
def own_playlist_poda():
    icon = os.path.join(xbmcvfs.translatePath('special://home/addons/service.iptv.web.server'),'resources', 'lib', 'providers', 'poda', 'icon.png')
    from resources.lib.providers.poda import pod
    data  = pod.channels
    channels = []
    for x,y in data.items():
        channels.append(y["name"])
    if channels == []:
        xbmcgui.Dialog().notification("PODA.tv", "Žádné kanály", icon = icon)
        return
    try:
        with open(own_channels_path, 'r') as openfile:
            select = json.load(openfile)["poda"]["select"]
        ch_preselect = []
        for x,y in data.items():
            if x in select:
                i = channels.index(y["name"])
                ch_preselect.append(i)
    except:
        ch_preselect = []
    dialog = xbmcgui.Dialog()
    d = dialog.multiselect("PODA.tv", channels, preselect=ch_preselect)
    if d is None:
        pass
    else:
        channels_select = []
        for index in d:
            ii = list(data)[index]
            channels_select.append(ii)
        playlist = {}
        for x,y in data.items():
            if x in channels_select:
                playlist[x] = y
        save_own_channels("poda", channels_select, playlist)


@plugin.route('/own_playlist_stvsk')
def own_playlist_stvsk():
    icon = os.path.join(xbmcvfs.translatePath('special://home/addons/service.iptv.web.server'),'resources', 'lib', 'providers', 'stvsk', 'icon.png')
    from resources.lib.providers.stvsk import ssk
    data  = ssk.channels
    channels = []
    for x,y in data.items():
        channels.append(y["name"])
    if channels == []:
        xbmcgui.Dialog().notification("SledovanieTV.sk", "Žádné kanály", icon = icon)
        return
    try:
        with open(own_channels_path, 'r') as openfile:
            select = json.load(openfile)["stvsk"]["select"]
        ch_preselect = []
        for x,y in data.items():
            if x in select:
                i = channels.index(y["name"])
                ch_preselect.append(i)
    except:
        ch_preselect = []
    dialog = xbmcgui.Dialog()
    d = dialog.multiselect("SledovanieTV.sk", channels, preselect=ch_preselect)
    if d is None:
        pass
    else:
        channels_select = []
        for index in d:
            ii = list(data)[index]
            channels_select.append(ii)
        playlist = {}
        for x,y in data.items():
            if x in channels_select:
                playlist[x] = y
        save_own_channels("stvsk", channels_select, playlist)


@plugin.route('/own_playlist_telly')
def own_playlist_telly():
    icon = os.path.join(xbmcvfs.translatePath('special://home/addons/service.iptv.web.server'),'resources', 'lib', 'providers', 'tel', 'icon.png')
    from resources.lib.providers.tel import telly
    data  = telly.channels
    channels = []
    for x,y in data.items():
        channels.append(y["name"])
    if channels == []:
        xbmcgui.Dialog().notification("Telly", "Žádné kanály", icon = icon)
        return
    try:
        with open(own_channels_path, 'r') as openfile:
            select = json.load(openfile)["telly"]["select"]
        ch_preselect = []
        for x,y in data.items():
            if x in select:
                i = channels.index(y["name"])
                ch_preselect.append(i)
    except:
        ch_preselect = []
    dialog = xbmcgui.Dialog()
    d = dialog.multiselect("Telly", channels, preselect=ch_preselect)
    if d is None:
        pass
    else:
        channels_select = []
        for index in d:
            ii = list(data)[index]
            channels_select.append(ii)
        playlist = {}
        for x,y in data.items():
            if x in channels_select:
                playlist[x] = y
        save_own_channels("telly", channels_select, playlist)


@plugin.route('/own_playlist_kuki')
def own_playlist_kuki():
    icon = os.path.join(xbmcvfs.translatePath('special://home/addons/service.iptv.web.server'),'resources', 'lib', 'providers', 'kuki', 'icon.png')
    from resources.lib.providers.kuki import kuki
    data  = kuki.channels
    channels = []
    for x,y in data.items():
        channels.append(y["name"])
    if channels == []:
        xbmcgui.Dialog().notification("Kuki", "Žádné kanály", icon = icon)
        return
    try:
        with open(own_channels_path, 'r') as openfile:
            select = json.load(openfile)["kuki"]["select"]
        ch_preselect = []
        for x,y in data.items():
            if x in select:
                i = channels.index(y["name"])
                ch_preselect.append(i)
    except:
        ch_preselect = []
    dialog = xbmcgui.Dialog()
    d = dialog.multiselect("Kuki", channels, preselect=ch_preselect)
    if d is None:
        pass
    else:
        channels_select = []
        for index in d:
            ii = list(data)[index]
            channels_select.append(ii)
        playlist = {}
        for x,y in data.items():
            if x in channels_select:
                playlist[x] = y
        save_own_channels("kuki", channels_select, playlist)


@plugin.route('/own_playlist_rebit')
def own_playlist_rebit():
    icon = os.path.join(xbmcvfs.translatePath('special://home/addons/service.iptv.web.server'),'resources', 'lib', 'providers', 'reb', 'icon.png')
    from resources.lib.providers.reb import rebit
    data  = rebit.channels
    channels = []
    for x,y in data.items():
        channels.append(y["name"])
    if channels == []:
        xbmcgui.Dialog().notification("REBIT.tv", "Žádné kanály", icon = icon)
        return
    try:
        with open(own_channels_path, 'r') as openfile:
            select = json.load(openfile)["rebit"]["select"]
        ch_preselect = []
        for x,y in data.items():
            if x in select:
                i = channels.index(y["name"])
                ch_preselect.append(i)
    except:
        ch_preselect = []
    dialog = xbmcgui.Dialog()
    d = dialog.multiselect("REBIT.tv", channels, preselect=ch_preselect)
    if d is None:
        pass
    else:
        channels_select = []
        for index in d:
            ii = list(data)[index]
            channels_select.append(ii)
        playlist = {}
        for x,y in data.items():
            if x in channels_select:
                playlist[x] = y
        save_own_channels("rebit", channels_select, playlist)


@plugin.route('/own_playlist_orange')
def own_playlist_orange():
    icon = os.path.join(xbmcvfs.translatePath('special://home/addons/service.iptv.web.server'),'resources', 'lib', 'providers', 'orange', 'icon.png')
    from resources.lib.providers.orange import orange
    data  = orange.channels
    channels = []
    for x,y in data.items():
        channels.append(y["name"])
    if channels == []:
        xbmcgui.Dialog().notification("Orange TV", "Žádné kanály", icon = icon)
        return
    try:
        with open(own_channels_path, 'r') as openfile:
            select = json.load(openfile)["orange"]["select"]
        ch_preselect = []
        for x,y in data.items():
            if x in select:
                i = channels.index(y["name"])
                ch_preselect.append(i)
    except:
        ch_preselect = []
    dialog = xbmcgui.Dialog()
    d = dialog.multiselect("Orange TV", channels, preselect=ch_preselect)
    if d is None:
        pass
    else:
        channels_select = []
        for index in d:
            ii = list(data)[index]
            channels_select.append(ii)
        playlist = {}
        for x,y in data.items():
            if x in channels_select:
                playlist[x] = y
        save_own_channels("orange", channels_select, playlist)


@plugin.route('/own_playlist_sweet')
def own_playlist_sweet():
    icon = os.path.join(xbmcvfs.translatePath('special://home/addons/service.iptv.web.server'),'resources', 'lib', 'providers', 'sweet', 'icon.jpeg')
    from resources.lib.providers.sweet import sweet
    data  = sweet.channels
    channels = []
    for x,y in data.items():
        channels.append(y["name"])
    if channels == []:
        xbmcgui.Dialog().notification("Sweet TV", "Žádné kanály", icon = icon)
        return
    try:
        with open(own_channels_path, 'r') as openfile:
            select = json.load(openfile)["sweet"]["select"]
        ch_preselect = []
        for x,y in data.items():
            if x in select:
                i = channels.index(y["name"])
                ch_preselect.append(i)
    except:
        ch_preselect = []
    dialog = xbmcgui.Dialog()
    d = dialog.multiselect("Sweet TV", channels, preselect=ch_preselect)
    if d is None:
        pass
    else:
        channels_select = []
        for index in d:
            ii = list(data)[index]
            channels_select.append(ii)
        playlist = {}
        for x,y in data.items():
            if x in channels_select:
                playlist[x] = y
        save_own_channels("sweet", channels_select, playlist)


@plugin.route('/own_playlist_touch')
def own_playlist_touch():
    icon = os.path.join(xbmcvfs.translatePath('special://home/addons/service.iptv.web.server'),'resources', 'lib', 'providers', 'touchtv', 'icon.png')
    from resources.lib.providers.touchtv import touchtv
    data  = touchtv.channels
    channels = []
    for x,y in data.items():
        channels.append(y["name"])
    if channels == []:
        xbmcgui.Dialog().notification("Touch TV", "Žádné kanály", icon = icon)
        return
    try:
        with open(own_channels_path, 'r') as openfile:
            select = json.load(openfile)["touch"]["select"]
        ch_preselect = []
        for x,y in data.items():
            if x in select:
                i = channels.index(y["name"])
                ch_preselect.append(i)
    except:
        ch_preselect = []
    dialog = xbmcgui.Dialog()
    d = dialog.multiselect("Touch TV", channels, preselect=ch_preselect)
    if d is None:
        pass
    else:
        channels_select = []
        for index in d:
            ii = list(data)[index]
            channels_select.append(ii)
        playlist = {}
        for x,y in data.items():
            if x in channels_select:
                playlist[x] = y
        save_own_channels("touch", channels_select, playlist)


if (__name__ == "__main__"):
    plugin.run()