# -*- coding: utf-8 -*-


import xbmc, time, xbmcgui, os, json, xbmcvfs, xbmcaddon, re, requests
from datetime import datetime


addon = xbmcaddon.Addon()
provider = addon.getSetting("provider_record")


def get_sec(time_str):
    h, m, s = time_str.split(':')
    return int(h) * 3600 + int(m) * 60 + int(s)


def main():
    title = xbmc.getInfoLabel('Listitem.Title')
    name = xbmc.getInfoLabel('Listitem.ChannelName')
    addon_pvr = xbmcaddon.Addon('pvr.iptvsimple')
    if addon_pvr.getSetting("m3uPathType") == "0":
        url = open(addon_pvr.getSetting("m3uPath"), "r").read()
    else:
        url = requests.get(addon_pvr.getSetting("m3uUrl")).text
    provider = ""
    url = url.split("#EXTINF")
    for x in url:
        if name in x:
            try:
                provider = re.findall('provider="(.*?)"',str(x), re.DOTALL)[0]
            except:
                pass
            break
    duration = get_sec(xbmc.getInfoLabel('ListItem.Duration(HH:mm:ss)'))
    epg = xbmc.getInfoLabel('ListItem.FileName').replace(".epg", "").replace(" ", "T")
    st = int(datetime.fromisoformat(epg).timestamp()) + abs(time.timezone)
    start = str(st)
    stop = str(st + duration)
    profile = xbmcvfs.translatePath(addon.getAddonInfo('profile')).encode().decode("utf-8")
    if provider == "O2 TV":
        o2ids = os.path.join(profile, "o2_ids.json")
        with open(o2ids, 'r') as openfile:
            data = json.load(openfile)
        id = ""
        for x, y in data.items():
            if name == y["name"].replace(" HD", ""):
                id = x
        from resources.lib.providers.o2 import o2
        o2.add_record(id, start, stop)
    elif provider == "SledovaniTV.cz":
        from resources.lib.providers.stvcz import scz
        scz.add_record(name, start, stop)
    elif provider == "PODA.tv":
        from resources.lib.providers.poda import pod
        pod.add_record(name, start, stop)
    elif provider == "SledovanieTV.sk":
        from resources.lib.providers.stvsk import ssk
        ssk.add_record(name, start, stop)
    elif provider == "T-Mobile TV GO":
        from resources.lib.providers.tm import tvgo
        tvgo.add_record(name, start, stop)
    elif provider == "Magio GO":
        from resources.lib.providers.mag import maggo
        maggo.add_record(name, start, stop)


if __name__ == "__main__":
    main()
