#-*-coding:utf8;-*-

import requests, xbmcaddon, xbmcgui, json, xbmc, os, xbmcvfs, uuid
from urllib.parse import quote


addon = xbmcaddon.Addon()
username = addon.getSetting("stvsk_username")
password = addon.getSetting("stvsk_password")
icon = os.path.join(xbmcvfs.translatePath('special://home/addons/service.iptv.web.server'),'resources', 'lib', 'providers', 'stvsk', 'icon.png')
addon_dir = xbmcvfs.translatePath( addon.getAddonInfo('path') )
addon_icon = os.path.join(addon_dir, "icon.png")
headers = {"User-Agent": "okhttp/3.12.12"}
product_list = {"0": "ANDROID-PHONE", "1": "SAMSUNG-TV"}
dev_list = {"0": "androidportable", "1": "samsungtv"}
mac_num = hex(uuid.getnode()).replace('0x', '').upper()
mac = ':'.join(mac_num[i : i + 2] for i in range(0, 11, 2))
product = product_list[addon.getSetting("stvsk_device")]
dev = dev_list[addon.getSetting("stvsk_device")]
profile = xbmcvfs.translatePath(addon.getAddonInfo('profile')).encode().decode("utf-8")
stvsk_data = os.path.join(profile, "stvsk_data.json")


def main():
    req = requests.get("https://sledovanietv.sk/api/create-pairing?username=" + quote(username) + "&password=" + quote(password) + "&type=" + dev + "&product=" + product+ "&serial=" + mac, headers = headers).json()
    if req["status"] == 1:
        json_object = json.dumps(req, indent=4)
        with open(stvsk_data, "w") as outfile:
            outfile.write(json_object)
        xbmcgui.Dialog().notification("SledovanieTV.sk", "Přihlášení úspěšné", icon = icon)
        xbmc.sleep(4000)
        xbmcgui.Dialog().notification("IPTV Web Server", "Restartujte KODI", icon = addon_icon)
    else:
        xbmcgui.Dialog().notification("SledovanieTV.sk", req["error"], icon = icon)