#-*-coding:utf8;-*-

import requests, xbmcaddon, xbmcgui, os, xbmcvfs, xbmc, json, uuid


icon = os.path.join(xbmcvfs.translatePath('special://home/addons/service.iptv.web.server'),'resources', 'lib', 'providers', 'touchtv', 'icon.png')
addon = xbmcaddon.Addon()
id = addon.getSetting("touchtv_id")
profile = xbmcvfs.translatePath(addon.getAddonInfo('profile')).encode().decode("utf-8")
touchtv_channels = os.path.join(profile, "touchtv_channels.json")
touchtv_token = os.path.join(profile, "touchtv_token.json")
addon_dir = xbmcvfs.translatePath( addon.getAddonInfo('path') )
addon_icon = os.path.join(addon_dir, "icon.png")
UUID = str(uuid.uuid4())


def main():
    data = {}
    channels = {}
    headers = {"X-DeviceId": UUID, "X-MobileToken": id, "Connection": "keep-alive", "Accept-Encoding": "", "User-Agent": "touchTV/4.2.2 (Linux; Android TV 11; cs; Amlogic VONTAR X2) ExoPlayerLib/2.17.1", "Host": "am.di-vision.sk"}
    req = requests.get("https://am.di-vision.sk/rest/assetgroups", headers = headers)
    if req.status_code == 200 or req.status_code == 201:
        data["touch_id"] = str(id)
        data["UUID"] = str(UUID)
        json_object = json.dumps(data, indent=4)
        with open(touchtv_token, "w") as outfile:
            outfile.write(json_object)
        for ch in req.json():
            channels[str(ch["selector"])] = {"name": ch["title"].replace(" HD", ""), "logo": ch["logoUrl"], "gid": ch["id"], "epgId": ch["epgId"], "vod": ch["vodUrlPrefix"]}
        json_object = json.dumps(channels, indent=4)
        with open(touchtv_channels, "w") as outfile:
            outfile.write(json_object)
        xbmcgui.Dialog().notification("Touch TV", "Přihlášení úspěšné", icon = icon)
        xbmc.sleep(4000)
        xbmcgui.Dialog().notification("IPTV Web Server", "Restartujte KODI", icon = addon_icon)
    else:
        xbmcgui.Dialog().notification("Touch TV", "Přihlášení se nezdařilo", icon = icon)