import routing


plugin = routing.Plugin()


@plugin.route('/touchtv_login')
def touchtv_login():
    from resources.lib.providers.touchtv import login
    login.main()


@plugin.route('/sweet_logout')
def sweet_logout():
    from resources.lib.providers.sweet import logout
    logout.main()


@plugin.route('/sweet_login')
def sweet_login():
    from resources.lib.providers.sweet import login
    login.main()


@plugin.route('/orange_login')
def orange_login():
    from resources.lib.providers.orange import login
    login.main()


@plugin.route('/poda_pair')
def poda_pair():
    from resources.lib.providers.poda import pair
    pair.pairing()


@plugin.route('/kuki_login')
def kuki_login():
    from resources.lib.providers.kuki import login
    login.main()


@plugin.route('/tmobile_devices')
def tmobile_devices():
    from resources.lib.providers.tm import tvgo
    tvgo.get_devices()


@plugin.route('/tmobile_login')
def tmobile_login():
    from resources.lib.providers.tm import tvgo
    tvgo.reg_device()


@plugin.route('/magio_devices')
def mag_devices():
    from resources.lib.providers.mag import maggo
    maggo.get_devices()


@plugin.route('/magio_login')
def mag_login():
    from resources.lib.providers.mag import maggo
    maggo.reg_device()


@plugin.route('/rebit_login')
def rebit_login():
    from resources.lib.providers.reb import login
    login.main()


@plugin.route('/telly_login')
def telly_login():
    from resources.lib.providers.tel import login
    login.main()


@plugin.route('/stvsk_login')
def stvsk_login():
    from resources.lib.providers.stvsk import login
    login.main()


@plugin.route('/stvcz_login')
def stvcz_login():
    from resources.lib.providers.stvcz import login
    login.main()


@plugin.route('/o2_login')
def o2_login():
    from resources.lib.providers.o2 import login
    login.main()


if (__name__ == "__main__"):
    plugin.run()