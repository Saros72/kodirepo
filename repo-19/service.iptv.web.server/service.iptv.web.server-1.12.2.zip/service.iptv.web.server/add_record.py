# -*- coding: utf-8 -*-


import xbmc, time, xbmcgui, os, json, xbmcvfs, xbmcaddon
from datetime import datetime


addon = xbmcaddon.Addon()
provider = addon.getSetting("provider_record")


def get_sec(time_str):
    h, m, s = time_str.split(':')
    return int(h) * 3600 + int(m) * 60 + int(s)


def main():
    title = xbmc.getInfoLabel('Listitem.Title')
    name = xbmc.getInfoLabel('Listitem.ChannelName')
    try:
        icon = xbmc.getInfoLabel('ListItem.Icon')
    except:
        icon = None
    duration = get_sec(xbmc.getInfoLabel('ListItem.Duration(HH:mm:ss)'))
    epg = xbmc.getInfoLabel('ListItem.FileName').replace(".epg", "").replace(" ", "T")
    st = int(datetime.fromisoformat(epg).timestamp()) + abs(time.timezone)
    start = str(st)
    stop = str(st + duration)
    profile = xbmcvfs.translatePath(addon.getAddonInfo('profile')).encode().decode("utf-8")
    if provider == "0":
        o2ids = os.path.join(profile, "o2_ids.json")
        with open(o2ids, 'r') as openfile:
            data = json.load(openfile)
        id = ""
        for x, y in data.items():
            if name == y["name"].replace(" HD", ""):
                id = x
        from resources.lib.providers.o2 import o2
        o2.add_record(id, start, stop)
    elif provider == "1":
        from resources.lib.providers.stvcz import scz
        scz.add_record(name, start, stop)
    elif provider == "2":
        from resources.lib.providers.poda import pod
        pod.add_record(name, start, stop)
    elif provider == "3":
        from resources.lib.providers.stvsk import ssk
        ssk.add_record(name, start, stop)
    elif provider == "4":
        from resources.lib.providers.tm import tvgo
        tvgo.add_record(name, start, stop)
    elif provider == "5":
        from resources.lib.providers.mag import maggo
        maggo.add_record(name, start, stop)


if __name__ == "__main__":
    main()
