# -*- coding: utf-8 -*-


import xbmc, xbmcaddon


addon = xbmcaddon.Addon()
provider = addon.getSetting("provider_record")


def main():
    title = xbmc.getInfoLabel('Listitem.Title')
    if provider == "0":
        from resources.lib.providers.o2 import o2
        o2.del_record(title)
    elif provider == "1":
        from resources.lib.providers.stvcz import scz
        scz.del_record(title)
    elif provider == "2":
        from resources.lib.providers.poda import pod
        pod.del_record(title)
    elif provider == "3":
        from resources.lib.providers.stvsk import ssk
        ssk.del_record(title)


if __name__ == "__main__":
    main()