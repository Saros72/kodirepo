# -*- coding: utf-8 -*-


import requests, xbmcaddon, datetime, json, os, xbmcvfs
from urllib.parse import quote


addon = xbmcaddon.Addon()
profile = xbmcvfs.translatePath(addon.getAddonInfo('profile')).encode().decode("utf-8")
o2_token = os.path.join(profile, "o2_token.json")
try:
    with open(o2_token, 'r') as openfile:
        data = json.load(openfile)
    token = data["token"]
    subscription = data["subscription"]
except:
    token = ""
    subscription = ""


def get_stream(id):
    url = "http://sledovanietv.sk/download/noAccess-cs.m3u8"
    headers = {'X-NanguTv-App-Version': 'Android#6.4.1', 'User-Agent': 'Dalvik/2.1.0', 'Connection': 'Keep-Alive', 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8', 'X-NanguTv-Device-Id' : 'b7pzci54mrzbcvy', 'X-NanguTv-Device-Name': 'TV-BOX', 'X-NanguTv-Access-Token': token}
    try:
        data = requests.get('https://app.o2tv.cz/sws/server/streaming/uris.json?serviceType=LIVE_TV&deviceType=STB&streamingProtocol=HLS&subscriptionCode=' + str(subscription) + '&channelKey=' + quote(id.split(".")[0]) + '&encryptionType=NONE', headers = headers).json()
        for d in data["uris"]:
            if d["resolution"] == "HD":
                url = d["uri"]
    except:
        url = "http://sledovanietv.sk/download/noAccess-cs.m3u8"
    return url


def get_catchup(id, utc, utcend):
    start = utc
    if utcend == "":
        end = int(utc) + 18000
        now =  int(datetime.datetime.now().timestamp())
        if end > now:
            end = now - 200
    else:
        end = utcend
    url =  "http://sledovanietv.sk/download/noAccess-cs.m3u8"
    headers = {'X-NanguTv-App-Version': 'Android#6.4.1', 'User-Agent': 'Dalvik/2.1.0', 'Connection': 'Keep-Alive', 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8', 'X-NanguTv-Device-Id' : 'b7pzci54mrzbcvy', 'X-NanguTv-Device-Name': 'TV-BOX', 'X-NanguTv-Access-Token': token}
    req = requests.get('https://app.o2tv.cz/sws/server/streaming/uris.json?serviceType=TIMESHIFT_TV&deviceType=STB&streamingProtocol=HLS&subscriptionCode=' + subscription +'&fromTimestamp=' + str(start) + '000&toTimestamp=' + str(end) + '000&channelKey=' + quote(id.split(".")[0]) + '&encryptionType=NONE', headers = headers)
    if req.status_code == 200:
        url = req.json()['uris'][0]['uri']
    return url


def get_vod_stream(id):
    id = id.split(".")[0]
    url =  "http://sledovanietv.sk/download/noAccess-cs.m3u8"
    try:
        sdata = data["sdata"]
    except:
        sdata = ""
    headers = {'X-NanguTv-App-Version': 'Android#6.4.1', 'User-Agent': 'Dalvik/2.1.0', 'Connection': 'Keep-Alive', 'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8', 'X-NanguTv-Device-Id' : 'b7pzci54mrzbcvy', 'X-NanguTv-Device-Name': 'TV-BOX', 'X-NanguTv-Access-Token': token}
    post = {'serviceType': 'NPVR', 'deviceType': 'STB', 'streamingProtocol': 'HLS', 'subscriptionCode': subscription, 'contentId': str(id), 'encryptionType': 'NONE'}
    req = requests.post("https://app.o2tv.cz/sws/server/streaming/uris.json", data = post, headers = headers)
    if req.status_code == 200:
        url = req.json()['uris'][0]['uri']
    return url


def vod_favorites():
    try:
        sdata = data["sdata"]
    except:
        sdata = ""
    records = {}
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:75.0) Gecko/20100101 Firefox/75.0', 'Content-Type': 'application/json', 'x-o2tv-access-token': token, 'x-o2tv-sdata': sdata, 'x-o2tv-device-id': 'b7pzci54mrzbcvy', 'x-o2tv-device-name': 'TV-BOX'}
    req = requests.get('https://api.o2tv.cz/unity/api/v1/recordings/', headers = headers)
    if req.status_code == 200:
        for r in req.json()["result"]:
            try:
                year = " (" + r["program"]["origin"]["yearStr"] + ")"
            except:
                year = ""
            records[str(r["pvrProgramId"])] = {"name": r["program"]["name"] + year, "logo": "https://img1.o2tv.cz" + r["program"]["images"][0]["cover"], "channelKey": r["program"]["channelKey"]}
    return records