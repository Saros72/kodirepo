# -*- coding: utf-8 -*-

import xbmcaddon, sys, xbmc, os, xbmcgui, bottle, xbmcvfs, requests, json, socket
from bottle import route, redirect, default_app, response, request, static_file, template
from wsgiref.simple_server import WSGIServer, WSGIRequestHandler, make_server
from socketserver import ThreadingMixIn
from threading import Thread
from resources.lib.providers.o2 import o2
from resources.lib.providers.tm import tvgo
from resources.lib.providers.mag import maggo
from resources.lib.providers.antik import antik
from resources.lib.providers.tel import telly
from resources.lib.providers.reb import rebit
from resources.lib.providers.stvcz import scz
from resources.lib.providers.stvsk import ssk
from urllib.parse import urlparse, urlencode, parse_qsl, quote
from resources.lib import czech_sort
from datetime import datetime


addon = xbmcaddon.Addon()
addon_dir = xbmcvfs.translatePath( addon.getAddonInfo('path') )
addon_icon = os.path.join(addon_dir, "icon.png")
profile = xbmcvfs.translatePath(addon.getAddonInfo('profile')).encode().decode("utf-8")
o2ids = os.path.join(profile, "o2_ids.json")
app = default_app()
bottle.debug(True)
antik_key_cache = {"access": 1}
antik_dev_id = addon.getSetting("antik_dev_id")
PORT = addon.getSetting("port")
style_home = os.path.join(xbmcvfs.translatePath('special://home/addons/service.iptv.web.server'),'resources', 'lib', 'templates', 'home.tpl')
style_links = os.path.join(xbmcvfs.translatePath('special://home/addons/service.iptv.web.server'),'resources', 'lib', 'templates', 'links.tpl')


def getNetworkIp():
    HOST = addon.getSetting("localhost")
    if HOST == "0":
        i = "localhost"
    else:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            i = s.getsockname()[0]
            s.close()
        except:
            i = "localhost"
    return i


IP = getNetworkIp()


def patch_url(url, **kwargs):
    return urlparse(url)._replace(query=urlencode(dict(parse_qsl(urlparse(url).query), **kwargs))).geturl()


@route('/files/<filename:path>')
def send_static(filename):
    return static_file(filename, root= xbmcaddon.Addon().getSetting("files_dir"))


@route("/stvsk/playlist")
def stvsk_playlist():
    if xbmcaddon.Addon().getSetting("inputstream") == "true":
        input_stream = "#KODIPROP:inputstreamaddon=inputstream.adaptive\n#KODIPROP:inputstream.adaptive.manifest_type=hls\n#KODIPROP:mimetype=application/x-mpegURL\n"
    else:
        input_stream = ""
    t = ""
    for x,y in ssk.channels.items():
        if y["type"] == "tv":
            t = t + '#EXTINF:-1 group-title="' + y["group"] + '" tvg-logo="' +y["logo"] + '" catchup="append" catchup-source="?utc={utc}&utcend={utcend}",' + y["name"] + "\n" + input_stream + "http://" + str(IP) + ":" + str(PORT)  + "/stvsk/" + str(x) + ".m3u8\n"
        else:
            t = t + '#EXTINF:-1 radio="true" group-title="' + y["group"] + '" tvg-logo="' +y["logo"] + '" catchup="append" catchup-source="?utc={utc}&utcend={utcend}",' + y["name"].replace(" HD", "") + "\nhttp://" + str(IP) + ":" + str(PORT)  + "/stvsk/" + str(x) + ".m3u8\n"
    if t != "":
        t = "#EXTM3U\n" + t
    response.content_type = 'text/plain; charset=UTF-8'
    return t


@route("/stvsk/<id>")
def stvsk_play(id):
    if 'utc' in request.query:
        stream = ssk.get_catchup(id,
 request.query["utc"], "")
    else:
        stream = ssk.channels[id.split(".")[0]]["url"]
        if "PHPSESSID" in stream:
            sessid = ssk.get_sessid()
            stream = patch_url(stream, PHPSESSID=sessid)
    response.content_type = "application/x-mpegURL"
    return redirect(stream)


@route("/stvsk/list")
def stvsk_list():
    names = []
    info = {'title': 'SledovanieTV.sk'}
    try:
        for x,y in ssk.channels.items():
            names.append(('/stvsk/' + str(x) + '.m3u8', y["name"].replace(" HD", "")))
        info["names"] = names
    except:
        return ""
    return template(style_links, info)


@route("/stvcz/playlist")
def stvcz_playlist():
    if xbmcaddon.Addon().getSetting("inputstream") == "true":
        input_stream = "#KODIPROP:inputstreamaddon=inputstream.adaptive\n#KODIPROP:inputstream.adaptive.manifest_type=hls\n#KODIPROP:mimetype=application/x-mpegURL\n"
    else:
        input_stream = ""
    t = ""
    for x,y in scz.channels.items():
        if y["type"] == "tv":
            t = t + '#EXTINF:-1 group-title="' + y["group"] + '" tvg-logo="' +y["logo"] + '" catchup="append" catchup-source="?utc={utc}&utcend={utcend}",' + y["name"] + "\n" + input_stream + "http://" + str(IP) + ":" + str(PORT)  + "/stvcz/" + str(x) + ".m3u8\n"
        else:
            t = t + '#EXTINF:-1 radio="true" group-title="' + y["group"] + '" tvg-logo="' +y["logo"] + '" catchup="append" catchup-source="?utc={utc}&utcend={utcend}",' + y["name"].replace(" HD", "") + "\nhttp://" + str(IP) + ":" + str(PORT)  + "/stvcz/" + str(x) + ".m3u8\n"
    if t != "":
        t = "#EXTM3U\n" + t
    response.content_type = 'text/plain; charset=UTF-8'
    return t


@route("/stvcz/<id>")
def stvcz_play(id):
    if 'utc' in request.query:
        stream = scz.get_catchup(id,
 request.query["utc"], "")
    else:
        stream = scz.channels[id.split(".")[0]]["url"]
        if "PHPSESSID" in stream:
            sessid = scz.get_sessid()
            stream = patch_url(stream, PHPSESSID=sessid)
    response.content_type = "application/x-mpegURL"
    return redirect(stream)


@route("/stvcz/list")
def stvcz_list():
    names = []
    info = {'title': 'SledovaniTV.cz'}
    try:
        for x,y in scz.channels.items():
            names.append(('/stvcz/' + str(x) + '.m3u8', y["name"].replace(" HD", "")))    
        info["names"] = names
    except:
        return ""
    return template(style_links, info)


@route("/rebit/playlist")
def rebit_playlist():
    if xbmcaddon.Addon().getSetting("inputstream") == "true":
        input_stream = "#KODIPROP:inputstreamaddon=inputstream.adaptive\n#KODIPROP:inputstream.adaptive.manifest_type=hls\n#KODIPROP:mimetype=application/x-mpegURL\n"
    else:
        input_stream = ""
    t = ""
    for x,y in rebit.channels.items():
        t = t + '#EXTINF:-1 tvg-logo="' + y["logo"] + '" catchup="append" catchup-source="?utc={utc}&utcend={utcend}",' + y["name"].replace(" HD", "") + "\n" + input_stream + "http://" + str(IP) + ":" + str(PORT)  + "/rebit/" + str(x) + ".m3u8\n"
    if t != "":
        t = "#EXTM3U\n" + t
    response.content_type = 'text/plain; charset=UTF-8'
    return t


@route("/rebit/<id>")
def rebit_play(id):
    ch = rebit.channels[int(id.split(".")[0])]["id"]
    if 'utc' in request.query:
        if 'utcend' in request.query:
            end = request.query["utcend"]
        else:
            now = int(datetime.now().timestamp())
            end = int(request.query["utc"]) + 10800
            if end > now:
                end = now - 60
        try:
            stream = rebit.get_catchup(ch,
 request.query["utc"], str(end))
        except:
            stream = rebit.get_stream(id)
    else:
        stream = rebit.get_stream(ch)
    response.content_type = "application/x-mpegURL"
    return redirect(stream)


@route("/rebit/list")
def rebit_list():
    names = []
    info = {'title': 'REBIT.tv'}
    try:
        for x,y in rebit.channels.items():
            names.append(('/rebit/' + str(x) + '.m3u8', y["name"].replace(" HD", "")))    
        info["names"] = names
    except:
        return ""
    return template(style_links, info)


@route("/telly/playlist")
def telly_playlist():
    if xbmcaddon.Addon().getSetting("inputstream") == "true":
        input_stream = "#KODIPROP:inputstreamaddon=inputstream.adaptive\n#KODIPROP:inputstream.adaptive.manifest_type=hls\n#KODIPROP:mimetype=application/x-mpegURL\n"
    else:
        input_stream = ""
    t = ""
    for x,y in telly.channels.items():
        t = t + "#EXTINF:-1," + y[0].replace(" HD", "") + "\n" + input_stream + "http://" + str(IP) + ":" + str(PORT)  + "/telly/" + str(x) + ".m3u8\n"
    if t != "":
        t = "#EXTM3U\n" + t
    response.content_type = 'text/plain; charset=UTF-8'
    return t


@route("/telly/<id>")
def telly_play(id):
    try:
        stream = telly.channels[int(id.split(".")[0])][1]
    except:
        stream = "http://sledovanietv.sk/download/noAccess-cs.m3u8"
    response.content_type = "application/x-mpegURL"
    return redirect(stream)


@route("/telly/list")
def telly_list():
    names = []
    info = {'title': 'Telly'}
    try:
        for x,y in telly.channels.items():
            names.append(('/telly/' + str(x) + '.m3u8', y[0].replace(" HD", "")))
        
        info["names"] = names
    except:
        return ""
    return template(style_links, info)


@route("/antik/playlist2")
def antik_playlist2():
    if xbmcaddon.Addon().getSetting("inputstream") == "true":
        input_stream = "#KODIPROP:inputstreamaddon=inputstream.adaptive\n#KODIPROP:inputstream.adaptive.manifest_type=hls\n#KODIPROP:mimetype=application/x-mpegURL\n"
    else:
        input_stream = ""
    r = requests.get(antik.playlist_url2).json()[0]["channels"]
    channels = []
    for ch in r:
        t = ch["channel_title"]
        for s in ch["stream"]:
            u = s["url"].split("/")[-2]
            if "tzshift" not in u:
                channels.append(t + "|" + u)
    r = czech_sort.sorted(channels)
    t = ""
    for i in r:
        c = i.split("|")
        t = t + "#EXTINF:-1," + c[0] + "\n" + input_stream + "http://" + str(IP) + ":" + str(PORT)  + "/antik/" + str(c[1]) + ".m3u8\n"
    t = "#EXTM3U\n" + t
    response.content_type = 'text/plain; charset=UTF-8'
    return t


@route("/antik/playlist")
def antik_playlist():
    if xbmcaddon.Addon().getSetting("inputstream") == "true":
        input_stream = "#KODIPROP:inputstreamaddon=inputstream.adaptive\n#KODIPROP:inputstream.adaptive.manifest_type=hls\n#KODIPROP:mimetype=application/x-mpegURL\n"
    else:
        input_stream = ""
    r = requests.get(antik.playlist_url).text
    ch = []
    r = r.split("/playlist.m3u8")
    for c in r:
        ch.append(c.split("|hls")[0].split("|")[-2].encode("ISO-8859-1").decode("utf-8") + "@" + c.split("/playlist.m3u8")[-1].split("/")[-1])
    r = czech_sort.sorted(ch)
    t = ""
    for i in r:
        c = i.split("@")
        t = t + "#EXTINF:-1," + c[0] + "\n" + input_stream + "http://" + str(IP) + ":" + str(PORT)  + "/antik/" + str(c[1]) + ".m3u8\n"
    t = "#EXTM3U\n" + t
    response.content_type = 'text/plain; charset=UTF-8'
    return t


@route("/antik/list")
def antik_list():
    r = requests.get(antik.playlist_url).text
    ch = []
    r = r.split("/playlist.m3u8")
    for c in r:
        ch.append(c.split("|hls")[0].split("|")[-2].encode("ISO-8859-1").decode("utf-8") + "@" + c.split("/playlist.m3u8")[-1].split("/")[-1])
    ch2 = []
    r = czech_sort.sorted(ch)
    for c in r:
        ch2.append("<a href=/antik/" + c.split("@")[1] + ".m3u8>" + c.split("@")[0]  + "</a><br>")
    return ",".join(ch2[:-1]).replace(">,", ">")


@route("/antik/list2")
def antik_list2():
    r = requests.get(antik.playlist_url2).json()[0]["channels"]
    t = ""
    for ch in r:
        t = t + "<b>" + ch["channel_title"] + "</b>:"
        for s in ch["stream"]:
            u = s["url"].split("/")[-2]
            if "tzshift" not in u:
                t = t + "<br><a href=/antik/" + u + ".m3u8>" + u  + "</a>"
        t = t + "<br><br>|"
    t = ",".join(czech_sort.sorted(t.split("|"))[1:])
    return t


@route('/antik_key/<key_id>')
def antik_key(key_id):
    global antik_key_cache
    try:
        return antik_key_cache[key_id]
    except:
        pass
    try:
        url = antik.request_template()["url"] + antik.request_template()["id"]
        data = antik.request_data(key_id)
        data = json.dumps(data, indent=2).encode('utf-8')
        data_encrypt = antik.data_encrypt(data)
        response = requests.post( url, data = data_encrypt, headers = {"Content-Type": "application/x-www-form-urlencoded", "User-Agent": "Dalvik/2.1.0 (Linux; U; Android 10; Build/1.110111.020)", "Accept-Encoding": "gzip"}).content
        bin = antik.get_bin(response)
        antik_key_cache[key_id] = bin
        antik_key_cache["access"] = 1
        return bin
    except:
        antik_key_cache["access"] = 0
        return ''


@route('/antik/<u>')
def antik_play(u):
    if antik_key_cache["access"] == 0:
        response.content_type = "application/x-mpegURL"
        return '''#EXTM3U
#EXT-X-VERSION:3
#EXT-X-TARGETDURATION:10
#EXT-X-MEDIA-SEQUENCE:0
#EXTINF:10.000000,
http://sledovanietv.sk/download/noAccess-sk0.ts
#EXTINF:10.000000,
http://sledovanietv.sk/download/noAccess-sk1.ts
#EXT-X-ENDLIST'''
    url = "http://195.181.174.88/live/" + u.replace(".m3u8", "/playlist.m3u8")
    req = requests.get(url).text.replace("encrypted-file://", "/antik_key/")
    ret=""
    for line in req.splitlines():
        if line[-3:] == ".ts":
            ret += url.replace("playlist.m3u8", "")
        ret += (line + "\n")
    response.content_type = "application/x-mpegURL"
    return ret


@route("/magio/playlist")
def magio_playlist():
    if xbmcaddon.Addon().getSetting("inputstream") == "true":
        input_stream = "#KODIPROP:inputstreamaddon=inputstream.adaptive\n#KODIPROP:inputstream.adaptive.manifest_type=mpd\n#KODIPROP:mimetype=application/dash+xml\n"
    else:
        input_stream = ""
    ch = maggo.get_channels()
    t = ""
    for x,y in ch.items():
        t = t + '#EXTINF:-1 group-title="' + y["group"] + '" tvg-logo="' +y["logo"] + '" catchup="append" catchup-source="?utc={utc}&utcend={utcend}",' + y["name"].replace(" HD", "") + "\n" + input_stream + "http://" + str(IP) + ":" + str(PORT)  + "/magio/" + str(x) + ".mpd\n"
    if t != "":
        t = "#EXTM3U\n" + t
    response.content_type = 'text/plain; charset=UTF-8'
    return t


@route("/magio/list")
def magio_list():
    names = []
    info = {'title': 'Magio GO'}
    try:
        ch = maggo.get_channels()
        for x,y in ch.items():
            names.append(('/magio/' + str(x) + '.mpd', y["name"].replace(" HD", "")))    
        info["names"] = names
    except:
        return ""
    return template(style_links, info)


@route("/magio/<id>")
def magio_play(id):
    if 'utc' in request.query:
        if 'utcend' in request.query:
            end = request.query["utcend"]
        else:
            now = int(datetime.now().timestamp())
            end = int(request.query["utc"]) + 10800
            if end > now:
                end = now - 60
        try:
            stream = maggo.get_catchup(id,
 request.query["utc"], str(end))
        except:
            stream = maggo.get_stream(id)
    else:
        stream = maggo.get_stream(id)
    response.content_type = "application/dash+xml"
    return redirect(stream)


@route("/tmobile/playlist")
def tmobile_playlist():
    if xbmcaddon.Addon().getSetting("inputstream") == "true":
        input_stream = "#KODIPROP:inputstreamaddon=inputstream.adaptive\n#KODIPROP:inputstream.adaptive.manifest_type=hls\n#KODIPROP:mimetype=application/x-mpegURL\n"
    else:
        input_stream = ""
    ch = tvgo.get_channels()
    t = ""
    for x,y in ch.items():
        t = t + '#EXTINF:-1 group-title="' + y["group"] + '" tvg-logo="' +y["logo"] + '" catchup="append" catchup-source="?utc={utc}&utcend={utcend}",' + y["name"].replace(" HD", "") + "\n" + input_stream + "http://" + str(IP) + ":" + str(PORT)  + "/tmobile/" + str(x) + ".m3u8\n"
    if t != "":
        t = "#EXTM3U\n" + t
    response.content_type = 'text/plain; charset=UTF-8'
    return t


@route("/tmobile/list")
def tmobile_list():
    names = []
    info = {'title': 'T-Mobile TV GO'}
    try:
        ch = tvgo.get_channels()
        for x,y in ch.items():
            names.append(('/tmobile/' + str(x) + '.m3u8', y["name"].replace(" HD", "")))    
        info["names"] = names
    except:
        return ""
    return template(style_links, info)


@route("/tmobile/<id>")
def tmobile_play(id):
    if 'utc' in request.query:
        if 'utcend' in request.query:
            end = request.query["utcend"]
        else:
            now = int(datetime.now().timestamp())
            end = int(request.query["utc"]) + 10800
            if end > now:
                end = now - 60
        stream = tvgo.get_catchup(id,
 request.query["utc"], str(end))
    else:
        stream = tvgo.get_stream(id)
    response.content_type = "application/x-mpegURL"
    return redirect(stream)


@route("/o2tv/playlist")
def o2tv_playlist():
    if xbmcaddon.Addon().getSetting("inputstream") == "true":
        input_stream = "#KODIPROP:inputstreamaddon=inputstream.adaptive\n#KODIPROP:inputstream.adaptive.manifest_type=hls\n#KODIPROP:mimetype=application/x-mpegURL\n"
    else:
        input_stream = ""
    try:
        with open(o2ids, 'r') as openfile:
            data = json.load(openfile)
    except:
        return ""
    t = ""
    for x,y in data.items():
        t = t + '#EXTINF:-1 tvg-logo="' + y["logo"] + '" catchup="append" catchup-source="?utc={utc}&utcend={utcend}",' + y["name"].replace(" HD", "") + "\n" + input_stream + "http://" + str(IP) + ":" + str(PORT)  + "/o2tv/" + quote(x) + ".m3u8\n"
    if t != "":
        t = "#EXTM3U\n" + t
    response.content_type = 'text/plain; charset=UTF-8'
    return t


@route("/o2tv/list")
def o2tv_list():
    try:
        with open(o2ids, 'r') as openfile:
            data = json.load(openfile)
    except:
        return ""
    names = []
    info = {'title': 'O2 TV'}
    try:
        for x,y in data.items():
            names.append(('/o2tv/' + quote(x) + '.m3u8', y["name"].replace(" HD", "")))
        info["names"] = names
    except:
        return ""
    return template(style_links, info)


@route("/o2tv/<id>")
def o2tv_play(id):
    if 'utc' in request.query:
        if 'utcend' in request.query:
            end = request.query["utcend"]
        else:
            end = ""
        stream = o2.get_catchup(id,
 request.query["utc"], end)
    else:
        stream = o2.get_stream(id)
    response.content_type = "application/x-mpegURL"
    return redirect(stream)


@route("/")
def home():
    return template(style_home)


def begin():
    xbmcgui.Dialog().notification("IPTV Web Server","http://" + str(IP) + ":" + str(PORT), sound = False, icon = addon_icon)
    httpd.serve_forever()


class SilentWSGIRequestHandler(WSGIRequestHandler):
    """Custom WSGI Request Handler with logging disabled"""
    protocol_version = 'HTTP/1.1'

    def log_message(self, *args, **kwargs):
        """Disable log messages"""
        pass


class ThreadedWSGIServer(ThreadingMixIn, WSGIServer):
    """Multi-threaded WSGI server"""
    allow_reuse_address = True
    daemon_threads = True
    timeout = 1


httpd = make_server(str(IP), int(PORT), app,
                    server_class=ThreadedWSGIServer,
                    handler_class=SilentWSGIRequestHandler)


def main():
    thread = Thread(target = begin)
    thread.daemon = True
    thread.start()
    monitor = xbmc.Monitor()
    while not monitor.abortRequested():
        if monitor.waitForAbort(1):
            httpd.shutdown()
            break


if __name__ == '__main__':
    main()