# -*- coding: utf-8 -*-

import sys
import xbmcgui
import xbmc
import xbmcplugin
import xbmcaddon
from urllib.parse import urlencode, parse_qsl
import json
import moveItem
import os


_url = sys.argv[0]
_handle = int(sys.argv[1])
addon = xbmcaddon.Addon(id='plugin.tvgo.sort.channels')
addon2 = xbmcaddon.Addon(id='script.tvgo.playlist')
profile = xbmc.translatePath(addon2.getAddonInfo('profile')).encode().decode("utf-8")
fcho = os.path.join(profile, "order.json")


def get_url(**kwargs):
    return '{0}?{1}'.format(_url, urlencode(kwargs))


def keystoint(x):
    return {int(k): v for k, v in x}


def order():
    od = {}
    f = open(fcho).read()
    return json.loads(f, object_pairs_hook=keystoint)


def list_menu():
    o = order()
    for idx, item in o.items():
        list_item = xbmcgui.ListItem(label = item[0])
        if addon.getSetting("logos_enable") == "true":
            list_item.setArt({'Icon': item[1]})
        url = get_url(action='change', index = idx)
        list_item.addContextMenuItems([('Aktualizovat playlist','RunPlugin({})'.format(get_url(action = "update_playlist")))])
        xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    xbmcplugin.endOfDirectory(_handle)


def move(index):
    o = order()
    newOrder = moveItem.getNewOrder(o, int(index))
    oo = {}
    if newOrder is not None:
        for x in newOrder:
            oo[int(newOrder.index(x))] = x
        ord = json.dumps(oo)
        f = open(fcho, "w")
        f.write(ord)
        f.close()
        xbmc.executebuiltin('Container.Refresh')


def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if params:
        if params["action"] == "change":
            move(params["index"])
        elif params["action"] == "update_playlist":
            xbmc.executebuiltin('RunAddon(script.tvgo.playlist)')
    else:
        list_menu()


if __name__ == '__main__':
    if not os.path.exists(fcho):
        xbmcgui.Dialog().notification("TV GO Sort Channels","Nejdříve vygenerujte playlist", xbmcgui.NOTIFICATION_ERROR, 4000)
        sys.exit(0)
    router(sys.argv[2][1:])
