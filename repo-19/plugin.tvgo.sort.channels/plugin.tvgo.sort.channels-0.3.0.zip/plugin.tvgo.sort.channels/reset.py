# -*- coding: utf-8 -*-

import xbmc
import xbmcvfs
import xbmcaddon
import xbmcgui
import os


addon2 = xbmcaddon.Addon(id='script.tvgo.playlist')
profile = xbmcvfs.translatePath(addon2.getAddonInfo('profile')).encode().decode("utf-8")
fcho = os.path.join(profile, "order.json")

try:
    xbmcvfs.delete(fcho)
    xbmc.executebuiltin('RunAddon(script.tvgo.playlist)')
    xbmcgui.Dialog().notification("TV GO Sort Channels","Obnoveno", xbmcgui.NOTIFICATION_INFO, 1000, sound = False)
except:
    xbmcgui.Dialog().notification("TV GO Sort Channels","Chyba", xbmcgui.NOTIFICATION_ERROR, 1000, sound = False)
