import sys
from resources.lib import webshare


if __name__ == '__main__':
    webshare.run()