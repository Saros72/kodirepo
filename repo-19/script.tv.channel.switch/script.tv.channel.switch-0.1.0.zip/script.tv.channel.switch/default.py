# -*- coding: utf-8 -*-


import xbmc
import xbmcgui
import json


if __name__ == "__main__":
    kb = xbmc.Keyboard("", "Číslo/Název kanálu")
    kb.doModal()
    if not kb.isConfirmed():
        pass
    else:
        q = kb.getText()
        channels = json.loads(xbmc.executeJSONRPC('{"id":1, "jsonrpc":"2.0","method":"PVR.GetChannels","params":{"channelgroupid":"alltv","properties":["channel","channeltype", "channelnumber"]}}'))["result"]["channels"]
        if q.isnumeric() == True:
            if q == "0":
                xbmc.executeJSONRPC('{"jsonrpc":"2.0","method":"Input.ExecuteAction","id":1,"params":{"action":"number0"}}')
            else:
                for x in channels:
                    if int(q) == x["channelnumber"]:
                        channelid = x["channelid"]
                        xbmc.executeJSONRPC('{"id":1,"jsonrpc":"2.0","method":"Player.Open","params":{"item":{"channelid":%s}}}' % channelid)
        else:
            for x in channels:
                label = x["label"].lower()
                if label[-3:] == " hd":
                    label = label[:-3]
                if q.replace(" mezera ", " ").lower() == label:
                    channelid = x["channelid"]
                    xbmc.executeJSONRPC('{"id":1,"jsonrpc":"2.0","method":"Player.Open","params":{"item":{"channelid":%s}}}' % channelid)