# -*- coding: utf-8 -*-
import xbmc
import xbmcaddon


addon = xbmcaddon.Addon()
player = xbmc.Player()


def wait_for_abort():
    if monitor.waitForAbort(1):
        raise


def stop_slideshow():
    while True:
        wait_for_abort()
        if xbmc.getCondVisibility('Slideshow.IsActive') == False:
            break
    player.stop()
    start_slideshow()


def start_slideshow():
    while True:
        wait_for_abort()
        if addon.getSetting("music_enabled") == "true" and xbmc.getCondVisibility('Slideshow.IsActive') == True:
            player.play(addon.getSetting('playlist'))
            break
    stop_slideshow()


if (__name__ == "__main__"):
    monitor = xbmc.Monitor()
    start_slideshow()
