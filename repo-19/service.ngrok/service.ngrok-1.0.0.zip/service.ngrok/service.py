#-*-coding:utf8;-*-


import xbmcaddon
import xbmcgui
import xbmc
import subprocess
import requests
import json
import os
import xbmcvfs


addon_dir = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path'))
addon_icon = os.path.join(addon_dir, "icon.png")


def ngrok():
    try:
        ng = subprocess.Popen([xbmcaddon.Addon().getSetting("ngrok_file"),'http', xbmcaddon.Addon().getSetting("port")], shell=False)
        xbmc.sleep(5000)
        url = "http://localhost:4040/api/tunnels"
        res = requests.get(url)
        res_unicode = res.content.decode("utf-8")
        res_json = json.loads(res_unicode)
        xbmcgui.Dialog().notification("Ngrok Public URL:",str(res_json["tunnels"][0]["public_url"]), icon = addon_icon)
        return ng
    except Exception as error:
        xbmcgui.Dialog().notification("Ngrok",str(type(error).__name__), icon = addon_icon)
        return None


class Main:
    def __init__( self ):
        self._service_setup()
        self.ng = None
        if xbmcaddon.Addon().getSetting("ngrok_file") != "":
            self.ng = ngrok()
        while (not self.Monitor.abortRequested()):
            if self.Monitor.waitForAbort(1):
                if self.ng is not None:
                    self.ng.kill()

    def _service_setup( self ):
        self.Monitor = MyMonitor(action = self._get_settings)
        self._get_settings

    def _get_settings( self ):
        if self.ng is not None:
            self.ng.kill()
            xbmc.sleep(1000)
        self.ng = ngrok()


class MyMonitor(xbmc.Monitor):
    def __init__( self, *args, **kwargs ):
        xbmc.Monitor.__init__( self )
        self.action = kwargs['action']

    def onSettingsChanged( self ):
        self.action()


if __name__ == '__main__':
    Main()
