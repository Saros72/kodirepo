# -*- coding: utf-8 -*-
import os
import xbmc
import xbmcgui
import xbmcaddon
import pychromecast
import time
import sys
from urllib.parse import quote


addon = xbmcaddon.Addon(id='context.chromecast')


def cast(url):
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    if addon.getSetting("dev_name") == "":
        services, browser = pychromecast.discovery.discover_chromecasts()
        devices = []
        for x in services:
            devices.append(x.friendly_name)
        pychromecast.discovery.stop_discovery(browser)
        if devices != []:
            choose = xbmcgui.Dialog().select("Zvolte zařízení", devices)
            if choose == -1:
                xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
                sys.exit(1)
            else:
                dev_name = devices[choose]
        else:
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
            xbmcgui.Dialog().notification("Chromecast","Žádné zařízení", xbmcgui.NOTIFICATION_ERROR, 4000, sound = False)
            sys.exit(1)
    else:
        dev_name = addon.getSetting("dev_name")
    chromecasts, browser = pychromecast.get_listed_chromecasts(friendly_names=[dev_name])
    if not chromecasts:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        xbmcgui.Dialog().notification("Chromecast","Zařízení nedostupné", xbmcgui.NOTIFICATION_ERROR, 4000, sound = False)
        sys.exit(1)
    cast = chromecasts[0]
    cast.wait()
    mc = cast.media_controller
    mc.play_media(url, 'video/mp4')
    mc.play()
    time.sleep(1)
    xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
    sys.exit(1)


def main():
    player = xbmc.Player()
    xbmc.executebuiltin('Action(play)')
    while True:
        time.sleep(0.5)
        try:
            url = player.getPlayingFile()
            if url:
                break
        except:
            pass
    player.stop()
    cast(str(url.split("|")[0]))


if (__name__ == "__main__"):
    main()
