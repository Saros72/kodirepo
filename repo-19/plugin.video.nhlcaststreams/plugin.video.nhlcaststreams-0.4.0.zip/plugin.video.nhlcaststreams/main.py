# -*- coding: utf-8 -*-

import sys
import xbmcgui
import xbmcplugin
import xbmcaddon
from urllib.parse import urlencode, quote, urlparse, parse_qsl
import requests
import datetime as dt
import calendar
import time
import json


_url = sys.argv[0]
_handle = int(sys.argv[1])


def get_url(**kwargs):
    return '{0}?{1}'.format(_url, urlencode(kwargs))


addon = xbmcaddon.Addon(id='plugin.video.nhlcaststreams')
login = {"password": addon.getSetting("password"),"email": addon.getSetting("email"), "ipaddress": "192.168.0.100", "deviceId": "02:00:00:00:00:00", "androidId": "00:00"}
res = requests.post("http://api.caststreams.com:2095/login-web", json=login)
data = json.loads(res.content)
if data["status"] == "success":
    addon.setSetting("token", data["token"])
    headers = {"accept":"application/json;charset=UTF-8",  "authorization": data["token"]}
else:
    xbmcgui.Dialog().notification("NHL CastStreams","Nesprávné přihlašovací údaje", xbmcgui.NOTIFICATION_ERROR, 3000)
    sys.exit()


def play_live(link):
    stream = requests.get("http://api.caststreams.com:2095/getGame?isjson=yes&rUrl=" + link, headers=headers).json()["link"]
    listitem = xbmcgui.ListItem(path=stream)
    xbmcplugin.setResolvedUrl(_handle, True, listitem)


def play_recent(link):
    stream = link.replace("wired_web", "wired60")
    listitem = xbmcgui.ListItem(path=stream)
    xbmcplugin.setResolvedUrl(_handle, True, listitem)


def add_one_hours(time_string):
    time_string = "01.01.2021 " + time_string
    the_time = calendar.timegm(time.strptime(time_string, "%d.%m.%Y %H:%M"))
    new_time = dt.datetime.fromtimestamp(the_time).strftime('%H:%M')
    return new_time


def list_team(team, icon):
    response = requests.get("http://api.caststreams.com:2095/videos?team=" + team, headers=headers).json()["videos"]
    name_list = []
    for r in response:
        d = r["desc"].split("-")
        date = d[2] + "." + d[1] + "." + d[0]
        name_list.append((r["name"] + " (" + date + ")", r["url"][0]))
    for category in name_list:
        list_item = xbmcgui.ListItem(label=category[0])
        list_item.setArt({'thumb': icon , 'icon': icon})
        list_item.setInfo('video', {'mediatype' : 'videos', 'title': category[0], "year": "2019", "genre": "Sportovní"})
        list_item.setProperty('IsPlayable', 'true')
        url = get_url(action='play_recent', link = category[1])
        xbmcplugin.addDirectoryItem(_handle, url, list_item, False)
    xbmcplugin.endOfDirectory(_handle)


def list_teams():
    name_list = [("Anaheim", "ANA"), ("Arizona", "ARI"), ("Boston", "BOS"), ("Buffalo", "BUF"), ("Calgary", "CGY"), ("Carolina", "CAR"), ("Chicago", "CHI"), ("Colorado", "COL"), ("Columbus", "CBJ"), ("Dallas", "DAL"), ("Detroit", "DET"), ("Edmonton", "EDM"), ("Florida", "FLA"), ("Lasvegas", "VGK"), ("LosAngeles", "LAK"), ("Minnesota", "MIN"), ("Montreal", "MTL"), ("Nashville", "NSH"), ("NewJersey", "NJD"), ("NyIslanders", "NYI"), ("NyRangers", "NYR"), ("Ottawa", "OTT"), ("Philadelphia", "PHI"), ("Pittsburgh", "PIT"), ("SanJose", "SJS"), ("StLouis", "STL"), ("TampaBay", "TBL"), ("Toronto", "TOR"), ("Vancouver", "VAN"), ("Washington", "WSH"), ("Winnipeg", "WPG")]
    for category in name_list:
        list_item = xbmcgui.ListItem(label=category[0])
        list_item.setArt({'thumb': "https://www.caststreams.com/images/" + category[0].lower() + ".png" , 'icon': "https://www.caststreams.com/images/" + category[0].lower() + ".png"})
        list_item.setInfo('video', {'mediatype' : 'videos', 'title': category[0], "year": "2021", "genre": "Sportovní"})
        url = get_url(action='listing_team', team = category[1], icon = "https://www.caststreams.com/images/" + category[0].lower() + ".png")
        xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    xbmcplugin.endOfDirectory(_handle)


def list_recent():
    response = requests.get("http://api.caststreams.com:2095/videos", headers=headers).json()["videos"]
    name_list = []
    for r in response:
        d = r["desc"].split("-")
        date = d[2] + "." + d[1] + "." + d[0]
        name_list.append((r["name"] + " (" + date + ")", r["url"][0]))
    for category in name_list:
        list_item = xbmcgui.ListItem(label=category[0])
        list_item.setInfo('video', {'mediatype' : 'videos', 'title': category[0], "year": "2021", "genre": "Sportovní"})
        list_item.setProperty('IsPlayable', 'true')
        url = get_url(action='play_recent', link = category[1])
        xbmcplugin.addDirectoryItem(_handle, url, list_item, False)
    xbmcplugin.endOfDirectory(_handle)


def list_live():
    response = requests.get("http://api.caststreams.com:2095/feeds", headers=headers).json()["feeds"]
    name_list = []
    for r in response:
        if addon.getSetting("all_streams") == "false":
            if (r["desc"].find('free') != -1):
                d = r["udate"].split(" ")[4][:5]
                name_list.append((r["name"] + " (" + add_one_hours(d) + ") [" + r["desc"].split(" ", 1)[1] + "]", r["url"][0]))
        else:
            d = r["udate"].split(" ")[4][:5]
            name_list.append((r["name"] + " (" + add_one_hours(d) + ") [" + r["desc"].split(" ", 1)[1] + "]", r["url"][0]))
    for category in name_list:
        list_item = xbmcgui.ListItem(label=category[0])
        list_item.setInfo('video', {'mediatype' : 'videos', 'title': category[0], "year": "2021", "genre": "Sportovní"})
        list_item.setProperty('IsPlayable', 'true')
        url = get_url(action='play_live', link = category[1])
        xbmcplugin.addDirectoryItem(_handle, url, list_item, False)
    xbmcplugin.endOfDirectory(_handle)


def list_menu():
    name_list = [("Živě", "listing_live"), ("Poslední", "listing_recent"), ("Týmy", "listing_teams")]
    for category in name_list:
        list_item = xbmcgui.ListItem(label=category[0])
        url = get_url(action=category[1])
        xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    xbmcplugin.endOfDirectory(_handle)


def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if params:
        if params["action"] == "listing_live":
            list_live()
        if params["action"] == "listing_recent":
            list_recent()
        if params["action"] == "listing_teams":
            list_teams()
        if params["action"] == "listing_team":
            list_team(params["team"], params["icon"])
        elif params["action"] == "play_live":
            play_live(params["link"])
        elif params["action"] == "play_recent":
            play_recent(params["link"])
    else:
        list_menu()


if __name__ == '__main__':
    router(sys.argv[2][1:])
