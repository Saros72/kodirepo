# -*- coding: utf-8 -*-

import sys
import os
import xbmcaddon
import xbmcgui
import xbmc
import json
import requests
import xbmcvfs
import xml.etree.ElementTree as ET


addon = xbmcaddon.Addon(id='script.365.epg.generator')
userpath = addon.getAddonInfo('profile')
custom_channels = xbmcvfs.translatePath("%s/custom_channels.txt" % userpath)
custom_channels_tm = xbmcvfs.translatePath("%s/custom_channels_tm.txt" % userpath)
custom_channels_o2 = xbmcvfs.translatePath("%s/custom_channels_o2.txt" % userpath)
custom_channels_mujtv = xbmcvfs.translatePath("%s/custom_channels_mujtv.txt" % userpath)
custom_channels_es = xbmcvfs.translatePath("%s/custom_channels_es.txt" % userpath)
custom_channels_stv = xbmcvfs.translatePath("%s/custom_channels_stv.txt" % userpath)
custom_channels_stvsk = xbmcvfs.translatePath("%s/custom_channels_stvsk.txt" % userpath)
custom_channels_mag = xbmcvfs.translatePath("%s/custom_channels_mag.txt" % userpath)
custom_channels_tvspiel = xbmcvfs.translatePath("%s/custom_channels_tvspiel.txt" % userpath)
custom_channels_ottplay = xbmcvfs.translatePath("%s/custom_channels_ottplay.txt" % userpath)
channels_select_path = xbmcvfs.translatePath(userpath + "/channels.json")
if not xbmcvfs.exists(userpath):
    xbmcvfs.mkdir(userpath)


def select():
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    category = {"České": "CZ", "Slovenské": "SK", "Polské": "PL", "Německé": "DE", "Anglické": "EN", "Francouzské": "FR", "Maďarské": "HU", "Ruské": "RU", "Španělské": "ES", "Italské": "IT", "Ostatní": "", "T-Mobile TV GO": "TM", "Magio GO": "MAG", "O2 TV Sport": "O2", "můjTVprogram.cz": "MTV", "Eurosport": "ES", "SledovaniTV.cz": "STV", "SledovanieTV.sk": "STVSK", "TV Spiel": "SPIEL", "OTT Play": "OTT"}
    if category[sys.argv[1]] == "TM":
        params={"dsid": "c75536831e9bdc93", "deviceName": "Redmi Note 7", "deviceType": "OTT_ANDROID", "osVersion": "10", "appVersion": "3.7.0", "language": "CZ"}
        headers={"Host": "czgo.magio.tv", "authorization": "Bearer", "User-Agent": "okhttp/3.12.12", "content-type":  "application/json", "Connection": "Keep-Alive"}
        req = requests.post("https://czgo.magio.tv/v2/auth/init", params=params, headers=headers, verify=True).json()
        token = req["token"]["accessToken"]
        headers2={"Host": "czgo.magio.tv", "authorization": "Bearer " + token, "User-Agent": "okhttp/3.12.12", "content-type":  "application/json"}
        req1 = requests.get("https://czgo.magio.tv/v2/television/channels?list=LIVE&queryScope=LIVE", headers=headers2).json()["items"]
        tm_channels = {}
        for y in req1:
            name = y["channel"]["name"]
            id = str(y["channel"]["channelId"])
            tm_channels[name.replace(" HD", "")] = id
        channels = list(tm_channels.keys())
        sorted(channels)
    elif category[sys.argv[1]] == "MAG":
        params={"dsid": "c75536831e9bdc93", "deviceName": "Redmi Note 7", "deviceType": "OTT_ANDROID", "osVersion": "10", "appVersion": "3.7.0", "language": "SK"}
        headers={"Host": "skgo.magio.tv", "authorization": "Bearer", "User-Agent": "okhttp/3.12.12", "content-type":  "application/json", "Connection": "Keep-Alive"}
        req = requests.post("https://skgo.magio.tv/v2/auth/init", params=params, headers=headers, verify=True).json()
        token = req["token"]["accessToken"]
        headers2={"Host": "skgo.magio.tv", "authorization": "Bearer " + token, "User-Agent": "okhttp/3.12.12", "content-type":  "application/json"}
        req1 = requests.get("https://skgo.magio.tv/v2/television/channels?list=LIVE&queryScope=LIVE", headers=headers2).json()["items"]
        mag_channels = {}
        for y in req1:
            name = y["channel"]["name"]
            id = str(y["channel"]["channelId"])
            mag_channels[name.replace(" HD", "")] = id
        channels = list(mag_channels.keys())
        sorted(channels)
    elif category[sys.argv[1]] == "O2":
        o2_channels = {"O2 Sport": "O2 Sport HD", "O2 Fotbal": "O2 Fotbal HD", "O2 Tenis": "O2 Tenis HD", "O2 Sport1": "O2 Sport1 HD", "O2 Sport2": "O2 Sport2 HD", "O2 Sport3": "O2 Sport3 HD", "O2 Sport4": "O2 Sport4 HD", "O2 Sport5": "O2 Sport5 HD", "O2 Sport6": "O2 Sport6 HD", "O2 Sport7": "O2 Sport7 HD", "O2 Sport8": "O2 Sport8 HD"}
        channels = list(o2_channels.keys())
        sorted(channels)
    elif category[sys.argv[1]] == "MTV":
        mujtv_channels = {'Skylink 7': '723', 'Stingray Classica': '233', 'Stingray iConcerts': '234', 'Stingray CMusic': '110', 'ORF1': '40', 'ORF2': '41', 'RTL': '49', 'RTL2': '50', 'Polsat': '39', 'TVP1': '37', 'TVP2': '38', 'Pro7': '174', 'SAT1': '52', 'Kabel1': '54', 'VOX': '53', 'ZDF': '393', 'ZDF Neo': '216', '3SAT': '46', 'SAT.1 GOLD': '408', 'Vixen': '892', 'Canal+ Sport': '1040'}
        channels = list(mujtv_channels.keys())
        sorted(channels)
    elif category[sys.argv[1]] == "ES":
        es_channels = {"Eurosport 3": "Eurosport3", "Eurosport 4": "Eurosport4", "Eurosport 5": "Eurosport5"}
        channels = list(es_channels.keys())
        sorted(channels)
    elif category[sys.argv[1]] == "STV":
        stv_channels = {'ČT1': 'ct1', 'ČT2': 'ct2', 'ČT24': 'ct24', 'Déčko': 'ctdecko', 'ČT art': 'ctart', 'ČT Sport': 'ct4sport', 'Nova': 'nova', 'Nova Fun': 'smichov', 'Nova Cinema': 'novacinema', 'Nova Action': 'fanda', 'Nova Gold': 'telka', 'Prima': 'primafamily', 'Prima COOL': 'primacool', 'Prima Max': 'prima_max', 'Prima Krimi': 'prima_krimi', 'Prima Zoom': 'primazoom', 'Prima Love': 'primalove', 'Paramount Network': 'primacomedy', 'TV Barrandov': 'barrandov', 'Kino Barrandov': 'kinobarrandov', 'Barrandov Krimi': 'barrandovplus', 'JOJ Family': 'jojfamily', 'Televize Seznam': 'Seznam', 'Óčko': 'ocko', 'Óčko STAR': 'ockogold', 'Óčko Expres': 'ocko_express', 'Jednotka': 'stv1', 'Dvojka': 'stv2', 'Markíza International': 'markizaint', 'TA3': 'ta3', 'Arena sport 2': 'slovak_sport2', 'Retro': 'retro', 'Life TV': 'TVlife', 'Polar': 'Polar', 'TVS': 'slovacko', 'V1 TV': 'v1tv', 'TV Brno 1': 'brno1', 'OIK TV': 'oik', 'regionalnitelevize.cz': 'regiotv', 'i-Vysočina': 'ivysocina_stream_zs', 'TV Noe': 'tvnoe', 'Šláger Originál': 'slagr', 'ORF eins': 'orf1', 'ORF zwei': 'orf2', 'UA TV': 'uatv', 'France 24': 'france24', 'France 24 (FR)': 'france24_fr', 'TV Mňam': 'mnamtv', 'TV Mňau': 'mnau', 'Filmpro': 'filmpro', 'Krb': 'fireplace', 'Rádio 1': 'radio_1', 'Rádio Country': 'radio_country', 'Kiss': 'radio_kiss', 'Rádio Spin': 'radio_spin', 'Signál rádio': 'radio_signal', 'Evropa 2': 'radio_evropa2', 'Fajn Radio': 'radio_fajn', 'Černá Hora': 'radio_cernahora', 'NON-STOP rádio': 'radio_nonstop', 'Rádio BEAT': 'radio_beat', 'Krokodýl': 'radio_krokodyl', 'ČRo Radiožurnál': 'radio_cro1', 'ČRo Dvojka': 'radio_cro2', 'ČRo Vltava': 'radio_cro3', 'ČRo Plus': 'radio_cro6', 'Free Rádio': 'radio_free', 'ČRo Radio Wave': 'radio_wave', 'ČRo D-Dur': 'radio_ddur', 'ČRo Jazz': 'radio_jazz', 'Radio Dechovka': 'radio_dechovka', 'ČRo Radio Praha': 'radio_praha', 'ČRo Junior': 'radio_junior', 'Rádio Slovensko': 'radio_slovensko', 'Rádio Regina Západ': 'radio_regina_sk', 'Rádio Devín': 'radio_devin', 'Rádio FM': 'radio_fm', 'Rádio Vlna': 'radio_vlna', 'Rádio Jemné': 'radio_jemne', 'Rádio Lumen': 'radio_lumen', 'Rádio Expres': 'radio_expres', 'Rádio Best FM': 'radio_bestfm', 'Rádio Fun': 'radio_fun', 'Rádio Patria': 'radio_patria', 'Proglas': 'radio_proglas', 'ČRo Brno': 'radio_brno', 'ČRo České Budějovice': 'radio_ceskebudejovice', 'Radio WOW': 'radio_wow_sk', 'ČRo Hradec Králové': 'radio_hk', 'ČRo Olomouc': 'radio_olomouc', 'ČRo Ostrava': 'radio_ostrava', 'ČRo Pardubice': 'radio_pardubice', 'ČRo Plzeň': 'radio_plzen', 'ČRo Region - Středočeský kraj': 'radio_region', 'ČRo Region - Vysočina': 'radio_vysocina', 'ČRo Sever': 'radio_sever', 'ČRo Sever - Liberec': 'radio_liberec', 'ČRo Regina': 'radio_regina', 'Prima Show': 'prima_show', 'ČT3': 'ct3', 'ČT1 JM': 'ct1jm', 'ČT1 SM': 'ct1sm', 'CNN Prima News': 'prima_news', 'Prima Star': 'prima_star', 'Nova Lady': 'nova_lady', 'Trojka': 'stv3', 'RTVS :24': 'stv24', 'Travelxp': 'travelxp', 'Arcadia World': 'arcadia', 'NASA TV': 'nasatv', 'NASA TV UHD': 'nasatv_uhd', 'Arena sport 1': 'slovak_sport', 'Šláger Premium HD': 'slagr_premium', 'Šláger Muzika': 'slagr2', 'Nickelodeon Ukraine': 'nickelodeon_pluto_ua', 'Rik': 'rik2', 'ZAK TV': 'zaktv', 'Plzeň TV': 'plzen_tv', 'Televize Ústeckého kraje': 'ustecko_tv', 'BBC World': 'bbc', 'Sky News': 'sky_news', 'TV Natura': 'natura', 'TV Lux': 'tv_lux', 'Lounge TV': 'lounge', 'Chuck TV': 'chucktv', 'Hobby TV': 'hobby', 'HaHa TV': 'haha_tv', 'Zoo Brno - Africká vesnice': 'zoo_brno_a_vesnice', 'Zoo Brno - Medvěd kamčatský': 'zoo_brno_m_kamcatsky', 'Zoo Brno - Medvěd lední': 'zoo_brno_m_ledni', 'Zoo Brno - Komentovaná krmení': 'komentovana_krmeni', 'Zoo Brno - Život v zoo': 'zvirata_v_zoo', 'Kladno.1 TV': 'kladno', 'TV Praha': 'praha', 'RTM+ (Liberecko)': 'rtm_plus_liberec', 'TV Beskyd': 'tvbeskyd', 'Galerie zvířat': 'loop_naturetv-galerie-zvirat', 'Ošetřování mláďat': 'loop_naturetv-osetrovani-mladat', 'cms:tv': 'cms_tv', 'Kočičí kavárna': 'uscenes_cat_cafe', 'Korálová zahrada': 'uscenes_coral_garden', 'Panorama TV': 'panorama_tv', 'Pláž': 'uscenes_hammock_beach', 'Noční Praha': 'night_prague', 'Mumlavské vodopády': 'loop_naturetv_mumlava_waterfalls', 'Čapí hnízdo': 'stork_nest', 'Info TV Brno a jižní morava': 'info_tv_brno', 'Krušná TV': 'krusna_tv', 'Epic Drama': 'epic_drama', 'Jihočeská televize': 'jihoceska_televize', 'Tik Bohumín': 'tik_bohumin', 'Regionální televize jižní Čechy': 'rt_jc', 'RT Ústecko': 'rt_ustecko', 'Poslanecká sněmovna ČR': 'pscr', 'Das Erste': 'ard', 'ZDF': 'zdf', '1+1': 'ukraina_24', 'ČRo Pohoda': 'radio_cro_pohoda', 'Rádio Jih': 'radio_jih', 'Rádio Jihlava': 'radio_jihlava', 'Rádio Košice': 'radio_kosice', 'Rádio Regina Východ': 'radio_regina_vy', 'Radio Dychovka': 'radio_dychovka', 'Rádio Orlicko': 'radio_orlicko', 'Impuls': 'radio_impuls', 'Frekvence 1': 'radio_frekvence1', 'Rádio Jih Cimbálka': 'radio_jih_cimbalka', 'JuKej Radio': 'radio_jukej', 'PiGy Disko Trysko': 'radio_pigy_disko', 'PiGy Pohádkové písničky': 'radio_pigy_pisnicky', 'PiGy Pohádky': 'radio_pigy_pohadky', 'Fit family rádio': 'radio_fit_family', 'Radio Z': 'radio_z', 'Radio Čas': 'radio_cas', 'Dance Rádio': 'radio_dance', 'Hitrádio Desítka': 'radio_hit_desitka', 'RadioR': 'radior', 'Rádio Otava': 'radio_blatna', 'Hitradio Osmdesatka': 'radio_hitradio_80', 'Hitradio Devadesátka': 'radio_hitradio_90', 'Hitrádio Faktor': 'radio_hitradio_faktor', 'Hitradio Orion': 'radio_hitradio_orion', 'Hitrádio Dragon': 'radio_hitradio_dragon', 'Hitrádio - Milénium': 'radio_hitradio_milenium', 'Rádio Blaník': 'radio_blanik', 'Rock Rádio': 'radio_rock_radio', 'Hitrádio Contact': 'radio_hitradio_contact', 'Hitrádio Zlín': 'radio_hitradio_zlin', 'ČRo Radiožurnál Sport': 'radio_cro_sport', 'Hitrádio Vysočina': 'radio_hitradio_vysocina', 'Hitrádio City Zóna lásky': 'radio_hitradio_city_zona_lasky', 'ČRo Zlín': 'radio_cro_zlin', 'ČRo Karlovy Vary': 'radio_cro_kv', 'Hitrádio City Brno': 'radio_hitradio_city_brno', 'Radio Color': 'radio_color', 'Hitrádio City 93,7 FM': 'radio_hitradio_city_93-7', 'Hitrádio FM': 'radio_hitradio_fm', 'Radio Hey': 'radio_hey', 'Hitrádio FM Plus': 'radio_hitradio_fm_plus', 'SeeJay': 'seejay', 'Hitrádio FM Crystal': 'radio_hitradio_fm_crystal', 'Hitrádio PopRock': 'radio_hitradio_poprock', 'Helax 93,7': 'radio_helax_93-7', 'Rádio Povídka': 'radio_povidka', 'Rádio Pohádka': 'radio_pohadka', 'Rádio Humor': 'radio_humor', 'Dobré rádio': 'radio_dobre_radio', 'Classic Praha': 'radio_classic_praha', 'Flash radio': 'radio_flash', 'Frekvence 1 - Youradio Československé hity': 'radio_frekvence1_youradio_cr_hity', 'Frekvence 1 - Youradio Legendy': 'radio_frekvence1_youradio_legendy', 'Frekvence 1 - Youradio Osmdesátky': 'radio_frekvence1_youradio_osmdesatky', 'Funkstar Radio': 'radio_funkstar_en', 'Oldies Rádio': 'radio_oldies_radio', 'Rádio Bonton': 'radio_bonton', 'Radio Čas Rock': 'radio_cas_rock', 'Rádio Dálnice': 'radio_dalnice_stream_yq', 'Radio Dixie': 'radio_dixie', 'Rádio Dráťák': 'radio_dratak', 'Radio Haná': 'radio_hana', 'Radio Ostravan': 'radio_ostravan', 'Radio Punctum': 'radio_punctum', 'Rádio Samson': 'radio_samson', 'United Czech Chillers': 'radio_united_czech_chillers', 'Známka Punku': 'radio_znamka_punku', 'Rádio Smile': 'radio_smile', 'Rádio G6 (Gipsy Radio)': 'radio_g6-gipsy_radio', 'Nekonečný šum': 'radio_nekonecny_sum', 'Cartoon Network HD': 'cartoon_network_hd', 'Nova Sport 1': 'nova_sport', 'Nova Sport 2': 'nova_sport2', 'JOJ Cinema': 'jojcinema', 'Óčko HD': 'ockoHD', 'Óčko STAR HD': 'ocko_starHD', 'Óčko EXPRES HD': 'ocko_expresHD', 'Óčko BLACK HD': 'ocko_blackHD', 'HBO': 'HBO', 'HBO 2': 'HBO2', 'HBO 3': 'hbo_comedy', 'Cinemax 1': 'cinemax1', 'Cinemax 2': 'cinemax2', 'FilmBox': 'filmbox', 'Filmbox Extra HD': 'FilmboxHD', 'FilmBox Premium': 'FilmboxExtra', 'FilmBox Family': 'FilmboxFamily', 'DocuBox': 'DocuBoxHD', 'FashionBox': 'FashionboxHD', 'FightBox': 'FightboxHD', 'Fast & Fun Box': 'Fastnfunbox', 'Filmbox Arthouse': 'FilmboxArthouse', 'Filmbox Stars': 'filmboxplus', '360TuneBox': '360TuneBox', 'AXN': 'axn', 'AXN Black': 'axnblack', 'AXN White': 'axnwhite', 'National Geographic Wild': 'nat_geo_wild', 'National Geographic HD': 'NGC_HD', 'Love Nature 4K': 'love_nature', 'Animal Planet': 'animal_planet', 'Travel Channel HD': 'travelhd', 'Spektrum': 'spektrum', 'Viasat History': 'viasat_history', 'Viasat Explore': 'viasat_explore', 'Viasat Nature': 'viasat_nature', 'Eurosport': 'Eurosport', 'Eurosport2': 'Eurosport2', 'Sport1': 'Sport1', 'Sport2': 'Sport2', 'Sport 5': 'sport5', 'Auto Motor Sport': 'auto_motor_sport', 'Fishing&Hunting': 'fishinghunting', 'Golf Channel': 'golf', 'Film Europe': 'Film_Europe', 'Relax': 'pohoda', 'Rebel': 'rebel', 'MTV 00s': 'VH1', 'CS Film': 'cs_film', 'Cartoon Network CZ': 'cartoon_cz', 'Cartoon Network EN': 'cartoon', 'Boomerang': 'boomerang', 'Film Europe + HD': 'Kino_CS', 'Nickelodeon': 'Nickelodeon', 'Nick JR': 'nickjr', 'Disney Channel': 'Disney_Channel', 'Disney Junior': 'disney_junior', 'Jim Jam': 'Jim_Jam', 'Minimax': 'Minimax', 'Baby TV': 'baby_tv', 'Discovery': 'Discovery', 'Discovery : TLC': 'TLC', 'Discovery Science': 'Science', 'Discovery Turbo Xtra': 'world', 'Investigation Discovery': 'ID', 'Crime and Investigation': 'sat_crime_invest', 'History Channel': 'history', 'CNN': 'cnn', 'TV5MONDE': 'tv5', 'Film+': 'film_plus', 'CS Mystery': 'kinosvet', 'AMC': 'amc', 'Deluxe Music': 'deluxe', 'MTV': 'mtv', 'Nick JR EN': 'nick_jr_en', 'CS Horror': 'horor_film', 'Lala TV': 'lala_tv', 'CS History': 'war', 'TV Paprika': 'tv_paprika', 'MTV Hits': 'mtv_hits', 'M1': 'm1', 'M2': 'm2', 'Duna': 'duna', 'Duna World': 'dunaworld', 'Mezzo Live HD': 'mezzo_live', 'Mezzo': 'mezzo', 'Erox': 'eroxHD', 'Eroxxx': 'eroxxxHD', 'X-mo': 'x-mo', 'Dorcel TV': 'DorceltvHD', 'Dorcel XXX': 'DorcelHD', 'Brazzers TV Europe': 'brazzers', 'Playboy TV': 'playboy', 'Leo TV Gold': 'leo_gold', 'LeoTV': 'leo', 'Extasy 4K': 'extasy_4k', 'Extasy': 'extasy', 'Private HD': 'privatetv', 'Reality Kings': 'realitykings', 'True Amateurs': 'true_amateurs', 'Babes TV': 'babes_tv', 'Redlight': 'redlight'}
        channels = list(stv_channels.keys())
        sorted(channels)
    elif category[sys.argv[1]] == "STVSK":
        stvsk_channels = {'Markíza': 'markiza', 'JOJ': 'joj', 'JOJ Plus': 'jojplus', 'Doma': 'doma', 'JOJ Šport': 'joj_sport', 'Dajto': 'dajto', 'Rik': 'rik2', 'Jojko': 'rik', 'WAU': 'wau', 'Nova International': 'novaint', 'Prima PLUS': 'primaplus', 'RTVS Šport': 'stv4', 'Televizia Osem': 'tv_osem', 'M1': 'm1', 'M2': 'm2', 'M4 Sport': 'm4', 'Arcadia World': 'arcadia', 'TV Karpaty': 'karpaty', 'TV Liptov': 'tv_liptov', 'Central': 'tv_central', 'TV Lux': 'tv_lux', 'TV Ružomberok': 'ruzomberok'}
        channels = list(stvsk_channels.keys())
        sorted(channels)
    elif category[sys.argv[1]] == "SPIEL":
        spiel_channels = {'Eurosport 1 (DE)': 'EURO', 'Eurosport 2 (DE)': 'EURO2', 'Sky Sport 1 (DE)': 'HDSPO', 'Sky Sport 2 (DE)': 'SHD2', 'Sky Sport Austria1': 'SPO-A', 'ORF Sport+': 'ORFSP'}
        channels = list(spiel_channels.keys())
        sorted(channels)
    elif category[sys.argv[1]] == "OTT":
        ottplay_channels = {'Penthouse Gold': '7:2777', 'Penthouse Quickies': '7:2779', 'Vivid Red': '7:2528', 'Super Tennis': 'ITbas:SuperTennis.it'}
        channels = list(ottplay_channels.keys())
        sorted(channels)
    else:
        channels = []
        html = requests.get("http://programandroid.365dni.cz/android/v6-tv.php?locale=cs_CZ").text
        root = ET.fromstring(html)
        for i in root.iter('a'):
            if i.attrib["c"] == category[sys.argv[1]]:
                channels.append(i.find('n').text)
    if os.path.exists(channels_select_path):
        f = open(channels_select_path, "r").read()
        data = json.loads(f)
        try:
            ch = data[sys.argv[1].encode().decode("utf-8")][0]
            ch_preselect = []
            for i in ch:
                ch_preselect.append(channels.index(i))
        except:
            ch_preselect = []
    else:
        ch_preselect = []
        data = {}
    repair_channels = []
    xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
    dialog = xbmcgui.Dialog()
    types = dialog.multiselect(sys.argv[1], channels, preselect=ch_preselect)
    if types is None:
        pass
    else:
        for index in types:
            repair_channels.append(channels[index])
        select_channels = []
        if category[sys.argv[1]] == "TM":
            for key, value in tm_channels.items():
                if key in repair_channels:
                    select_channels.append(value)
        elif category[sys.argv[1]] == "MAG":
            for key, value in mag_channels.items():
                if key in repair_channels:
                    select_channels.append(value)
        elif category[sys.argv[1]] == "O2":
            for key, value in o2_channels.items():
                if key in repair_channels:
                    select_channels.append(value)
        elif category[sys.argv[1]] == "MTV":
            for key, value in mujtv_channels.items():
                if key in repair_channels:
                    select_channels.append(value)
        elif category[sys.argv[1]] == "ES":
            for key, value in es_channels.items():
                if key in repair_channels:
                    select_channels.append(value)
        elif category[sys.argv[1]] == "STV":
            for key, value in stv_channels.items():
                if key in repair_channels:
                    select_channels.append(value)
        elif category[sys.argv[1]] == "STVSK":
            for key, value in stvsk_channels.items():
                if key in repair_channels:
                    select_channels.append(value)
        elif category[sys.argv[1]] == "SPIEL":
            for key, value in spiel_channels.items():
                if key in repair_channels:
                    select_channels.append(value)
        elif category[sys.argv[1]] == "OTT":
            for key, value in ottplay_channels.items():
                if key in repair_channels:
                    select_channels.append(value)
        else:
            for i in root.iter('a'):
                if i.find('n').text in repair_channels:
                    select_channels.append(i.attrib["id"])

        ff = open(channels_select_path, "w")
        data[sys.argv[1].encode().decode("utf-8")] = [repair_channels, ",".join(select_channels)]
        json.dump(data, ff)
        ff.close()
        if category[sys.argv[1]] == "TM":
            c_path = custom_channels_tm
            id = data["T-Mobile TV GO"][1]
        elif category[sys.argv[1]] == "MAG":
            c_path = custom_channels_mag
            id = data["Magio GO"][1]
        elif category[sys.argv[1]] == "O2":
            c_path = custom_channels_o2
            id = data["O2 TV Sport"][1]
        elif category[sys.argv[1]] == "MTV":
            c_path = custom_channels_mujtv
            id = data["můjTVprogram.cz"][1]
        elif category[sys.argv[1]] == "ES":
            c_path = custom_channels_es
            id = data["Eurosport"][1]
        elif category[sys.argv[1]] == "STV":
            c_path = custom_channels_stv
            id = data["SledovaniTV.cz"][1]
        elif category[sys.argv[1]] == "STVSK":
            c_path = custom_channels_stvsk
            id = data["SledovanieTV.sk"][1]
        elif category[sys.argv[1]] == "SPIEL":
            c_path = custom_channels_tvspiel
            id = data["TV Spiel"][1]
        elif category[sys.argv[1]] == "OTT":
            c_path = custom_channels_ottplay
            id = data["OTT Play"][1]
        else:
            c_path = custom_channels
            id = []
            for key, value in data.items():
                if key != "T-Mobile TV GO" and key != "Magio GO" and key != "O2 TV Sport" and key != "můjTVprogram.cz" and key != "Eurosport" and key != "SledovaniTV.cz" and key != "SledovanieTV.sk" and key != "TV Spiel" and key != "OTT Play":
                    if value[1] != "":
                        id.append(value[1])
            id = ",".join(id)
        fff = open(c_path, "w")
        fff.write(id)
        fff.close()


if __name__ == "__main__":
    select()