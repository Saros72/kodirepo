# -*- coding: utf-8 -*-

import re
import os
import xbmcgui
import xbmcaddon
import xbmc
import m3u8
import unicodedata
import requests
import xml.etree.ElementTree as ET
from m3u8 import protocol
from m3u8.parser import save_segment_custom_value


addon = xbmcaddon.Addon(id='script.365.epg.generator')
prs = 0


def encode(string):
    if addon.getSetting("diacritics") == "false":
        string = str(unicodedata.normalize('NFKD', string).encode('ascii', 'ignore'), "utf-8")
    return string


def parse_iptv_attributes(line, lineno, data, state):
    if line.startswith(protocol.extinf):
        title = ''
        chunks = line.replace(protocol.extinf + ':', '').rsplit(',', 1)
        if len(chunks) == 2:
            duration_and_props, title = chunks
        elif len(chunks) == 1:
            duration_and_props = chunks[0]

        additional_props = {}
        chunks = duration_and_props.strip().split(' ', 1)
        if len(chunks) == 2:
            duration, raw_props = chunks
            matched_props = re.finditer(r'([\w\-]+)="([^"]*)"', raw_props)
            for match in matched_props:
                additional_props[match.group(1)] = match.group(2)
        else:
            duration = duration_and_props

        if 'segment' not in state:
            state['segment'] = {}
        state['segment']['duration'] = float(duration)
        state['segment']['title'] = title
        save_segment_custom_value(state, 'extinf_props', additional_props)
        state['expect_segment'] = True
        return True


def parse_segments(uri, index, id):
    playlist = '#EXTM3U\n'
    parsed = m3u8.load(uri, custom_tags_parser=parse_iptv_attributes)
    for p in parsed.segments:
        parsed.segments[index].custom_parser_values['extinf_props']['tvg-id'] = id
        tags = p.custom_parser_values['extinf_props']
        t = ""
        for x,y in tags.items():
            t = t + x + '="' + y + '" '
        playlist = playlist + '#EXTINF:-1 ' + t[:-1] + ',' + p.title + '\n' + p.uri + '\n'
    return playlist


def parse_names(uri):
    n = []
    parsed = m3u8.load(uri, custom_tags_parser=parse_iptv_attributes)
    for p in parsed.segments:
        try:
            id = p.custom_parser_values['extinf_props']["tvg-id"]
        except:
            id = ""
        try:
            logo = p.custom_parser_values['extinf_props']["tvg-logo"]
        except:
            logo = ""
        n.append((p.title, id, logo))
    return n


def get_nonexistant_path(fname_path):
    filename, file_extension = os.path.splitext(fname_path)
    new_fname = "{}-{}{}".format(filename, "new", file_extension)
    return new_fname


def save_playlist(uri, index, id):
    new_playlist = parse_segments(uri, index, id)
    f = open(uri, "w", encoding="utf-8")
    f.write(new_playlist)
    f.close()
    channels(uri, index)


def source7(check):
    ch = [('Penthouse Gold', '7:2777', 'http://pics.cbilling.pw/streams/penthouse1-hd.png'), ('Penthouse Quickies', '7:2779', 'http://pics.cbilling.pw/streams/penthouse2-hd.png'), ('Vivid Red', '7:2528', 'http://pics.cbilling.pw/streams/vivid-red-hd.png'), ('Super Tennis', 'ITbas:SuperTennis.it', 'https://guidatv.sky.it/logo/5246supertennishd_Light_Fit.png?checksum=13f5cbb1646d848fde3af6fccba8dd4c')]
    chch = [idx for idx in ch if idx[0][0].lower() == check.lower()]
    ch.sort()
    for c in ch:
        if c not in chch:
            chch.append(c)
    channel = xbmcgui.Dialog().select("OTT Play", [x[0] for x in chch], useDetails=False)
    if channel != -1:
        return chch[channel][1]
    else:
        return None


def source6(check):
    ch = [('Eurosport 1 (DE)', 'EURO', 'http://live.tvspielfilm.de/static/images/channels/large/EURO.png'), ('Eurosport 2 (DE)', 'EURO2', 'http://live.tvspielfilm.de/static/images/channels/large/EURO2.png'), ('Sky Sport 1 (DE)', 'HDSPO', 'http://live.tvspielfilm.de/static/images/channels/large/HDSPO.png'), ('Sky Sport 2 (DE)', 'SHD2', 'http://live.tvspielfilm.de/static/images/channels/large/SHD2.png'), ('Sky Sport Austria1', 'SPO-A', 'http://live.tvspielfilm.de/static/images/channels/large/SPO-A.png'), ('ORF Sport+', 'ORFSP', 'http://live.tvspielfilm.de/static/images/channels/large/ORFSP.png')]
    chch = [idx for idx in ch if idx[0][0].lower() == check.lower()]
    ch.sort()
    for c in ch:
        if c not in chch:
            chch.append(c)
    channel = xbmcgui.Dialog().select("TV Spiel", [x[0] for x in chch], useDetails=False)
    if channel != -1:
        return chch[channel][1]
    else:
        return None


def source5(check):
    ch = [('Eurosport 3', 'eurosport-3', 'http://www.o2tv.cz/assets/images/tv-logos/win/eurosport-3.png'), ('Eurosport 4', 'eurosport-4', 'http://www.o2tv.cz/assets/images/tv-logos/win/eurosport-4.png'), ('Eurosport 5', 'eurosport-5', 'http://www.o2tv.cz/assets/images/tv-logos/win/eurosport-5.png')]
    chch = [idx for idx in ch if idx[0][0].lower() == check.lower()]
    ch.sort()
    for c in ch:
        if c not in chch:
            chch.append(c)
    channel = xbmcgui.Dialog().select("Eurosport", [x[0] for x in chch], useDetails=False)
    if channel != -1:
        return chch[channel][1]
    else:
        return None


def source4(check):
    ch = [('Skylink 7', '723-skylink-7', 'https://services.mujtvprogram.cz/tvprogram2services/services/logoImageDownloader.php?p1=ac6c69625699eaecc9b39f7ea4d69b8c&amp;p2=80'), ('Stingray Classica', '233-stingray-classica', 'https://services.mujtvprogram.cz/tvprogram2services/services/logoImageDownloader.php?p1=661af53f8f3b997611c29f844c7006fd&amp;p2=80'), ('Stingray iConcerts', '234-stingray-iconcerts', 'https://services.mujtvprogram.cz/tvprogram2services/services/logoImageDownloader.php?p1=99c87946872c81f46190c77af7cd1d89&amp;p2=80'), ('Stingray CMusic', '110-stingray-cmusic', 'https://services.mujtvprogram.cz/tvprogram2services/services/logoImageDownloader.php?p1=b323f2ad3200cb938b43bed58dd8fbf9&amp;p2=80'), ('ORF1', '40-orf1', 'https://services.mujtvprogram.cz/tvprogram2services/services/logoImageDownloader.php?p1=422162d3082a84fc97a7fb9b3ad6823f&amp;p2=80'), ('ORF2', '41-orf2', 'https://services.mujtvprogram.cz/tvprogram2services/services/logoImageDownloader.php?p1=477dcc38e54309f5db7aec56b62b4cdf&amp;p2=80'), ('RTL', '49-rtl', 'https://services.mujtvprogram.cz/tvprogram2services/services/logoImageDownloader.php?p1=7cb9005e66956c56fd0671ee79ee2471&amp;p2=80'), ('RTL2', '50-rtl2', 'https://services.mujtvprogram.cz/tvprogram2services/services/logoImageDownloader.php?p1=418e0d04529ea3aaa2bc2c925ddf5982&amp;p2=80'), ('Polsat', '39-polsat', 'https://services.mujtvprogram.cz/tvprogram2services/services/logoImageDownloader.php?p1=f54e290782e8352303cfe43ce949d339&amp;p2=80'), ('TVP1', '37-tvp1', 'https://services.mujtvprogram.cz/tvprogram2services/services/logoImageDownloader.php?p1=770431539d1fa662f705c1c05a0dd943&amp;p2=80'), ('TVP2', '38-tvp2', 'https://services.mujtvprogram.cz/tvprogram2services/services/logoImageDownloader.php?p1=e2ce4065f27ce199f7613f38878cef72&amp;p2=80'), ('Pro7', '174-pro7', 'https://services.mujtvprogram.cz/tvprogram2services/services/logoImageDownloader.php?p1=e23a7fb8caff9ff514f254c43a39d9b6&amp;p2=80'), ('SAT1', '52-sat1', 'https://services.mujtvprogram.cz/tvprogram2services/services/logoImageDownloader.php?p1=97dd916e0164fff141065c3fba71c291&amp;p2=80'), ('Kabel1', '54-kabel1', 'https://services.mujtvprogram.cz/tvprogram2services/services/logoImageDownloader.php?p1=be6dc88dd3c1c243ba4f28cccb8f1d34&amp;p2=80'), ('VOX', '53-vox', 'https://services.mujtvprogram.cz/tvprogram2services/services/logoImageDownloader.php?p1=d2c68d2b145a5f2e20e5c05c20a9679e&amp;p2=80'), ('ZDF', '393-zdf', 'https://services.mujtvprogram.cz/tvprogram2services/services/logoImageDownloader.php?p1=dad48d516fbdb30321564701cc3faa04&amp;p2=80'), ('ZDF Neo', '216-zdf-neo', 'https://services.mujtvprogram.cz/tvprogram2services/services/logoImageDownloader.php?p1=cd5b8935893b0e4cde41bc3720435f14&amp;p2=80'), ('3SAT', '46-3sat', 'https://services.mujtvprogram.cz/tvprogram2services/services/logoImageDownloader.php?p1=58d350c6065d9355a52c6dbc3b31b185&amp;p2=80'), ('SAT.1 GOLD', '408-sat1-gold', ''), ('Vixen', '892-vixen', 'https://services.mujtvprogram.cz/tvprogram2services/services/logoImageDownloader.php?p1=4499ebafb26a915859febcb4306703ca&amp;p2=80')]
    chch = [idx for idx in ch if idx[0][0].lower() == check.lower()]
    ch.sort()
    for c in ch:
        if c not in chch:
            chch.append(c)
    channel = xbmcgui.Dialog().select("můjTVprogram.cz", [x[0] for x in chch], useDetails=False)
    if channel != -1:
        return chch[channel][1]
    else:
        return None


def source3(check):
    ch = [('O2 Sport', 'o2tv-sport', 'http://www.o2tv.cz/assets/images/tv-logos/original/o2-sport-hd.png'), ('O2 Fotbal', 'o2tv-fotbal', 'http://www.o2tv.cz/assets/images/tv-logos/original/o2-tv-fotbal.png'), ('O2 Tenis', 'o2tv-tenis', 'http://www.o2tv.cz/assets/images/tv-logos/original/o2-tv-tenis.png'), ('O2 Sport1', 'o2tv-sport1', 'http://www.o2tv.cz/assets/images/tv-logos/original/o2-sport-hd.png'), ('O2 Sport2', 'o2tv-sport2', 'http://www.o2tv.cz/assets/images/tv-logos/original/o2-sport-hd.png'), ('O2 Sport3', 'o2tv-sport3', 'http://www.o2tv.cz/assets/images/tv-logos/original/o2-sport-hd.png'), ('O2 Sport4', 'o2tv-sport4', 'http://www.o2tv.cz/assets/images/tv-logos/original/o2-sport-hd.png'), ('O2 Sport5', 'o2tv-sport5', 'http://www.o2tv.cz/assets/images/tv-logos/original/o2-sport-hd.png'), ('O2 Sport6', 'o2tv-sport6', 'http://www.o2tv.cz/assets/images/tv-logos/original/o2-sport-hd.png'), ('O2 Sport7', 'o2tv-sport7', 'http://www.o2tv.cz/assets/images/tv-logos/original/o2-sport-hd.png'), ('O2 Sport8', 'o2tv-sport8', 'http://www.o2tv.cz/assets/images/tv-logos/original/o2-sport-hd.png')]
    chch = [idx for idx in ch if idx[0][0].lower() == check.lower()]
    ch.sort()
    for c in ch:
        if c not in chch:
            chch.append(c)
    channel = xbmcgui.Dialog().select("O2 TV Sport", [x[0] for x in chch], useDetails=False)
    if channel != -1:
        return chch[channel][1]
    else:
        return None


def source2(check, lng):
    if lng == "cz":
        ch = [('ČT1', 'stv-ct1', 'https://sledovanitv.cz/cache/biglogos/ct1.png'), ('ČT2', 'stv-ct2', 'https://sledovanitv.cz/cache/biglogos/ct2.png'), ('ČT3', 'stv-ct3', 'https://sledovanitv.cz/cache/biglogos/ct3.png'), ('ČT24', 'stv-ct24', 'https://sledovanitv.cz/cache/biglogos/ct24.png'), ('Déčko', 'stv-ctdecko', 'https://sledovanitv.cz/cache/biglogos/ctdecko.png'), ('ČT art', 'stv-ctart', 'https://sledovanitv.cz/cache/biglogos/ctart.png'), ('ČT Sport', 'stv-ct4sport', 'https://sledovanitv.cz/cache/biglogos/ct4sport.png'), ('Nova', 'stv-nova', 'https://sledovanitv.cz/cache/biglogos/nova.png'), ('Nova Cinema', 'stv-novacinema', 'https://sledovanitv.cz/cache/biglogos/novacinema.png'), ('Nova Action', 'stv-fanda', 'https://sledovanitv.cz/cache/biglogos/fanda.png'), ('Nova Fun', 'stv-smichov', 'https://sledovanitv.cz/cache/biglogos/smichov.png'), ('Nova Lady', 'stv-nova_lady', 'https://sledovanitv.cz/cache/biglogos/nova_lady.png'), ('Nova Gold', 'stv-telka', 'https://sledovanitv.cz/cache/biglogos/telka.png'), ('Prima', 'stv-primafamily', 'https://sledovanitv.cz/cache/biglogos/primafamily.png'), ('Prima COOL', 'stv-primacool', 'https://sledovanitv.cz/cache/biglogos/primacool.png'), ('Prima Max', 'stv-prima_max', 'https://sledovanitv.cz/cache/biglogos/prima_max.png'), ('Prima Love', 'stv-primalove', 'https://sledovanitv.cz/cache/biglogos/primalove.png'), ('Prima Krimi', 'stv-prima_krimi', 'https://sledovanitv.cz/cache/biglogos/prima_krimi.png'), ('Prima Show', 'stv-prima_show', 'https://sledovanitv.cz/cache/biglogos/prima_show.png'), ('Prima Star', 'stv-prima_star', 'https://sledovanitv.cz/cache/biglogos/prima_star.png'), ('Prima Zoom', 'stv-primazoom', 'https://sledovanitv.cz/cache/biglogos/primazoom.png'), ('CNN Prima News', 'stv-prima_news', 'https://sledovanitv.cz/cache/biglogos/prima_news.png'), ('Paramount Network', 'stv-primacomedy', 'https://sledovanitv.cz/cache/biglogos/primacomedy.png'), ('TV Barrandov', 'stv-barrandov', 'https://sledovanitv.cz/cache/biglogos/barrandov.png'), ('Barrandov Krimi', 'stv-barrandovplus', 'https://sledovanitv.cz/cache/biglogos/barrandovplus.png'), ('Kino Barrandov', 'stv-kinobarrandov', 'https://sledovanitv.cz/cache/biglogos/kinobarrandov.png'), ('Televize Seznam', 'stv-Seznam', 'https://sledovanitv.cz/cache/biglogos/Seznam.png'), ('Relax', 'stv-pohoda', 'https://sledovanitv.cz/cache/biglogos/pohoda.png'), ('TV Noe', 'stv-tvnoe', 'https://sledovanitv.cz/cache/biglogos/tvnoe.png'), ('Jednotka', 'stv-stv1', 'https://sledovanitv.cz/cache/biglogos/stv1.png'), ('Dvojka', 'stv-stv2', 'https://sledovanitv.cz/cache/biglogos/stv2.png'), ('Trojka', 'stv-stv3', 'https://sledovanitv.cz/cache/biglogos/stv3.png'), ('Markíza International', 'stv-markizaint', 'https://sledovanitv.cz/cache/biglogos/markizaint.png'), ('JOJ Family', 'stv-jojfamily', 'https://sledovanitv.cz/cache/biglogos/jojfamily.png'), ('TA3', 'stv-ta3', 'https://sledovanitv.cz/cache/biglogos/ta3.png'), ('TV Lux', 'stv-tv_lux', 'https://sledovanitv.cz/cache/biglogos/tv_lux.png'), ('Life TV', 'stv-TVlife', 'https://sledovanitv.cz/cache/biglogos/TVlife.png'), ('HBO', 'stv-HBO', 'https://sledovanitv.cz/cache/biglogos/HBO.png'), ('HBO 2', 'stv-HBO2', 'https://sledovanitv.cz/cache/biglogos/HBO2.png'), ('HBO 3', 'stv-hbo_comedy', 'https://sledovanitv.cz/cache/biglogos/hbo_comedy.png'), ('Cinemax 1', 'stv-cinemax1', 'https://sledovanitv.cz/cache/biglogos/cinemax1.png'), ('Cinemax 2', 'stv-cinemax2', 'https://sledovanitv.cz/cache/biglogos/cinemax2.png'), ('JOJ Cinema', 'stv-jojcinema', 'https://sledovanitv.cz/cache/biglogos/jojcinema.png'), ('AMC', 'stv-amc', 'https://sledovanitv.cz/cache/biglogos/amc.png'), ('Film+', 'stv-film_plus', 'https://sledovanitv.cz/cache/biglogos/film_plus.png'), ('FilmBox', 'stv-filmbox', 'https://sledovanitv.cz/cache/biglogos/filmbox.png'), ('Filmbox Extra HD', 'stv-FilmboxHD', 'https://sledovanitv.cz/cache/biglogos/FilmboxHD.png'), ('FilmBox Premium', 'stv-FilmboxExtra', 'https://sledovanitv.cz/cache/biglogos/FilmboxExtra.png'), ('Filmbox Stars', 'stv-filmboxplus', 'https://sledovanitv.cz/cache/biglogos/filmboxplus.png'), ('FilmBox Family', 'stv-FilmboxFamily', 'https://sledovanitv.cz/cache/biglogos/FilmboxFamily.png'), ('Filmbox Arthouse', 'stv-FilmboxArthouse', 'https://sledovanitv.cz/cache/biglogos/FilmboxArthouse.png'), ('Film Europe', 'stv-Film_Europe', 'https://sledovanitv.cz/cache/biglogos/Film_Europe.png'), ('Film Europe + HD', 'stv-Kino_CS', 'https://sledovanitv.cz/cache/biglogos/Kino_CS.png'), ('AXN', 'stv-axn', 'https://sledovanitv.cz/cache/biglogos/axn.png'), ('AXN White', 'stv-axnwhite', 'https://sledovanitv.cz/cache/biglogos/axnwhite.png'), ('AXN Black', 'stv-axnblack', 'https://sledovanitv.cz/cache/biglogos/axnblack.png'), ('CS Film', 'stv-cs_film', 'https://sledovanitv.cz/cache/biglogos/cs_film.png'), ('CS Horror', 'stv-horor_film', 'https://sledovanitv.cz/cache/biglogos/horor_film.png'), ('HaHa TV', 'stv-haha_tv', 'https://sledovanitv.cz/cache/biglogos/haha_tv.png'), ('Spektrum', 'stv-spektrum', 'https://sledovanitv.cz/cache/biglogos/spektrum.png'), ('National Geographic HD', 'stv-NGC_HD', 'https://sledovanitv.cz/cache/biglogos/NGC_HD.png'), ('National Geographic Wild', 'stv-nat_geo_wild', 'https://sledovanitv.cz/cache/biglogos/nat_geo_wild.png'), ('Animal Planet', 'stv-animal_planet', 'https://sledovanitv.cz/cache/biglogos/animal_planet.png'), ('Discovery', 'stv-Discovery', 'https://sledovanitv.cz/cache/biglogos/Discovery.png'), ('Discovery Science', 'stv-Science', 'https://sledovanitv.cz/cache/biglogos/Science.png'), ('Discovery Turbo Xtra', 'stv-world', 'https://sledovanitv.cz/cache/biglogos/world.png'), ('Investigation Discovery', 'stv-ID', 'https://sledovanitv.cz/cache/biglogos/ID.png'), ('Discovery : TLC', 'stv-TLC', 'https://sledovanitv.cz/cache/biglogos/TLC.png'), ('Crime and Investigation', 'stv-sat_crime_invest', 'https://sledovanitv.cz/cache/biglogos/sat_crime_invest.png'), ('History Channel', 'stv-history', 'https://sledovanitv.cz/cache/biglogos/history.png'), ('Viasat Explore', 'stv-viasat_explore', 'https://sledovanitv.cz/cache/biglogos/viasat_explore.png'), ('Viasat History', 'stv-viasat_history', 'https://sledovanitv.cz/cache/biglogos/viasat_history.png'), ('Viasat Nature', 'stv-viasat_nature', 'https://sledovanitv.cz/cache/biglogos/viasat_nature.png'), ('Love Nature', 'stv-love_nature', 'https://sledovanitv.cz/cache/biglogos/love_nature.png'), ('Travelxp', 'stv-travelxp', 'https://sledovanitv.cz/cache/biglogos/travelxp.png'), ('Travel Channel HD', 'stv-travelhd', 'https://sledovanitv.cz/cache/biglogos/travelhd.png'), ('Fishing&Hunting', 'stv-fishinghunting', 'https://sledovanitv.cz/cache/biglogos/fishinghunting.png'), ('CS Mystery', 'stv-kinosvet', 'https://sledovanitv.cz/cache/biglogos/kinosvet.png'), ('CS History', 'stv-war', 'https://sledovanitv.cz/cache/biglogos/war.png'), ('TV Paprika', 'stv-tv_paprika', 'https://sledovanitv.cz/cache/biglogos/tv_paprika.png'), ('TV Mňam', 'stv-mnamtv', 'https://sledovanitv.cz/cache/biglogos/mnamtv.png'), ('Hobby TV', 'stv-hobby', 'https://sledovanitv.cz/cache/biglogos/hobby.png'), ('TV Natura', 'stv-natura', 'https://sledovanitv.cz/cache/biglogos/natura.png'), ('DocuBox', 'stv-DocuBoxHD', 'https://sledovanitv.cz/cache/biglogos/DocuBoxHD.png'), ('FashionBox', 'stv-FashionboxHD', 'https://sledovanitv.cz/cache/biglogos/FashionboxHD.png'), ('NASA TV', 'stv-nasatv', 'https://sledovanitv.cz/cache/biglogos/nasatv.png'), ('NASA TV UHD', 'stv-nasatv_uhd', 'https://sledovanitv.cz/cache/biglogos/nasatv_uhd.png'), ('Eurosport', 'stv-Eurosport', 'https://sledovanitv.cz/cache/biglogos/Eurosport.png'), ('Eurosport2', 'stv-Eurosport2', 'https://sledovanitv.cz/cache/biglogos/Eurosport2.png'), ('Sport1', 'stv-Sport1', 'https://sledovanitv.cz/cache/biglogos/Sport1.png'), ('Sport2', 'stv-Sport2', 'https://sledovanitv.cz/cache/biglogos/Sport2.png'), ('Nova Sport 1', 'stv-nova_sport', 'https://sledovanitv.cz/cache/biglogos/nova_sport.png'), ('Nova Sport 2', 'stv-nova_sport2', 'https://sledovanitv.cz/cache/biglogos/nova_sport2.png'), ('Arena sport 1', 'stv-slovak_sport', 'https://sledovanitv.cz/cache/biglogos/slovak_sport.png'), ('Arena sport 2', 'stv-slovak_sport2', 'https://sledovanitv.cz/cache/biglogos/slovak_sport2.png'), ('Sport 5', 'stv-sport5', 'https://sledovanitv.cz/cache/biglogos/sport5.png'), ('Auto Motor Sport', 'stv-auto_motor_sport', 'https://sledovanitv.cz/cache/biglogos/auto_motor_sport.png'), ('Golf Channel', 'stv-golf', 'https://sledovanitv.cz/cache/biglogos/golf.png'), ('FightBox', 'stv-FightboxHD', 'https://sledovanitv.cz/cache/biglogos/FightboxHD.png'), ('Chuck TV', 'stv-chucktv', 'https://sledovanitv.cz/cache/biglogos/chucktv.png'), ('Fast & Fun Box', 'stv-Fastnfunbox', 'https://sledovanitv.cz/cache/biglogos/Fastnfunbox.png'), ('Lala TV', 'stv-lala_tv', 'https://sledovanitv.cz/cache/biglogos/lala_tv.png'), ('Rik', 'stv-rik2', 'https://sledovanitv.cz/cache/biglogos/rik2.png'), ('Jim Jam', 'stv-Jim_Jam', 'https://sledovanitv.cz/cache/biglogos/Jim_Jam.png'), ('Nickelodeon', 'stv-Nickelodeon', 'https://sledovanitv.cz/cache/biglogos/Nickelodeon.png'), ('Nicktoons', 'stv-nicktoons', 'https://sledovanitv.cz/cache/biglogos/nicktoons.png'), ('Nick JR', 'stv-nickjr', 'https://sledovanitv.cz/cache/biglogos/nickjr.png'), ('Nick JR EN', 'stv-nick_jr_en', 'https://sledovanitv.cz/cache/biglogos/nick_jr_en.png'), ('Minimax', 'stv-Minimax', 'https://sledovanitv.cz/cache/biglogos/Minimax.png'), ('Disney Channel', 'stv-Disney_Channel', 'https://sledovanitv.cz/cache/biglogos/Disney_Channel.png'), ('Disney Junior', 'stv-disney_junior', 'https://sledovanitv.cz/cache/biglogos/disney_junior.png'), ('Cartoon Network CZ', 'stv-cartoon_cz', 'https://sledovanitv.cz/cache/biglogos/cartoon_cz.png'), ('Cartoon Network HD', 'stv-cartoon_network_hd', 'https://sledovanitv.cz/cache/biglogos/cartoon_network_hd.png'), ('Cartoon Network EN', 'stv-cartoon', 'https://sledovanitv.cz/cache/biglogos/cartoon.png'), ('Boomerang', 'stv-boomerang', 'https://sledovanitv.cz/cache/biglogos/boomerang.png'), ('Baby TV', 'stv-baby_tv', 'https://sledovanitv.cz/cache/biglogos/baby_tv.png'), ('Óčko HD', 'stv-ockoHD', 'https://sledovanitv.cz/cache/biglogos/ockoHD.png'), ('Óčko STAR HD', 'stv-ocko_starHD', 'https://sledovanitv.cz/cache/biglogos/ocko_starHD.png'), ('Óčko EXPRES HD', 'stv-ocko_expresHD', 'https://sledovanitv.cz/cache/biglogos/ocko_expresHD.png'), ('Óčko BLACK HD', 'stv-ocko_blackHD', 'https://sledovanitv.cz/cache/biglogos/ocko_blackHD.png'), ('Retro', 'stv-retro', 'https://sledovanitv.cz/cache/biglogos/retro.png'), ('Rebel', 'stv-rebel', 'https://sledovanitv.cz/cache/biglogos/rebel.png'), ('MTV', 'stv-mtv', 'https://sledovanitv.cz/cache/biglogos/mtv.png'), ('MTV Hits', 'stv-mtv_hits', 'https://sledovanitv.cz/cache/biglogos/mtv_hits.png'), ('360TuneBox', 'stv-360TuneBox', 'https://sledovanitv.cz/cache/biglogos/360TuneBox.png'), ('Deluxe Music', 'stv-deluxe', 'https://sledovanitv.cz/cache/biglogos/deluxe.png'), ('Lounge TV', 'stv-lounge', 'https://sledovanitv.cz/cache/biglogos/lounge.png'), ('iConcerts', 'stv-i_concerts', 'https://sledovanitv.cz/cache/biglogos/i_concerts.png'), ('Mezzo', 'stv-mezzo', 'https://sledovanitv.cz/cache/biglogos/mezzo.png'), ('Mezzo Live HD', 'stv-mezzo_live', 'https://sledovanitv.cz/cache/biglogos/mezzo_live.png'), ('Šláger Originál', 'stv-slagr', 'https://sledovanitv.cz/cache/biglogos/slagr.png'), ('Šláger Muzika', 'stv-slagr2', 'https://sledovanitv.cz/cache/biglogos/slagr2.png'), ('Šláger Premium HD', 'stv-slagr_premium', 'https://sledovanitv.cz/cache/biglogos/slagr_premium.png'), ('ČT1 SM', 'stv-ct1sm', 'https://sledovanitv.cz/cache/biglogos/ct1sm.png'), ('ČT1 JM', 'stv-ct1jm', 'https://sledovanitv.cz/cache/biglogos/ct1jm.png'), ('regionalnitelevize.cz', 'stv-regiotv', 'https://sledovanitv.cz/cache/biglogos/regiotv.png'), ('Regionální televize jižní Čechy', 'stv-rt_jc', 'https://sledovanitv.cz/cache/biglogos/rt_jc.png'), ('RT Ústecko', 'stv-rt_ustecko', 'https://sledovanitv.cz/cache/biglogos/rt_ustecko.png'), ('TV Praha', 'stv-praha', 'https://sledovanitv.cz/cache/biglogos/praha.png'), ('TV Brno 1', 'stv-brno1', 'https://sledovanitv.cz/cache/biglogos/brno1.png'), ('Info TV Brno a jižní morava', 'stv-info_tv_brno', 'https://sledovanitv.cz/cache/biglogos/info_tv_brno.png'), ('Polar', 'stv-Polar', 'https://sledovanitv.cz/cache/biglogos/Polar.png'), ('TVS', 'stv-slovacko', 'https://sledovanitv.cz/cache/biglogos/slovacko.png'), ('V1 TV', 'stv-v1tv', 'https://sledovanitv.cz/cache/biglogos/v1tv.png'), ('Plzeň TV', 'stv-plzen_tv', 'https://sledovanitv.cz/cache/biglogos/plzen_tv.png'), ('ZAK TV', 'stv-zaktv', 'https://sledovanitv.cz/cache/biglogos/zaktv.png'), ('Kladno.1 TV', 'stv-kladno', 'https://sledovanitv.cz/cache/biglogos/kladno.png'), ('Filmpro', 'stv-filmpro', 'https://sledovanitv.cz/cache/biglogos/filmpro.png'), ('RTM+ (Liberecko)', 'stv-rtm_plus_liberec', 'https://sledovanitv.cz/cache/biglogos/rtm_plus_liberec.png'), ('ORF eins', 'stv-orf1', 'https://sledovanitv.cz/cache/biglogos/orf1.png'), ('ORF zwei', 'stv-orf2', 'https://sledovanitv.cz/cache/biglogos/orf2.png'), ('CNN', 'stv-cnn', 'https://sledovanitv.cz/cache/biglogos/cnn.png'), ('Sky News', 'stv-sky_news', 'https://sledovanitv.cz/cache/biglogos/sky_news.png'), ('BBC World', 'stv-bbc', 'https://sledovanitv.cz/cache/biglogos/bbc.png'), ('France 24', 'stv-france24', 'https://sledovanitv.cz/cache/biglogos/france24.png'), ('France 24 (FR)', 'stv-france24_fr', 'https://sledovanitv.cz/cache/biglogos/france24_fr.png'), ('TV5MONDE', 'stv-tv5', 'https://sledovanitv.cz/cache/biglogos/tv5.png'), ('Russia Today', 'stv-russiatoday', 'https://sledovanitv.cz/cache/biglogos/russiatoday.png'), ('RT Documentary', 'stv-rt_doc', 'https://sledovanitv.cz/cache/biglogos/rt_doc.png'), ('UA TV', 'stv-uatv', 'https://sledovanitv.cz/cache/biglogos/uatv.png'), ('TV Mňau', 'stv-mnau', 'https://sledovanitv.cz/cache/biglogos/mnau.png'), ('Zoo Brno - Africká vesnice', 'stv-zoo_brno_a_vesnice', 'https://sledovanitv.cz/cache/biglogos/zoo_brno_a_vesnice.png'), ('Zoo Brno - Medvěd kamčatský', 'stv-zoo_brno_m_kamcatsky', 'https://sledovanitv.cz/cache/biglogos/zoo_brno_m_kamcatsky.png'), ('Zoo Brno - Medvěd lední', 'stv-zoo_brno_m_ledni', 'https://sledovanitv.cz/cache/biglogos/zoo_brno_m_ledni.png'), ('Zoo Brno - Komentovaná krmení', 'stv-komentovana_krmeni', 'https://sledovanitv.cz/cache/biglogos/komentovana_krmeni.png'), ('Zoo Brno - Život v zoo', 'stv-zvirata_v_zoo', 'https://sledovanitv.cz/cache/biglogos/zvirata_v_zoo.png'), ('Galerie zvířat', 'stv-loop_naturetv-galerie-zvirat', 'https://sledovanitv.cz/cache/biglogos/loop_naturetv-galerie-zvirat.png'), ('Ošetřování mláďat', 'stv-loop_naturetv-osetrovani-mladat', 'https://sledovanitv.cz/cache/biglogos/loop_naturetv-osetrovani-mladat.png'), ('Kočičí kavárna', 'stv-uscenes_cat_cafe', 'https://sledovanitv.cz/cache/biglogos/uscenes_cat_cafe.png'), ('Čapí hnízdo', 'stv-stork_nest', 'https://sledovanitv.cz/cache/biglogos/stork_nest.png'), ('Pláž', 'stv-uscenes_hammock_beach', 'https://sledovanitv.cz/cache/biglogos/uscenes_hammock_beach.png'), ('Korálová zahrada', 'stv-uscenes_coral_garden', 'https://sledovanitv.cz/cache/biglogos/uscenes_coral_garden.png'), ('Mumlavské vodopády', 'stv-loop_naturetv_mumlava_waterfalls', 'https://sledovanitv.cz/cache/biglogos/loop_naturetv_mumlava_waterfalls.png'), ('Noční Praha', 'stv-night_prague', 'https://sledovanitv.cz/cache/biglogos/night_prague.png'), ('Krb', 'stv-fireplace', 'https://sledovanitv.cz/cache/biglogos/fireplace.png'), ('Erox', 'stv-eroxHD', 'https://sledovanitv.cz/cache/biglogos/eroxHD.png'), ('Eroxxx', 'stv-eroxxxHD', 'https://sledovanitv.cz/cache/biglogos/eroxxxHD.png'), ('Leo TV Gold', 'stv-leo_gold', 'https://sledovanitv.cz/cache/biglogos/leo_gold.png'), ('Extasy 4K', 'stv-extasy_4k', 'https://sledovanitv.cz/cache/biglogos/extasy_4k.png'), ('ČRo Radiožurnál', 'stv-radio_cro1', 'https://sledovanitv.cz/cache/biglogos/radio_cro1.png'), ('ČRo Dvojka', 'stv-radio_cro2', 'https://sledovanitv.cz/cache/biglogos/radio_cro2.png'), ('ČRo Radio Wave', 'stv-radio_wave', 'https://sledovanitv.cz/cache/biglogos/radio_wave.png'), ('Evropa 2', 'stv-radio_evropa2', 'https://sledovanitv.cz/cache/biglogos/radio_evropa2.png'), ('Impuls', 'stv-radio_impuls', 'https://sledovanitv.cz/cache/biglogos/radio_impuls.png'), ('Frekvence 1', 'stv-radio_frekvence1', 'https://sledovanitv.cz/cache/biglogos/radio_frekvence1.png'), ('Kiss', 'stv-radio_kiss', 'https://sledovanitv.cz/cache/biglogos/radio_kiss.png'), ('Fajn Radio', 'stv-radio_fajn', 'https://sledovanitv.cz/cache/biglogos/radio_fajn.png'), ('Rádio Orlicko', 'stv-radio_orlicko', 'https://sledovanitv.cz/cache/biglogos/radio_orlicko.png'), ('Krokodýl', 'stv-radio_krokodyl', 'https://sledovanitv.cz/cache/biglogos/radio_krokodyl.png'), ('Černá Hora', 'stv-radio_cernahora', 'https://sledovanitv.cz/cache/biglogos/radio_cernahora.png'), ('Signál rádio', 'stv-radio_signal', 'https://sledovanitv.cz/cache/biglogos/radio_signal.png'), ('Rádio Spin', 'stv-radio_spin', 'https://sledovanitv.cz/cache/biglogos/radio_spin.png'), ('Rádio Country', 'stv-radio_country', 'https://sledovanitv.cz/cache/biglogos/radio_country.png'), ('Rádio BEAT', 'stv-radio_beat', 'https://sledovanitv.cz/cache/biglogos/radio_beat.png'), ('Rádio 1', 'stv-radio_1', 'https://sledovanitv.cz/cache/biglogos/radio_1.png'), ('Radio Dychovka', 'stv-radio_dychovka', 'https://sledovanitv.cz/cache/biglogos/radio_dychovka.png'), ('Radio Dechovka', 'stv-radio_dechovka', 'https://sledovanitv.cz/cache/biglogos/radio_dechovka.png'), ('Rádio Slovensko', 'stv-radio_slovensko', 'https://sledovanitv.cz/cache/biglogos/radio_slovensko.png'), ('Rádio FM', 'stv-radio_fm', 'https://sledovanitv.cz/cache/biglogos/radio_fm.png'), ('Rádio Regina Západ', 'stv-radio_regina_sk', 'https://sledovanitv.cz/cache/biglogos/radio_regina_sk.png'), ('Rádio Expres', 'stv-radio_expres', 'https://sledovanitv.cz/cache/biglogos/radio_expres.png'), ('Rádio Fun', 'stv-radio_fun', 'https://sledovanitv.cz/cache/biglogos/radio_fun.png'), ('Rádio Jemné', 'stv-radio_jemne', 'https://sledovanitv.cz/cache/biglogos/radio_jemne.png'), ('Rádio Vlna', 'stv-radio_vlna', 'https://sledovanitv.cz/cache/biglogos/radio_vlna.png'), ('Rádio Best FM', 'stv-radio_bestfm', 'https://sledovanitv.cz/cache/biglogos/radio_bestfm.png'), ('Rádio Košice', 'stv-radio_kosice', 'https://sledovanitv.cz/cache/biglogos/radio_kosice.png'), ('Radio WOW', 'stv-radio_wow_sk', 'https://sledovanitv.cz/cache/biglogos/radio_wow_sk.png'), ('Rádio Lumen', 'stv-radio_lumen', 'https://sledovanitv.cz/cache/biglogos/radio_lumen.png'), ('Rádia Regina Východ', 'stv-radio_regina_vy', 'https://sledovanitv.cz/cache/biglogos/radio_regina_vy.png'), ('Rádio Devín', 'stv-radio_devin', 'https://sledovanitv.cz/cache/biglogos/radio_devin.png'), ('Rádio Patria', 'stv-radio_patria', 'https://sledovanitv.cz/cache/biglogos/radio_patria.png'), ('Fit family rádio', 'stv-radio_fit_family', 'https://sledovanitv.cz/cache/biglogos/radio_fit_family.png'), ('NON-STOP rádio', 'stv-radio_nonstop', 'https://sledovanitv.cz/cache/biglogos/radio_nonstop.png'), ('ČRo Vltava', 'stv-radio_cro3', 'https://sledovanitv.cz/cache/biglogos/radio_cro3.png'), ('ČRo Plus', 'stv-radio_cro6', 'https://sledovanitv.cz/cache/biglogos/radio_cro6.png'), ('ČRo Jazz', 'stv-radio_jazz', 'https://sledovanitv.cz/cache/biglogos/radio_jazz.png'), ('ČRo Junior', 'stv-radio_junior', 'https://sledovanitv.cz/cache/biglogos/radio_junior.png'), ('ČRo D-Dur', 'stv-radio_ddur', 'https://sledovanitv.cz/cache/biglogos/radio_ddur.png'), ('ČRo Brno', 'stv-radio_brno', 'https://sledovanitv.cz/cache/biglogos/radio_brno.png'), ('ČRo Radio Praha', 'stv-radio_praha', 'https://sledovanitv.cz/cache/biglogos/radio_praha.png'), ('ČRo České Budějovice', 'stv-radio_ceskebudejovice', 'https://sledovanitv.cz/cache/biglogos/radio_ceskebudejovice.png'), ('ČRo Hradec Králové', 'stv-radio_hk', 'https://sledovanitv.cz/cache/biglogos/radio_hk.png'), ('ČRo Olomouc', 'stv-radio_olomouc', 'https://sledovanitv.cz/cache/biglogos/radio_olomouc.png'), ('ČRo Ostrava', 'stv-radio_ostrava', 'https://sledovanitv.cz/cache/biglogos/radio_ostrava.png'), ('ČRo Pardubice', 'stv-radio_pardubice', 'https://sledovanitv.cz/cache/biglogos/radio_pardubice.png'), ('ČRo Plzeň', 'stv-radio_plzen', 'https://sledovanitv.cz/cache/biglogos/radio_plzen.png'), ('ČRo Region - Středočeský kraj', 'stv-radio_region', 'https://sledovanitv.cz/cache/biglogos/radio_region.png'), ('ČRo Region - Vysočina', 'stv-radio_vysocina', 'https://sledovanitv.cz/cache/biglogos/radio_vysocina.png'), ('ČRo Sever', 'stv-radio_sever', 'https://sledovanitv.cz/cache/biglogos/radio_sever.png'), ('ČRo Sever - Liberec', 'stv-radio_liberec', 'https://sledovanitv.cz/cache/biglogos/radio_liberec.png'), ('ČRo Regina', 'stv-radio_regina', 'https://sledovanitv.cz/cache/biglogos/radio_regina.png'), ('RadioR', 'stv-radior', 'https://sledovanitv.cz/cache/biglogos/radior.png'), ('Rádio Otava', 'stv-radio_blatna', 'https://sledovanitv.cz/cache/biglogos/radio_blatna.png'), ('Proglas', 'stv-radio_proglas', 'https://sledovanitv.cz/cache/biglogos/radio_proglas.png'), ('i-Vysočina', 'stv-ivysocina_stream_zs', 'https://sledovanitv.cz/cache/biglogos/ivysocina_stream_zs.png'), ('TV Beskyd', 'stv-tvbeskyd', 'https://sledovanitv.cz/cache/biglogos/tvbeskyd.png'), ('cms:tv', 'stv-cms_tv', 'https://sledovanitv.cz/cache/biglogos/cms_tv.png'), ('Panorama TV', 'stv-panorama_tv', 'https://sledovanitv.cz/cache/biglogos/panorama_tv.png'), ('Jihočeská televize', 'stv-jihoceska_televize', 'https://sledovanitv.cz/cache/biglogos/jihoceska_televize.png'), ('Tik Bohumín', 'stv-tik_bohumin', 'https://sledovanitv.cz/cache/biglogos/tik_bohumin.png'), ('Dorcel TV', 'stv-DorceltvHD', 'https://sledovanitv.cz/cache/biglogos/DorceltvHD.png'), ('Dorcel XXX', 'stv-DorcelHD', 'https://sledovanitv.cz/cache/biglogos/DorcelHD.png'), ('Playboy TV', 'stv-playboy', 'https://sledovanitv.cz/cache/biglogos/playboy.png'), ('ČRo Pohoda', 'stv-radio_cro_pohoda', 'https://sledovanitv.cz/cache/biglogos/radio_cro_pohoda.png'), ('Rádio Jih', 'stv-radio_jih', 'https://sledovanitv.cz/cache/biglogos/radio_jih.png'), ('Rádio Jihlava', 'stv-radio_jihlava', 'https://sledovanitv.cz/cache/biglogos/radio_jihlava.png'), ('Free Rádio', 'stv-radio_free', 'https://sledovanitv.cz/cache/biglogos/radio_free.png'), ('JuKej Radio', 'stv-radio_jukej', 'https://sledovanitv.cz/cache/biglogos/radio_jukej.png'), ('PiGy Disko Trysko', 'stv-radio_pigy_disko', 'https://sledovanitv.cz/cache/biglogos/radio_pigy_disko.png'), ('PiGy Pohádkové písničky', 'stv-radio_pigy_pisnicky', 'https://sledovanitv.cz/cache/biglogos/radio_pigy_pisnicky.png'), ('PiGy Pohádky', 'stv-radio_pigy_pohadky', 'https://sledovanitv.cz/cache/biglogos/radio_pigy_pohadky.png'), ('Radio Z', 'stv-radio_z', 'https://sledovanitv.cz/cache/biglogos/radio_z.png'), ('Radio Čas', 'stv-radio_cas', 'https://sledovanitv.cz/cache/biglogos/radio_cas.png'), ('Dance Rádio', 'stv-radio_dance', 'https://sledovanitv.cz/cache/biglogos/radio_dance.png'), ('Hitrádio Desítka', 'stv-radio_hit_desitka', 'https://sledovanitv.cz/cache/biglogos/radio_hit_desitka.png'), ('Hitradio Osmdesatka', 'stv-radio_hitradio_80', 'https://sledovanitv.cz/cache/biglogos/radio_hitradio_80.png'), ('Hitradio Devadesátka', 'stv-radio_hitradio_90', 'https://sledovanitv.cz/cache/biglogos/radio_hitradio_90.png'), ('Hitradio Orion', 'stv-radio_hitradio_orion', 'https://sledovanitv.cz/cache/biglogos/radio_hitradio_orion.png'), ('Rádio Blaník', 'stv-radio_blanik', 'https://sledovanitv.cz/cache/biglogos/radio_blanik.png'), ('Rock Rádio', 'stv-radio_rock_radio', 'https://sledovanitv.cz/cache/biglogos/radio_rock_radio.png'), ('ČRo Radiožurnál Sport', 'stv-radio_cro_sport', 'https://sledovanitv.cz/cache/biglogos/radio_cro_sport.png'), ('ČRo Zlín', 'stv-radio_cro_zlin', 'https://sledovanitv.cz/cache/biglogos/radio_cro_zlin.png'), ('ČRo Karlovy Vary', 'stv-radio_cro_kv', 'https://sledovanitv.cz/cache/biglogos/radio_cro_kv.png'), ('Radio Color', 'stv-radio_color', 'https://sledovanitv.cz/cache/biglogos/radio_color.png'), ('Radio Hey', 'stv-radio_hey', 'https://sledovanitv.cz/cache/biglogos/radio_hey.png'), ('SeeJay', 'stv-seejay', 'https://sledovanitv.cz/cache/biglogos/seejay.png'), ('Pervij kanal', 'stv-russia_channel1', 'https://sledovanitv.cz/cache/biglogos/russia_channel1.png'), ('Dom Kino', 'stv-dom_kino', 'https://sledovanitv.cz/cache/biglogos/dom_kino.png'), ('Dom Kino Premium', 'stv-dom_kino_premium', 'https://sledovanitv.cz/cache/biglogos/dom_kino_premium.png'), ('Vremya', 'stv-vremya', 'https://sledovanitv.cz/cache/biglogos/vremya.png'), ('Poekhali!', 'stv-poehali', 'https://sledovanitv.cz/cache/biglogos/poehali.png'), ('Muzika Pervogo', 'stv-muzika_pervogo', 'https://sledovanitv.cz/cache/biglogos/muzika_pervogo.png'), ('Bobyor', 'stv-bobyor', 'https://sledovanitv.cz/cache/biglogos/bobyor.png'), ('O!', 'stv-telekanal_o', 'https://sledovanitv.cz/cache/biglogos/telekanal_o.png'), ('Telecafe', 'stv-telecafe', 'https://sledovanitv.cz/cache/biglogos/telecafe.png'), ('Karusel', 'stv-karousel', 'https://sledovanitv.cz/cache/biglogos/karousel.png'), ('X-mo', 'stv-x-mo', 'https://sledovanitv.cz/cache/biglogos/x-mo.png'), ('Brazzers TV Europe', 'stv-brazzers', 'https://sledovanitv.cz/cache/biglogos/brazzers.png'), ('Leo TV', 'stv-leo', 'https://sledovanitv.cz/cache/biglogos/leo.png'), ('Extasy', 'stv-extasy', 'https://sledovanitv.cz/cache/biglogos/extasy.png'), ('Private HD', 'stv-privatetv', 'https://sledovanitv.cz/cache/biglogos/privatetv.png'), ('Reality Kings', 'stv-realitykings', 'https://sledovanitv.cz/cache/biglogos/realitykings.png'), ('True Amateurs', 'stv-true_amateurs', 'https://sledovanitv.cz/cache/biglogos/true_amateurs.png'), ('Babes TV', 'stv-babes_tv', 'https://sledovanitv.cz/cache/biglogos/babes_tv.png'), ('Redlight', 'stv-redlight', 'https://sledovanitv.cz/cache/biglogos/redlight.png')]
        title = 'SledovaniTV.cz'
    else:
        ch = [('Markíza', 'stvsk-markiza', 'https://sledovanietv.sk/cache/biglogos/markiza.png'), ('JOJ', 'stvsk-joj', 'https://sledovanietv.sk/cache/biglogos/joj.png'), ('JOJ Plus', 'stvsk-jojplus', 'https://sledovanietv.sk/cache/biglogos/jojplus.png'), ('Doma', 'stvsk-doma', 'https://sledovanietv.sk/cache/biglogos/doma.png'), ('JOJ Šport', 'stvsk-joj_sport', 'https://sledovanietv.sk/cache/biglogos/joj_sport.png'), ('Dajto', 'stvsk-dajto', 'https://sledovanietv.sk/cache/biglogos/dajto.png'), ('Rik', 'stvsk-rik2', 'https://sledovanietv.sk/cache/biglogos/rik2.png'), ('Jojko', 'stvsk-rik', 'https://sledovanietv.sk/cache/biglogos/rik.png'), ('WAU', 'stvsk-wau', 'https://sledovanietv.sk/cache/biglogos/wau.png'), ('Nova International', 'stvsk-novaint', 'https://sledovanietv.sk/cache/biglogos/novaint.png'), ('Prima PLUS', 'stvsk-primaplus', 'https://sledovanietv.sk/cache/biglogos/primaplus.png'), ('RTVS Šport', 'stvsk-stv4', 'https://sledovanietv.sk/cache/biglogos/stv4.png'), ('Televizia Osem', 'stvsk-tv_osem', 'https://sledovanietv.sk/cache/biglogos/tv_osem.png'), ('M1', 'stvsk-m1', 'https://sledovanietv.sk/cache/biglogos/m1.png'), ('M2', 'stvsk-m2', 'https://sledovanietv.sk/cache/biglogos/m2.png'), ('M4 Sport', 'stvsk-m4', 'https://sledovanietv.sk/cache/biglogos/m4.png'), ('Arcadia World', 'stvsk-arcadia', 'https://sledovanietv.sk/cache/biglogos/arcadia.png'), ('TV Karpaty', 'stvsk-karpaty', 'https://sledovanietv.sk/cache/biglogos/karpaty.png'), ('TV Liptov', 'stvsk-tv_liptov', 'https://sledovanietv.sk/cache/biglogos/tv_liptov.png'), ('Central', 'stvsk-tv_central', 'https://sledovanietv.sk/cache/biglogos/tv_central.png'), ('TV Lux', 'stvsk-tv_lux', 'https://sledovanietv.sk/cache/biglogos/tv_lux.png'), ('TV Ružomberok', 'stvsk-ruzomberok', 'https://sledovanietv.sk/cache/biglogos/ruzomberok.png')]
        title = 'SledovanieTV.sk'
    chch = [idx for idx in ch if idx[0][0].lower() == check.lower()]
    ch.sort()
    for c in ch:
        if c not in chch:
            chch.append(c)
    channel = xbmcgui.Dialog().select(title, [x[0] for x in chch], useDetails=False)
    if channel != -1:
        return chch[channel][1]
    else:
        return None


def source1(check, lng):
    if lng == "cz":
        prfx = "tm-"
        title = 'T-Mobile TV GO'
    else:
        prfx = "mag-"
        title = 'Magio GO'
    ch = []
    params={"dsid": "c75536831e9bdc93", "deviceName": "Redmi Note 7", "deviceType": "OTT_ANDROID", "osVersion": "10", "appVersion": "3.7.0", "language": "CZ"}
    headers={"Host": lng + "go.magio.tv", "authorization": "Bearer", "User-Agent": "okhttp/3.12.12", "content-type":  "application/json", "Connection": "Keep-Alive"}
    req = requests.post("https://" + lng + "go.magio.tv/v2/auth/init", params=params, headers=headers, verify=True).json()
    token = req["token"]["accessToken"]
    headers2={"Host": lng + "go.magio.tv", "authorization": "Bearer " + token, "User-Agent": "okhttp/3.12.12", "content-type":  "application/json"}
    req1 = requests.get("https://" + lng + "go.magio.tv/v2/television/channels?list=LIVE&queryScope=LIVE", headers=headers2).json()["items"]
    for y in req1:
        id = str(y["channel"]["channelId"])
        name = y["channel"]["name"]
        ch.append((name.replace(" HD", ""), prfx + id + "-" + encode(name).replace(" HD", "").lower().replace(" ", "-")))
    chch = [idx for idx in ch if idx[0][0].lower() == check.lower()]
    ch.sort()
    for c in ch:
        if c not in chch:
            chch.append(c)
    channel = xbmcgui.Dialog().select(title, [x[0] for x in chch], useDetails=False)
    if channel != -1:
        return chch[channel][1]
    else:
        return None


def source0(check):
    ch = []
    html = requests.get("http://programandroid.365dni.cz/android/v6-tv.php?locale=cs_CZ").text
    root = ET.fromstring(html)
    for i in root.iter('a'):
        try:
            icon = "http://sms.cz/kategorie/televize/bmp/loga/velka/" + i.find("o").text
        except:
            icon = ""
        ch.append((i.find('n').text, encode((i.attrib["id"] + "-" + i.find('n').text).replace(" ", "-").lower()), icon))
    chch = [idx for idx in ch if idx[0][0].lower() == check.lower()]
    ch.sort()
    for c in ch:
        if c not in chch:
            chch.append(c)
    channel = xbmcgui.Dialog().select('TV.SMS.cz', [x[0] for x in chch], useDetails=False)
    if channel != -1:
        return chch[channel][1]
    else:
        return None


def sources(uri, channel, check):
    source = xbmcgui.Dialog().select('Zdroj', ["TV.SMS.cz", "T-Mobile TV GO", "Magio GO", "SledovaniTV.cz", "SledovanieTV.sk", "O2 TV Sport", "můjTVprogram.cz", "Eurosport", "TV Spiel", "OTT Play"], useDetails=False)
    if source != -1:
        if source == 0:
            id = source0(check)
            if id is not None:
                save_playlist(uri, channel, id)
            else:
                channels(uri, channel)
        elif source == 1:
            id = source1(check, "cz")
            if id is not None:
                save_playlist(uri, channel, id)
            else:
                channels(uri, channel)
        elif source == 2:
            id = source1(check, "sk")
            if id is not None:
                save_playlist(uri, channel, id)
            else:
                channels(uri, channel)
        elif source == 3:
            id = source2(check, "cz")
            if id is not None:
                save_playlist(uri, channel, id)
            else:
                channels(uri, channel)
        elif source == 4:
            id = source2(check, "sk")
            if id is not None:
                save_playlist(uri, channel, id)
            else:
                channels(uri, channel)
        elif source == 5:
            id = source3(check)
            if id is not None:
                save_playlist(uri, channel, id)
            else:
                channels(uri, channel)
        elif source == 6:
            id = source4(check)
            if id is not None:
                save_playlist(uri, channel, id)
            else:
                channels(uri, channel)
        elif source == 7:
            id = source5(check)
            if id is not None:
                save_playlist(uri, channel, id)
            else:
                channels(uri, channel)
        elif source == 8:
            id = source6(check)
            if id is not None:
                save_playlist(uri, channel, id)
            else:
                channels(uri, channel)
        elif source == 9:
            id = source7(check)
            if id is not None:
                save_playlist(uri, channel, id)
            else:
                channels(uri, channel)
    else:
        channels(uri, channel)


def channels(uri, prs):
    name_list = parse_names(uri)
    item = []
    for x in name_list:
        inner_item = xbmcgui.ListItem(label="[COLOR lightskyblue]" + x[0] + "[/COLOR]", label2=x[1])
        inner_item.setArt({ 'thumb': x[2]})
        item.append(inner_item)
    channel = xbmcgui.Dialog().select('Playlist', item, useDetails=True, preselect = prs)
    if channel != -1:
        sources(uri, channel, name_list[channel][0][0])



uri = xbmcgui.Dialog().browse(1,"Vyberte m3u soubor","files", ".m3u|.txt", defaultt = addon.getSetting("pls_path"))
if uri:
#    fname = get_nonexistant_path(uri)
    addon.setSetting(id='pls_path', value= uri)
    channels(uri, prs)