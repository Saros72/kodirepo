#-*-coding:utf8;-*-

__version__ = "0.2"
__all__ = ["SimpleHTTPRequestHandler"]
__author__ = "bones7456"
__home_page__ = "http://li2z.cn/"
__modified__ = "Sároš"

import html
import http.server
import os
import re
import sys
import urllib.parse
from io import BytesIO
import io
import mimetypes
import xbmcaddon
import xbmcgui
import xbmc
import xbmcvfs
import socket
import subprocess
import requests
import json
import time
import threading
from http import HTTPStatus


addon = xbmcaddon.Addon(id='service.simple.http.server')


class SimpleHTTPRequestHandler(http.server.SimpleHTTPRequestHandler):

    enc = sys.getfilesystemencoding()

    server_version = "SimpleHTTPWithUpload/" + __version__

    def do_POST(self):
        r, info = self.deal_post_data()
        print((r, info, "by: ", self.client_address))
        f = BytesIO()
        f.write(b'''
        <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" 
        <html>
        <title>Upload Result Page</title>
        <body>
        <h2>Upload Result Page</h2>
        <hr>
        ''')
        if r:
            f.write(b"<h1>Success:</h1>")
        else:
            f.write(b"<h1>Failed:</h1>")
        f.write(info.encode())
        f.write(('<br><a href="%s">back</a>' % self.headers['referer']).encode())
        f.write(b'<hr><small>Powered By: bones7456, modified by Saros')
        length = f.tell()
        f.seek(0)
        self.send_response(200)
        self.send_header("Content-type", "text/html; charset={}".format(self.enc))
        self.send_header("Content-Length", str(length))
        self.end_headers()
        if f:
            self.copyfile(f, self.wfile)
            f.close()

    def deal_post_data(self):
        content_type = self.headers['content-type']
        if not content_type:
            return False, "Content-Type header doesn't contain boundary"
        boundary = content_type.split("=")[1].encode()
        remained_bytes = int(self.headers['content-length'])
        line = self.rfile.readline()
        remained_bytes -= len(line)
        if boundary not in line:
            return False, "Content NOT begin with boundary"
        line = self.rfile.readline()
        remained_bytes -= len(line)
        fn = re.findall(r'Content-Disposition.*name="file"; filename="(.*)"', line.decode())
        if not fn:
            return False, "Can't find out file name..."
        path = self.translate_path(self.path)
        fn = os.path.join(path, fn[0])
        line = self.rfile.readline()
        remained_bytes -= len(line)
        line = self.rfile.readline()
        remained_bytes -= len(line)
        try:
            out = open(fn, 'wb')
        except IOError:
            return False, "Can't create file to write, do you have permission to write?"

        pre_line = self.rfile.readline()
        remained_bytes -= len(pre_line)
        while remained_bytes > 0:
            line = self.rfile.readline()
            remained_bytes -= len(line)
            if boundary in line:
                pre_line = pre_line[0:-1]
                if pre_line.endswith(b'\r'):
                    pre_line = pre_line[0:-1]
                out.write(pre_line)
                out.close()
                return True, "File '%s' upload success!" % fn
            else:
                out.write(pre_line)
                pre_line = line
        return False, "Unexpected Ends of data."

    def list_directory(self, path):
        try:
            list = os.listdir(path)
        except OSError:
            self.send_error(
                HTTPStatus.NOT_FOUND,
                "No permission to list directory")
            return None
        list.sort(key=lambda a: a.lower())
        r = []
        try:
            displaypath = urllib.parse.unquote(self.path, errors='surrogatepass')
        except UnicodeDecodeError:
            displaypath = urllib.parse.unquote(path)
        displaypath = html.escape(displaypath, quote=False)
        title = 'Directory listing for %s' % displaypath
        r.append('''
        <!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
        <html>
        <head>
            <meta http-equiv="Content-Type" content="text/html; charset={enc}">
            <title>{title}</title>
        </head>
        <body>
        <h1>{title}</h1>
        <hr>
        <form ENCTYPE="multipart/form-data" method="post">
        File to upload here: <input name="file" type="file"/>
            <input type="submit" value="upload"/>
        </form>
        <hr>
        <ul>
        '''.format(title=title, enc=self.enc))
        for name in list:
            fullname = os.path.join(path, name)
            displayname = linkname = name
            # Append / for directories or @ for symbolic links
            if os.path.isdir(fullname):
                displayname = name + "/"
                linkname = name + "/"
            if os.path.islink(fullname):
                displayname = name + "@"
                # Note: a link to a directory displays with @ and links with /
            r.append('<li><a href="%s">%s</a></li>'
                     % (urllib.parse.quote(linkname, errors='surrogatepass'),
                        html.escape(displayname, quote=False)))
        r.append('''
        </ul>
        <hr>
        </body>
        </html>
        ''')
        encoded = '\n'.join(r).encode(self.enc, 'surrogateescape')
        f = io.BytesIO()
        f.write(encoded)
        f.seek(0)
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-type", "text/html; charset=%s" % self.enc)
        self.send_header("Content-Length", str(len(encoded)))
        self.end_headers()
        return f

    def log_request(self, code='-', size='-'):
        if isinstance(code, HTTPStatus):
            code = code.value
        self.log_message('"%s" %s %s ',
                         urllib.parse.unquote(self.requestline), str(code), str(size))

    if not mimetypes.inited:
        mimetypes.init() # try to read system mime.types
    extensions_map = mimetypes.types_map.copy()
    extensions_map.update({
        '': 'application/octet-stream', # Default
        '.py': 'text/plain',
        '.c': 'text/plain',
        '.log': 'text/plain',
        })


def getNetworkIp():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
    s.connect(('google.com', 80))
    return s.getsockname()[0]


def main():
    os.chdir(xbmcvfs.translatePath(addon.getSetting("folder")))
    host = str(getNetworkIp())
    port = addon.getSetting("port")
    xbmcgui.Dialog().notification("Simple HTTP Server","http://" + host + ":" + str(port), xbmcgui.NOTIFICATION_INFO, 6000, sound = False)
    server_address = (host, int(port))
    handler_class = SimpleHTTPRequestHandler
    server_class = http.server.HTTPServer
    server = server_class(server_address, handler_class)
    thread = threading.Thread(target = server.serve_forever)
    thread.daemon = True
    thread.start()
    monitor = xbmc.Monitor()
    while not monitor.abortRequested():
        if monitor.waitForAbort(1):
            server.shutdown()
            xbmc.sleep(1000)
            thread.join()
            break
        

if __name__ == '__main__':
    main()
