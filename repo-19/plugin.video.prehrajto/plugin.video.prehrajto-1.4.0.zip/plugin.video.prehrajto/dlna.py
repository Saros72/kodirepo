# -*- coding: utf-8 -*-
import os
import xbmc
import xbmcgui
import xbmcaddon
import time
from urllib import request
import sys
from nanodlna import devices, util


def cast(url):
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    devices_list = []
    services = devices.get_devices(3)
    for x in services:
        devices_list.append(x["friendly_name"])
    if services != []:
        choose = xbmcgui.Dialog().select("Zvolte zařízení", devices_list)
        if choose == -1:
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
            sys.exit(1)
        else:
            dev_name = services[choose]
    else:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        xbmcgui.Dialog().notification("DLNA","Žádné zařízení", xbmcgui.NOTIFICATION_ERROR, 4000, sound = False)
        sys.exit(1)
    xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
    files = {"file_video": url.replace("&", "&amp;")}
    sub = open(os.path.join(xbmc.translatePath('special://home/addons/plugin.video.prehrajto'),'resources', 'subtitles.txt'), "r").read()
    if sub != "":
        files["file_subtitle"] = sub.replace("&", "&amp;")
    util.play(files, dev_name)


class NoRedirect(request.HTTPErrorProcessor):
    def http_response(self, request, response):
        return response
    https_response = http_response


def main():
    player = xbmc.Player()
    xbmc.executebuiltin('Action(play)')
    while True:
        try:
            time.sleep(0.5)
            url = player.getPlayingFile().split("|")[0]
            if url:
                break
        except:
            pass
    player.stop()
    opener = request.build_opener(NoRedirect)
    location = opener.open(url).getheader('Location')
    if location is not None:
        url = location
    cast(str(url))


if (__name__ == "__main__"):
    main()