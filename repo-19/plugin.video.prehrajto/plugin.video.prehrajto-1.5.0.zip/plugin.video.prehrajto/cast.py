# -*- coding: utf-8 -*-
import os
import xbmc
import xbmcgui
import xbmcaddon
import pychromecast
import time
import sys
from urllib import request


def cast(url):
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    services, browser = pychromecast.discovery.discover_chromecasts()
    devices = []
    for x in services:
        devices.append(x.friendly_name)
    pychromecast.discovery.stop_discovery(browser)
    if devices != []:
        choose = xbmcgui.Dialog().select("Zvolte zařízení", devices)
        if choose == -1:
            xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
            sys.exit(1)
        else:
            dev_name = devices[choose]
    else:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        xbmcgui.Dialog().notification("Chromecast","Žádné zařízení", xbmcgui.NOTIFICATION_ERROR, 4000, sound = False)
        sys.exit(1)
    chromecasts, browser = pychromecast.get_listed_chromecasts(friendly_names=[dev_name])
    if not chromecasts:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        xbmcgui.Dialog().notification("Chromecast","Zařízení nedostupné", xbmcgui.NOTIFICATION_ERROR, 4000, sound = False)
        browser.stop_discovery()
        sys.exit(1)
    cast = chromecasts[0]
    cast.wait()
    if not cast.is_idle:
        cast.quit_app()
        t = 5
        while cast.status.app_id is not None and t > 0:
            time.sleep(0.1)
            t = t - 0.1
    mc = cast.media_controller
    sub = open(os.path.join(xbmcvfs.translatePath('special://home/addons/plugin.video.prehrajto'),'resources', 'subtitles.txt'), "r").read()
    if sub == "":
        sub = None
    mc.play_media(url = url, content_type = "video/mp4", subtitles = sub)
    mc.play()
    time.sleep(1)
    xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
    player_state = None
    t = 5
    has_played = False
    while True:
        try:
            if player_state != cast.media_controller.status.player_state:
                player_state = cast.media_controller.status.player_state
                print("Player state:", player_state)
            if player_state == "PLAYING":
                has_played = True
            if cast.socket_client.is_connected and has_played and player_state != "PLAYING":
                has_played = False
                break
                xbmcgui.Dialog().notification("Chromecast","Přehrávání zastaveno", xbmcgui.NOTIFICATION_INFO, 4000, sound = False)

            time.sleep(0.1)
            t = t - 0.1
        except KeyboardInterrupt:
            break

    browser.stop_discovery()


class NoRedirect(request.HTTPErrorProcessor):
    def http_response(self, request, response):
        return response
    https_response = http_response


def main():
    player = xbmc.Player()
    xbmc.executebuiltin('Action(play)')
    while True:
        try:
            time.sleep(0.5)
            url = player.getPlayingFile().split("|")[0]
            if url:
                break
        except:
            pass
    player.stop()
    opener = request.build_opener(NoRedirect)
    location = opener.open(url).getheader('Location')
    if location is not None:
        url = location
    cast(str(url))


if (__name__ == "__main__"):
    main()