__version__ = "12.1.0"

if __name__ == "__main__":
    print(__version__)
