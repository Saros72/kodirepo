# -*- coding: utf-8 -*-

import routing
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import re
from bs4 import BeautifulSoup
import requests
from pytube import YouTube
import xbmcvfs
import os
import json


plugin = routing.Plugin()


@plugin.route('/autozurnal_play/')
def autozurnal_play():
    link = plugin.args['show_url'][0]
    req = requests.get(link).content
    soup = BeautifulSoup(req, 'html.parser')
    items = soup.find_all('iframe',{'class': ['latestVideoEmbed', 'embed-responsive-item']},True)[0].attrs['src']
    id = re.findall('embed/(.*)?',str(items), re.DOTALL)[0].split("?")[0]
    yt = YouTube("https://www.youtube.com/embed/" + id)
    stream = yt.streams.get_highest_resolution().url
    list_item = xbmcgui.ListItem(path=stream)
    xbmcplugin.setResolvedUrl(plugin.handle, True, list_item)


@plugin.route('/autozurnal_list/')
def autozurnal_list():
    pg = plugin.args['page'][0]
    name_list = []
    listing = []
    req = requests.get("https://autozurnal.com/video?page=" + pg).content
    soup = BeautifulSoup(req, 'html.parser')
    items = soup.find_all('div',{'class': ['col-sm-8', 'col-sm-6']},True)
    for item in items:
        i = (item.find_all('img')[0].attrs['alt'], "https://autozurnal.com" + item.find_all('a')[0].attrs['href'], item.find_all('img',{'class': 'img-responsive'},True)[0].attrs['src'])
        if i not in name_list:
            name_list.append(i)
    name_list.append(("Další", "pg", ""))
    for category in name_list:
        list_item = xbmcgui.ListItem(label=category[0])
        list_item.setInfo('video', {'title': category[0], "genre": "Publicistický / Sportovní"})
        list_item.setArt({'thumb':category[2] , 'icon': category[2]})
        if category[1] == "pg":
            pg = int(pg) + 1
            listing.append((plugin.url_for(autozurnal_list, page = str(pg)), list_item, True))
        else:
            list_item.setProperty('IsPlayable', 'true')
            listing.append((plugin.url_for(autozurnal_play, show_url = category[1]), list_item, False))
    xbmcplugin.addDirectoryItems(plugin.handle, listing, len(listing))
    xbmcplugin.endOfDirectory(plugin.handle)


@plugin.route('/autosalon_sk_play/')
def autosalon_sk_play():
    link = plugin.args['show_url'][0]
    req = requests.get(link).text
    id = re.findall('https://www.youtube.com/embed/(.*?)"',str(req), re.DOTALL)[0]
    stream = YouTube("https://m.youtube.com/watch?v=" + str(id)).streams.get_highest_resolution().url
    list_item = xbmcgui.ListItem(path=stream)
    xbmcplugin.setResolvedUrl(plugin.handle, True, list_item)


@plugin.route('/autosalon_sk_list/')
def autosalon_sk_list():
    pg = plugin.args['page'][0]
    name_list = []
    listing = []
    req = requests.get("http://www.auto-salon.sk/tv-relacia?id=28&pg=" + str(pg)).content
    soup = BeautifulSoup(req, 'html.parser')
    items = soup.find_all('table',{'class':'articles-list'},True)
    paging = soup.find_all('div',{'class':'paging-arrows'},True)[1].find_all('a')
    for item in items:
        for x in range(0, len(item) - 1):
            i = item.find_all('h2',{'class':'articles-list-title'}, True)[x]
            t = i.text
            u = i.find_all('a')[0].attrs['href']

            name_list.append((t, u, os.path.join(xbmcvfs.translatePath('special://home/addons/plugin.video.autosalontv'),'img', 'autosalonsk.jpg')))
    if paging != []:
        name_list.append(("Další", "pg", ""))
    for category in name_list:
        list_item = xbmcgui.ListItem(label=category[0])
        list_item.setInfo('video', {'title': category[0], "genre": "Publicistický / Sportovní"})
        list_item.setArt({'thumb':category[2] , 'icon': category[2]})
        if category[1] == "pg":
            pg = int(pg) + 1
            listing.append((plugin.url_for(autosalon_sk_list, page = str(pg)), list_item, True))
        else:
            list_item.setProperty('IsPlayable', 'true')
            listing.append((plugin.url_for(autosalon_sk_play, show_url = category[1]), list_item, False))
    xbmcplugin.addDirectoryItems(plugin.handle, listing, len(listing))
    xbmcplugin.endOfDirectory(plugin.handle)


@plugin.route('/autosalon_tv_play/')
def autosalon_tv_play():
    link = plugin.args['show_url'][0]
    html = requests.get(link, headers = {"referer": "https://www.autosalon.tv/"}).content
    sid=re.findall('sid=(.*?)"',str(html), re.DOTALL)[0]
    html = requests.get("https://video.onnetwork.tv/embed.php?sid=" + sid, headers = {"referer": "https://www.autosalon.tv/"}).content
    ver = re.findall('version":"(.*?)"',str(html), re.DOTALL)[0]
    mid = re.findall('mid":"(.*?)"',str(html), re.DOTALL)[0]
    html = requests.get("https://video.onnetwork.tv/frame" + ver + ".php?mid=" + mid, headers = {"referer": "https://www.autosalon.tv/"}).content
    urls = re.findall('playerVideos=(.*?);',str(html), re.DOTALL)[0]
    url = json.loads(urls)[0]["url"]
    stream = url.replace("\\", "")
    list_item = xbmcgui.ListItem(path=stream)
    xbmcplugin.setResolvedUrl(plugin.handle, True, list_item)


@plugin.route('/autosalon_tv_list/')
def autosalon_tv_list():
    xbmcplugin.setContent(plugin.handle, 'episodes')
    link = plugin.args['show_url'][0]
    name_list = []
    listing = []
    html = requests.get(link).content
    soup = BeautifulSoup(html, 'html.parser')
    items = soup.find_all('div',{'class':'container-fluid cards-container cards-container-episodes'},True)
    for item in items:
        for x in range(0, len(item)):
            try:
                title = item.find_all('div',{'class':'title'}, True)[x].text
                title = title[:-10] + " - " + title[-10:]
                if title:
                    img = item.find_all('img')[x].attrs['src'].replace("small", "large")
                    plot = item.find_all('div',{'class':'subtitle'},True)[x].text
                    url = "https://autosalon.tv" + item.find_all('a')[x].attrs['href']
                    name_list.append((title, img, plot, url))
            except: pass
    for category in name_list:
        list_item = xbmcgui.ListItem(label=category[0])
        list_item.setInfo('video', {'title': category[0], "plot": category[2],  "genre": "Publicistický / Sportovní"})
        list_item.setArt({'thumb':category[1] , 'icon': category[1], 'fanart': category[1]})
        list_item.setProperty('IsPlayable', 'true')
        listing.append((plugin.url_for(autosalon_tv_play, show_url = category[3]), list_item, False))
    xbmcplugin.addDirectoryItems(plugin.handle, listing, len(listing))
    xbmcplugin.endOfDirectory(plugin.handle)


@plugin.route('/autosalon_tv_season/')
def autosalon_tv_season():
    xbmcplugin.setContent(plugin.handle, 'tvshows')
    name_list = []
    listing = []
    html = requests.get("https://autosalon.tv/epizody").content
    soup = BeautifulSoup(html, 'html.parser')
    items = soup.find_all('div',{'class':'container-fluid cards-container cards-container-seasons'},True)
    for item in items:
        for x in range(0, len(item) + 2):
            title = item.select('h3')[x].string + '/ ' + item.select('h4')[x].string
            year = item.select('h3')[x].string[-5:]
            url = "https://autosalon.tv" + item.find_all('a')[x].attrs['href']
            name_list.append((title, url, year))
    for category in name_list:
        list_item = xbmcgui.ListItem(label=category[0])
        listing.append((plugin.url_for(autosalon_tv_list, show_url = category[1]), list_item, True))
    xbmcplugin.addDirectoryItems(plugin.handle, listing, len(listing))
    xbmcplugin.endOfDirectory(plugin.handle)


@plugin.route('/')
def root():
    listing = []
    list_item = xbmcgui.ListItem("Autosalon TV")
    list_item.setArt({'icon': os.path.join(xbmcvfs.translatePath('special://home/addons/plugin.video.autosalontv'),'img', 'autosalontv.png')})
    listing.append((plugin.url_for(autosalon_tv_season), list_item, True))
    list_item = xbmcgui.ListItem("Autosalón SK")
    list_item.setArt({'icon': os.path.join(xbmcvfs.translatePath('special://home/addons/plugin.video.autosalontv'),'img', 'autosalonsk.jpg')})
    listing.append((plugin.url_for(autosalon_sk_list, page = "0"), list_item, True))
    list_item = xbmcgui.ListItem("Autožurnál")
    list_item.setArt({'icon': os.path.join(xbmcvfs.translatePath('special://home/addons/plugin.video.autosalontv'),'img', 'autozurnal.jpg')})
    listing.append((plugin.url_for(autozurnal_list, page = "1"), list_item, True))
    xbmcplugin.addDirectoryItems(plugin.handle, listing, len(listing))
    xbmcplugin.endOfDirectory(plugin.handle)


plugin.run()
