# -*- coding: utf-8 -*-

import sys
import os
import xbmcgui
import xbmcplugin
import xbmcaddon
from urllib.parse import urlencode, quote, urlparse, parse_qsl
import requests
import re
from bs4 import BeautifulSoup


_url = sys.argv[0]
_handle = int(sys.argv[1])


def get_url(**kwargs):
    return '{0}?{1}'.format(_url, urlencode(kwargs))


def season(link, year):
    name_list = []
    html = requests.get(link).content
    soup = BeautifulSoup(html, 'html.parser')
    items = soup.find_all('div',{'class':'container-fluid cards-container cards-container-episodes'},True)
    for item in items:
        for x in range(0, len(item)):
            try:
                title = item.find_all('div',{'class':'title'}, True)[x].text
                title = title[:-10] + " - " + title[-10:]
                if title:
                    img = item.find_all('img')[x].attrs['src'].replace("small", "large")
                    plot = item.find_all('div',{'class':'subtitle'},True)[x].text
                    url = "https://autosalon.tv" + item.find_all('a')[x].attrs['href']
                    name_list.append((title, img, plot, url))
            except: pass
    xbmcplugin.setContent(_handle, 'videos')
    for category in name_list:
        list_item = xbmcgui.ListItem(label=category[0])
        list_item.setInfo('video', {'mediatype' : 'tvshow', 'title': category[0], "plot": category[2], "year": year, "genre": "Publicistický / Sportovní"})
        list_item.setArt({'thumb':category[1] , 'icon': category[1], 'fanart': category[1]})
        list_item.setProperty('IsPlayable', 'true')
        url = get_url(action='play', link = category[3])
        xbmcplugin.addDirectoryItem(_handle, url, list_item, False)
    xbmcplugin.endOfDirectory(_handle)


def list_menu():
    name_list = []
    html = requests.get("https://autosalon.tv/epizody").content
    soup = BeautifulSoup(html, 'html.parser')
    items = soup.find_all('div',{'class':'container-fluid cards-container cards-container-seasons'},True)
    for item in items:
        for x in range(0, len(item) + 2):
            title = item.select('h3')[x].string + '/ ' + item.select('h4')[x].string
            year = item.select('h3')[x].string[-5:]
            url = "https://autosalon.tv" + item.find_all('a')[x].attrs['href']
            name_list.append((title, url, year))
    for category in name_list:
        list_item = xbmcgui.ListItem(label=category[0])
        url = get_url(action='listing_season', link = category[1], year = category[2])
        xbmcplugin.addDirectoryItem(_handle, url, list_item, True)
    xbmcplugin.endOfDirectory(_handle)


def play_video(link):
    html = requests.get(link, headers = {"referer": "https://www.autosalon.tv/"}).content
    sid=re.findall('sid=(.*?)"',str(html), re.DOTALL)[0]
    html = requests.get("https://video.onnetwork.tv/embed.php?sid=" + sid, headers = {"referer": "https://www.autosalon.tv/"}).content
    ver = re.findall('version":"(.*?)"',str(html), re.DOTALL)[0]
    mid = re.findall('mid":"(.*?)"',str(html), re.DOTALL)[0]
    html = requests.get("https://video.onnetwork.tv/frame" + ver + ".php?mid=" + mid, headers = {"referer": "https://www.autosalon.tv/"}).content
    urls = re.findall('"hls"(.*?)3u8',str(html), re.DOTALL)[0]
    url = re.findall('"url": "(.*?).m',str(urls), re.DOTALL)[-1]
    stream = url.replace("\\", "") + ".m3u8"
    listitem = xbmcgui.ListItem(path=stream)
    xbmcplugin.setResolvedUrl(_handle, True, listitem)


def router(paramstring):
    params = dict(parse_qsl(paramstring))
    if params:
        if params["action"] == "listing_season":
            season(params["link"], params["year"])
        elif params["action"] == "play":
            play_video(params["link"])
    else:
        list_menu()


if __name__ == '__main__':
    router(sys.argv[2][1:])
