#-*-coding:utf8;-*-
import time, requests, os, json, unicodedata, xbmcaddon, xbmc, sys, xbmcgui, xbmcplugin, xbmcvfs, uuid, time
from urllib.parse import urlparse, parse_qsl
from datetime import datetime, timedelta
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry
try:
    from resources.lib import xmltv
except:
    import xmltv
try:
    from resources.lib.ffmpeg_progress_yield import FfmpegProgress
except:
    from ffmpeg_progress_yield import FfmpegProgress


service_type = {"0": "LIVE", "1": "TIMESHIFT"}
addon = xbmcaddon.Addon(id='script.tvgo.playlist')
if addon.getSetting("provider") == "0":
    dev_types = {"0": "OTT_LINUX_4302", "1": "OTT_STB", "2": "OTT_ANDROID"}
    dev_names = {"0": "LGG50UP7500", "1": "KSTB6077", "2": "Xiaomi Mi 11"}
    user = addon.getSetting("login_cz")
    password = addon.getSetting("password_cz")
    lng = "cz"
    dev_type = dev_types[addon.getSetting("device_cz")]
    dev_name = dev_names[addon.getSetting("device_cz")]
else:
    dev_types = {"0": "OTT_STB", "1": "OTT_ANDROID"}
    dev_names = {"0": "KSTB6077", "1": "Xiaomi Mi 11"}
    user = addon.getSetting("login_sk")
    password = addon.getSetting("password_sk")
    lng = "sk"
    dev_type = dev_types[addon.getSetting("device_sk")]
    dev_name = dev_names[addon.getSetting("device_sk")]
profile = xbmcvfs.translatePath(addon.getAddonInfo('profile')).encode().decode("utf-8")
addon_dir = xbmcvfs.translatePath( addon.getAddonInfo('path') )
addon_icon = os.path.join(addon_dir, "icon.png")
fs = os.path.join(addon.getSetting("playlist_folder"), "tvgo_" + lng + ".m3u")
fcho = os.path.join(profile, "order.json")
fe = os.path.join(addon.getSetting("playlist_folder"), "tvgo_" + lng + ".xml")
tfs = os.path.join(profile, "temp_tvgo.m3u")
tfe = os.path.join(profile, "temp_tvgo.xml")
ft = os.path.join(profile,"token_" + lng + ".json")
UA = "okhttp/3.12.12"
dev_id = str(addon.getSetting("uuid_" + lng))
if dev_id == "":
    dev_id = str(uuid.uuid4())
    addon.setSetting(id='uuid_' + lng, value=dev_id)
qu_d = {"0": "p5", "1": "p4", "2": "p3"}
qu = qu_d[addon.getSetting("quality")]
now = datetime.now()
local_now = now.astimezone()
TimeShift = " " + str(local_now)[-6:].replace(":", "")


def encode(string):
    string = str(unicodedata.normalize('NFKD', string).encode('ascii', 'ignore'), "utf-8")
    return string


def restore_token():
    xbmcvfs.delete(ft)
    xbmcgui.Dialog().notification("TV GO Playlist","Obnoveno", xbmcgui.NOTIFICATION_INFO, 4000, sound = False)


def login():
    params={"dsid": dev_id, "deviceName": dev_name, "deviceType": dev_type, "osVersion": "0.0.0", "appVersion": "0.0.0", "language": "EN"}
    headers={"Host": lng + "go.magio.tv", "User-Agent": UA}
    req = requests.post("https://" + lng + "go.magio.tv/v2/auth/init", params=params, headers=headers).json()
    if req["success"] == True:
        accessToken = req["token"]["accessToken"]
        params = {"loginOrNickname": user, "password": password}
        headers = {"Content-type": "application/json", "authorization": "Bearer " + accessToken, "Host": lng + "go.magio.tv", "User-Agent": UA, "Connection": "Keep-Alive"}
        req = requests.post("https://" + lng + "go.magio.tv/v2/auth/login", json = params, headers = headers).json()
        if req["success"] == True:
            f = open(ft, "w")
            f.write(json.dumps(req))
            f.close()
            accesstoken = req["token"]["accessToken"]
            refreshtoken = req["token"]["refreshToken"]
            return refreshtoken, accesstoken
        else:
            xbmcgui.Dialog().notification("TV GO Playlist",req["errorMessage"], xbmcgui.NOTIFICATION_ERROR, 4000, sound = True)
            return None, None
    else:
        xbmcgui.Dialog().notification("TV GO Playlist",req["errorMessage"], xbmcgui.NOTIFICATION_ERROR, 4000, sound = True)
        return None, None


def delete_device():
    refreshtoken, accesstoken = login()
    if refreshtoken == None:
        return
    f = open(ft, "r")
    data = json.load(f)
    expiresIn = data["token"]["expiresIn"]
    accesstoken = data["token"]["accessToken"]
    refreshtoken = data["token"]["refreshToken"]
    if expiresIn < int(time.time() * 1000):
        refreshtoken, accesstoken = login()
    params={"refreshToken": refreshtoken}
    headers = {"Content-type": "application/json", "Host": lng + "go.magio.tv", "User-Agent": UA, "Connection": "Keep-Alive"}
    req = requests.post("https://" + lng + "go.magio.tv/v2/auth/tokens", json = params, headers = headers).json()
    if req["success"] == True:
        accesstoken2 = req["token"]["accessToken"]
    else:
        xbmcgui.Dialog().notification("TV GO Playlist",req["errorMessage"], xbmcgui.NOTIFICATION_ERROR, 4000, sound = True)
        return
    headers = {"Content-type": "application/json", "authorization": "Bearer " + accesstoken2, "Host": lng + "go.magio.tv", "User-Agent": UA, "Connection": "Keep-Alive"}
    req = requests.get("https://" + lng + "go.magio.tv/v2/home/my-devices", headers = headers).json()
    devices = []
    try:
            devices.append((req["thisDevice"]["name"] + " (Toto zařízení)", req["thisDevice"]["id"]))
    except:
            pass
    try:
        for d in req["smallScreenDevices"]:
            devices.append((d["name"], d["id"]))
    except:
            pass
    try:
        for d in req["stbAndBigScreenDevices"]:
            devices.append((d["name"], d["id"]))
    except:
            pass
    choose = xbmcgui.Dialog().select("Odebrat zařízení", [i[0] for i in devices])

    if choose == -1: return
    else:
        dev_id = devices[choose][1]
    req = requests.get("https://" + lng + "go.magio.tv/home/deleteDevice?id=" + str(dev_id), headers = headers).json()
    if req["success"] == True:
        if choose == 0 and os.path.exists(ft):
            xbmcvfs.delete(ft)
            addon.setSetting(id='uuid_' + lng, value="")
        xbmcgui.Dialog().notification("TV GO Playlist","Odebráno", xbmcgui.NOTIFICATION_INFO, 4000, sound = False)
    else:
        xbmcgui.Dialog().notification("TV GO Playlist",req["errorMessage"], xbmcgui.NOTIFICATION_ERROR, 4000, sound = True)


def epg(dlg, token, channels, tm_ids, d, d_b):
    st = 1
    if dlg == True:
        dialog = xbmcgui.DialogProgressBG()
        dialog.create("TV GO EPG", "")
        dialog.update(0, "TV GO EPG", "Stahování dat...")
    programmes = []
    session = requests.Session()
    retry = Retry(connect=3, backoff_factor=0.5)
    adapter = HTTPAdapter(max_retries=retry)
    session.mount('http://', adapter)
    session.mount('https://', adapter)
    headers = {"Content-type": "application/json", "authorization": "Bearer " + token, "Host": lng + "go.magio.tv", "User-Agent": UA, "Connection": "Keep-Alive"}
    now = datetime.now()
    for i in range(d_b*-1, d):
        next_day = now + timedelta(days = i)
        back_day = (now + timedelta(days = i)) - timedelta(days = 1)
        date_to = next_day.strftime("%Y-%m-%d")
        date_from = back_day.strftime("%Y-%m-%d")
        date_ = next_day.strftime("%d.%m.%Y")
        per = int(int(d) + int(d_b))
        percent = int((float(st*100) / per))
        req = session.get("https://" + lng + "go.magio.tv/v2/television/epg?filter=channel.id=in=(" + str(tm_ids[1:]) + ");endTime=ge=" + date_from + "T23:00:00.000Z;startTime=le=" + date_to + "T23:59:59.999Z&limit=" + str(len(channels)) + "&offset=0&lang=" + lng.upper(), headers=headers).json()["items"]
        for x in range(0, len(req)):
            for y in req[x]["programs"]:
                id = y["channel"]["id"]
                name = y["channel"]["name"]
                channel = "tm-" + str(id) + "-" + encode(name).replace(" HD", "").lower().replace(" ", "-")
                start_time = y["startTime"].replace("-", "").replace("T", "").replace(":", "")
                stop_time = y["endTime"].replace("-", "").replace("T", "").replace(":", "")
                title = y["program"]["title"]
                desc = y["program"]["description"]
                year = y["program"]["programValue"]["creationYear"]
                try:
                    subgenre = y["program"]["programCategory"]["subCategories"][0]["desc"]
                except:
                    subgenre = ''
                try:
                    genre = [(y["program"]["programCategory"]["desc"], u''), (subgenre, u'')]
                except:
                    genre = None
                try:
                    icon = y["program"]["images"][0]
                except:
                    icon = None
                epi = y["program"]["programValue"]["episodeId"]
                if epi != None:
                    title = title + " (" + epi + ")"
                try:
                    programm = {'channel': str(channel), 'start': start_time + TimeShift, 'stop': stop_time + TimeShift, 'title': [(title, u'')],  'desc': [(desc, u'')]}
                    if year != None:
                        programm['date'] = year
                    if genre != None:
                        programm['category'] = genre
                    if icon != None:
                        programm['icon'] = [{"src": icon}]
                except:
                    pass
                if programm not in programmes:
                    programmes.append(programm)
        if dlg == True:
            dialog.update(percent, "TV GO EPG", date_)
        st += 1
    if dlg == True:
        dialog.update(0, "TV GO EPG","")
    session.close()
    w = xmltv.Writer(encoding="utf-8", source_info_url="http://www.funktronics.ca/python-xmltv", source_info_name="Funktronics", generator_info_name="python-xmltv", generator_info_url="http://www.funktronics.ca/python-xmltv")
    for c in channels:
        w.addChannel(c)
        stch = 1
    for p in programmes:
        w.addProgramme(p)
        per = len(programmes)
        percent = int((float(stch*100) / per))
        if dlg == True:
            dialog.update(percent, "Generuji...", p["channel"])
        stch += 1
    if dlg == True:
        dialog.update(0, "TV GO EPG", "Ukládání...")
    w.write(tfe, pretty_print=True)
    xbmcvfs.copy(tfe, fe)
    if dlg == True:
        dialog.close()
    xbmcgui.Dialog().notification("TV GO Playlist","EPG aktualizováno", sound = False, icon = addon_icon)


def restart_pvr():
    try:
        time.sleep(1)
        addon_pvr = xbmcaddon.Addon('pvr.iptvsimple')
        xbmc.executeJSONRPC('{{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{{"addonid":"{}","enabled":false}}}}'.format('pvr.iptvsimple'))
        addon_pvr.setSetting('m3uPathType', '0')
        addon_pvr.setSetting('m3uPath', fs)
        if addon.getSetting("enable_epg") == "true":
            addon_pvr.setSetting('epgPathType', '0')
            addon_pvr.setSetting('epgPath', fe)
        time.sleep(3)
        xbmc.executeJSONRPC('{{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{{"addonid":"{}","enabled":true}}}}'.format('pvr.iptvsimple'))
    except:
        xbmcgui.Dialog().notification("TV GO Playlist","Nelze nastavit/restartova PVR klienta", xbmcgui.NOTIFICATION_ERROR, 4000, sound = False)


def playlist(dlg, upd):
    if not os.path.exists(ft):
        refreshtoken, accesstoken = login()
        if refreshtoken == None:
            return
    f = open(ft, "r")
    data = json.load(f)
    expiresIn = data["token"]["expiresIn"]
    accesstoken = data["token"]["accessToken"]
    refreshtoken = data["token"]["refreshToken"]
    if expiresIn < int(time.time() * 1000) or dlg == False:
        refreshtoken, accesstoken = login()
    if dlg == True:
        dialog = xbmcgui.DialogProgressBG()
        dialog.create("TV GO Playlist", "")
    params={"refreshToken": refreshtoken}
    headers = {"Content-type": "application/json", "Host": lng + "go.magio.tv", "User-Agent": UA, "Connection": "Keep-Alive"}
    req = requests.post("https://" + lng + "go.magio.tv/v2/auth/tokens", json = params, headers = headers).json()
    if req["success"] == True:
        accesstoken2 = req["token"]["accessToken"]
    else:
        xbmcgui.Dialog().notification("TV GO Playlist",req["errorMessage"], xbmcgui.NOTIFICATION_ERROR, 4000, sound = True)
        if dlg == True:
            dialog.close()
        return
    session = requests.Session()
    retry = Retry(connect=3, backoff_factor=0.5)
    adapter = HTTPAdapter(max_retries=retry)
    session.mount('http://', adapter)
    session.mount('https://', adapter)
    params={"list": "LIVE", "queryScope": "LIVE"}
    headers = {"Content-type": "application/json", "authorization": "Bearer " + accesstoken2, "Host": lng + "go.magio.tv", "User-Agent": UA, "Connection": "Keep-Alive"}
    req = session.get("https://" + lng + "go.magio.tv/v2/television/channels", params = params, headers = headers).json()
    channels = []
    channels2 = []
    ids = ""
    reqq = requests.get("https://" + lng + "go.magio.tv/home/categories?language=" + lng, headers = headers).json()["categories"]
    categories = {}
    for cc in reqq:
        for c in cc["channels"]:
            categories [c["channelId"]] = cc["name"]
    for n in req["items"]:
        name = n["channel"]["name"]
        logo = str(n["channel"]["logoUrl"])
        idd = n["channel"]["channelId"]
        ids = ids + "," + str(idd)
        if idd == 5000:
            idd = 6016
            name = "Eurosport 1"
        id = "tm-" + str(idd) + "-" + encode(name).replace(" HD", "").lower().replace(" ", "-")
        channels2.append(({"display-name": [(name, u"cs")], "id": str(id), "icon": [{"src": logo}]}))
        channels.append((name, idd, logo))
    if os.path.exists(fcho):
        ff = open(fcho).read()
        order = json.loads(ff)
    else:
        order = None
    f = open(tfs, "w", encoding="utf-8")
    f.write("#EXTM3U\n")
    per = len(channels)
    stch = 1
    oo = {}
    for ch in channels:
        percent = int((float(stch*100) / per))
        if addon.getSetting("playlist_vlc") == "true":
            params={"service": service_type[addon.getSetting("service")], "name": dev_name, "devtype": dev_type, "id": ch[1], "prof": qu, "ecid": "", "drm": "verimatrix"}
            headers = {"Content-type": "application/json", "authorization": "Bearer " + accesstoken2, "Host": lng + "go.magio.tv", "User-Agent": UA, "Connection": "Keep-Alive"}
            req = session.get("https://" + lng + "go.magio.tv/v2/television/stream-url", params = params, headers = headers)
            if req.json()["success"] == True:
                url = req.json()["url"]
            else:
                if req.json()["success"] == False and req.json()["errorCode"] == "NO_PACKAGE":
                    url = None
                else:
                    xbmcgui.Dialog().notification("TV GO Playlist",req.json()["errorMessage"].replace("exceeded-max-device-count", "Překročen maximální počet zařízení"), xbmcgui.NOTIFICATION_ERROR, 4000, sound = True)
                    if dlg == True:
                        dialog.close()
                    if "DEVICE_MAX_LIMIT" in str(req.json()):
                        delete_device()
                    return
            id = "tm-" + str(ch[1]) + "-" + encode(ch[0]).replace(" HD", "").lower().replace(" ", "-")
            if ch[1] == 5000:
                id = "tm-6016-eurosport-1"
            group = categories[ch[1]]
            if lng == "sk" or lng == "cz":
                if url is not None:
                    headers = {"Host": urlparse(url).netloc, "User-Agent": "ReactNativeVideo/3.13.2 (Linux;Android 10) ExoPlayerLib/2.10.3", "Connection": "Keep-Alive"}
                    req = session.get(url, headers = headers, allow_redirects=False)
                    url = str(req.headers["location"])
        else:
            id = "tm-" + str(ch[1]) + "-" + encode(ch[0]).replace(" HD", "").lower().replace(" ", "-")
            if ch[1] == 5000:
                id = "tm-6016-eurosport-1"
            group = categories[ch[1]]
            url = "plugin://script.tvgo.playlist/play/" + str(ch[1])
        catchup = ' catchup-days="7" catchup-source="plugin://script.tvgo.playlist/catchup/' + str(ch[1]) + '/${start}-${end}"'
        if addon.getSetting("input_stream") == "true" and addon.getSetting("playlist_vlc") == "true" and url is not None:
            if ".m3u8" in url:
                inputstrem = "#KODIPROP:inputstreamaddon=inputstream.adaptive\n#KODIPROP:inputstream.adaptive.manifest_type=hls\n#KODIPROP:mimetype=application/vnd.apple.mpegurl\n"
            else:
                inputstrem = "#KODIPROP:inputstreamaddon=inputstream.adaptive\n#KODIPROP:inputstream.adaptive.manifest_type=mpd\n#KODIPROP:mimetype=application/dash+xml\n"
        else:
            inputstrem = ""
        ord = str(int(stch) + 1000)
        if url is not None:
            if order is not None:
                try:
                    for key, value in order.items():
                        if value[0] == str(ch[0]):
                            ord = str(int(key) + 1)
                except:
                    ord = str(int(stch) + 1000)
            else:
                ord = str(int(stch))
            f.write('#EXTINF:-1 tvg-chno="' + str(ord) + '" group-title="' + group + '" tvg-id="' + id +  '"' + catchup + ' tvg-logo="' + ch[2] + '" tvg-name="' + str(ch[0]) + '"' + ',' +str(ch[0]) + '\n' + inputstrem + url + '\n')
            oo[stch - 1] = [str(ch[0]), ch[2], "", "item", "-"]
        if dlg == True:
            dialog.update(percent, "TV GO Playlist", ch[0])
        stch += 1
    f.close()
    session.close()
    if not os.path.exists(fcho):
        ord = json.dumps(oo)
        ff = open(fcho, "w")
        ff.write(ord)
        ff.close()
    if dlg == True:
        dialog.close()
        xbmcvfs.copy(tfs, fs)
        xbmcgui.Dialog().notification("TV GO Playlist","Playlist aktualizován", sound = False, icon = addon_icon)
    else:
        if addon.getSetting("playlist_vlc") == "true":
            xbmcvfs.copy(tfs, fs)
            xbmcgui.Dialog().notification("TV GO Playlist","Playlist aktualizován", sound = False, icon = addon_icon)
    if upd == True and addon.getSetting("enable_epg") == "true":
        epg(dlg, accesstoken2, channels2, ids, int(addon.getSetting("num_days")), int(addon.getSetting("num_days_back")))
    if addon.getSetting("restart_pvr") == "true":
        if xbmc.getCondVisibility('System.AddonIsEnabled(pvr.iptvsimple)') == False:
            xbmc.executeJSONRPC('{{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{{"addonid":"{}","enabled":true}}}}'.format('pvr.iptvsimple'))
        restart_pvr()


def catchup(ch_id, t):
    timestamp = t.split("-")
    date_time_start = datetime.fromtimestamp(int(timestamp[0]))
    d_start = date_time_start.strftime("%Y-%m-%dT%H:%M:%S")
    date_time_end = datetime.fromtimestamp(int(timestamp[1]))
    d_end = date_time_end.strftime("%Y-%m-%dT%H:%M:%S")
    if not os.path.exists(ft):
        login()
    f = open(ft, "r")
    data = json.load(f)
    expiresIn = data["token"]["expiresIn"]
    accesstoken = data["token"]["accessToken"]
    refreshtoken = data["token"]["refreshToken"]
    if expiresIn < int(time.time() * 1000):
        refreshtoken, accesstoken = login()
    params={"refreshToken": refreshtoken}
    headers = {"Content-type": "application/json", "authorization": "Bearer " + accesstoken, "Host": lng + "go.magio.tv", "User-Agent": UA, "Connection": "Keep-Alive"}
    req = requests.post("https://" + lng + "go.magio.tv/v2/auth/tokens", json = params, headers = headers).json()
    if req["success"] == True:
        accesstoken2 = req["token"]["accessToken"]
    else:
        xbmcgui.Dialog().notification("TV GO Playlist",req["errorMessage"], xbmcgui.NOTIFICATION_ERROR, 4000, sound = True)
        return
    now = datetime.now()
    current_time = now.strftime("%Y-%m-%dT%H:%M:%S")
    date_time_end = date_time_end + timedelta(seconds=15)
    d_end = date_time_end.strftime("%Y-%m-%dT%H:%M:%S")
    headers = {"Content-type": "application/json", "authorization": "Bearer " + accesstoken2, "Host": lng + "go.magio.tv", "User-Agent": UA, "Connection": "Keep-Alive"}
    req = requests.get("https://" + lng + "go.magio.tv/v2/television/epg?filter=channel.id==" + ch_id + "%20and%20startTime=ge=" + d_start + ".000Z%20and%20endTime=le=" + d_end + ".000Z&limit=10&offset=0&lang=" + lng.upper(),headers = headers).json()
    if req["success"] == False:
        xbmcgui.Dialog().notification("TV GO Playlist",req["errorMessage"], xbmcgui.NOTIFICATION_ERROR, 4000, sound = True)
        return        
    else:
        if req["items"] != []:
            scheduleId = str(req["items"][0]["programs"][0]["scheduleId"])
            params={"service": "ARCHIVE", "name": dev_name, "devtype": dev_type, "id": scheduleId, "prof": qu, "ecid": "", "drm": "verimatrix"}
            headers = {"Content-type": "application/json", "authorization": "Bearer " + accesstoken2, "Host": lng + "go.magio.tv", "User-Agent": UA, "Connection": "Keep-Alive"}
            req = requests.get("https://" + lng + "go.magio.tv/v2/television/stream-url", params = params, headers = headers).json()
            if req["success"] == True:
                url = req["url"]
                headers = {"Host": urlparse(url).netloc, "User-Agent": "ReactNativeVideo/3.13.2 (Linux;Android 10) ExoPlayerLib/2.10.3", "Connection": "Keep-Alive"}
                req = requests.get(url, headers = headers, allow_redirects=False)
                stream = req.headers["location"]
            else:
                xbmcgui.Dialog().notification("TV GO Playlist",req["errorMessage"], xbmcgui.NOTIFICATION_ERROR, 4000, sound = True)
                return
        else:
            params={"service": "TIMESHIFT", "name": dev_name, "devtype": dev_type, "id": ch_id, "prof": qu, "ecid": "", "drm": "verimatrix"}
            headers = {"Content-type": "application/json", "authorization": "Bearer " + accesstoken2, "Host": lng + "go.magio.tv", "User-Agent": UA, "Connection": "Keep-Alive"}
            req = requests.get("https://" + lng + "go.magio.tv/v2/television/stream-url", params = params, headers = headers).json()
            if req["success"] == True:
                url = req["url"]
            else:
                xbmcgui.Dialog().notification("TV GO Playlist",req["errorMessage"], xbmcgui.NOTIFICATION_ERROR, 4000, sound = True)
                return
            headers = {"Host": urlparse(url).netloc, "User-Agent": "ReactNativeVideo/3.13.2 (Linux;Android 10) ExoPlayerLib/2.10.3", "Connection": "Keep-Alive"}
            req = requests.get(url, headers = headers, allow_redirects=False)
            stream = req.headers["location"]
    listitem = xbmcgui.ListItem(path=stream)
    listitem.setContentLookup(False)
    if ".mpd" in stream:
        listitem.setMimeType('application/xml+dash')
        listitem.setProperty('inputstream', 'inputstream.adaptive')
        listitem.setProperty('inputstream.adaptive.manifest_type', 'mpd')
    _handle = int(sys.argv[1]) if len(sys.argv) > 1 else -1
    xbmcplugin.setResolvedUrl(_handle, True, listitem)


def play_vlc():
    name = xbmc.getInfoLabel('Listitem.ChannelName')
    ind = None
    f = open (fs, encoding='utf-8').read().splitlines()
    for x in f:
        if name in x:
            if addon.getSetting("input_stream") == "true":
                ind = f.index(x) + 3
            else:
                ind = f.index(x) + 1
    if ind is not None:
        stream = f[ind]
    else:
        return
    if addon.getSetting("vlc") == "0":
        url = stream
    else:
        url = fs
#    app = 'org.videolan.vlc'
    app = ''
    intent   = 'android.intent.action.VIEW'
    dataType = 'video/*'
    cmd = 'StartAndroidActivity("%s", "%s", "%s", "%s")' % (app, intent, dataType, url)
    xbmc.executebuiltin(cmd)


def play(ch_id):
    if not os.path.exists(ft):
        refreshtoken, accesstoken = login()
        if refreshtoken == None:
            return
    f = open(ft, "r")
    data = json.load(f)
    expiresIn = data["token"]["expiresIn"]
    accesstoken = data["token"]["accessToken"]
    refreshtoken = data["token"]["refreshToken"]
    if expiresIn < int(time.time() * 1000):
        refreshtoken, accesstoken = login()
    params={"refreshToken": refreshtoken}
    headers = {"Content-type": "application/json", "authorization": "Bearer " + accesstoken, "Host": lng + "go.magio.tv", "User-Agent": UA, "Connection": "Keep-Alive"}
    req = requests.post("https://" + lng + "go.magio.tv/v2/auth/tokens", json = params, headers = headers).json()
    if req["success"] == True:
        accesstoken2 = req["token"]["accessToken"]
    else:
        xbmcgui.Dialog().notification("TV GO Playlist",req["errorMessage"], xbmcgui.NOTIFICATION_ERROR, 4000, sound = True)
        return
    params={"service": service_type[addon.getSetting("service")], "name": dev_name, "devtype": dev_type, "id": ch_id, "prof": qu, "ecid": "", "drm": "verimatrix"}
    headers = {"Content-type": "application/json", "authorization": "Bearer " + accesstoken2, "Host": lng + "go.magio.tv", "User-Agent": UA, "Connection": "Keep-Alive"}
    req = requests.get("https://" + lng + "go.magio.tv/v2/television/stream-url", params = params, headers = headers)
    if req.json()["success"] == True:
        url = req.json()["url"]
    else:
        xbmcgui.Dialog().notification("TV GO Playlist",req.json()["errorMessage"], xbmcgui.NOTIFICATION_ERROR, 4000, sound = True)
        if "DEVICE_MAX_LIMIT" in str(req.json()):
            time.sleep(2)
            delete_device()
        return
    headers = {"Host": urlparse(url).netloc, "User-Agent": "ReactNativeVideo/3.13.2 (Linux;Android 10) ExoPlayerLib/2.10.3", "Connection": "Keep-Alive"}
    req = requests.get(url, headers = headers, allow_redirects=False)
    stream = req.headers["location"]
    listitem = xbmcgui.ListItem(path=stream)
    listitem.setContentLookup(False)
    if ".m3u8" in stream:
        listitem.setMimeType('application/vnd.apple.mpegurl')
        if addon.getSetting("input_stream") == "true":
            listitem.setProperty('inputstream', 'inputstream.adaptive')
            listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
    else:
        listitem.setMimeType('application/xml+dash')
        if addon.getSetting("input_stream") == "true" or lng == "sk":
            listitem.setProperty('inputstream', 'inputstream.adaptive')
            listitem.setProperty('inputstream.adaptive.manifest_type', 'mpd')
    _handle = int(sys.argv[1]) if len(sys.argv) > 1 else -1
    xbmcplugin.setResolvedUrl(_handle, True, listitem)


def record(ch_id, t, file_name):
    if addon.getSetting("record_folder") == "":
        xbmcgui.Dialog().notification("TV GO Playlist", "Nastavte složku pro stahování", xbmcgui.NOTIFICATION_ERROR, 4000, sound = True)
        return
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    if not os.path.exists(ft):
        refreshtoken, accesstoken = login()
        if refreshtoken == None:
            return
    f = open(ft, "r")
    data = json.load(f)
    expiresIn = data["token"]["expiresIn"]
    accesstoken = data["token"]["accessToken"]
    refreshtoken = data["token"]["refreshToken"]
    if expiresIn < int(time.time() * 1000):
        refreshtoken, accesstoken = login()
    params={"refreshToken": refreshtoken}
    headers = {"Content-type": "application/json", "Host": lng + "go.magio.tv", "User-Agent": UA, "Connection": "Keep-Alive"}
    req = requests.post("https://" + lng + "go.magio.tv/v2/auth/tokens", json = params, headers = headers).json()
    if req["success"] == True:
        accesstoken2 = req["token"]["accessToken"]
    else:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        xbmcgui.Dialog().notification("TV GO Playlist",req["errorMessage"], xbmcgui.NOTIFICATION_ERROR, 4000, sound = True)
        return
    params={"list": "LIVE", "queryScope": "LIVE"}
    headers = {"Content-type": "application/json", "authorization": "Bearer " + accesstoken2, "Host": lng + "go.magio.tv", "User-Agent": UA, "Connection": "Keep-Alive"}
    req = requests.get("https://" + lng + "go.magio.tv/v2/television/channels", params = params, headers = headers).json()
    channel = {}
    for n in req["items"]:
        channel[n["channel"]["name"]] = n["channel"]["channelId"]
    ch_id = str(channel[ch_id])
    timestamp = t.split("-")
    date_time_start = datetime.fromtimestamp(int(timestamp[0]))
    d_start = date_time_start.strftime("%Y-%m-%dT%H:%M:%S")
    date_time_end = datetime.fromtimestamp(int(timestamp[1]))
    d_end = date_time_end.strftime("%Y-%m-%dT%H:%M:%S")
    now = datetime.now()
    current_time = now.strftime("%Y-%m-%dT%H:%M:%S")
    date_time_end = date_time_end + timedelta(seconds=15)
    d_end = date_time_end.strftime("%Y-%m-%dT%H:%M:%S")
    headers = {"Content-type": "application/json", "authorization": "Bearer " + accesstoken2, "Host": lng + "go.magio.tv", "User-Agent": UA, "Connection": "Keep-Alive"}
    req = requests.get("https://" + lng + "go.magio.tv/v2/television/epg?filter=channel.id==" + ch_id + "%20and%20startTime=ge=" + d_start + ".000Z%20and%20endTime=le=" + d_end + ".000Z&limit=10&offset=0&lang=" + lng.upper(),headers = headers).json()
    if req["success"] == False:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        xbmcgui.Dialog().notification("TV GO Playlist",req["errorMessage"], xbmcgui.NOTIFICATION_ERROR, 4000, sound = True)
        return        
    else:
        if req["items"] != []:
            scheduleId = str(req["items"][0]["programs"][0]["scheduleId"])
            params={"service": "ARCHIVE", "name": dev_name, "devtype": dev_type, "id": scheduleId, "prof": qu, "ecid": "", "drm": "verimatrix"}
            headers = {"Content-type": "application/json", "authorization": "Bearer " + accesstoken2, "Host": lng + "go.magio.tv", "User-Agent": UA, "Connection": "Keep-Alive"}
            req = requests.get("https://" + lng + "go.magio.tv/v2/television/stream-url", params = params, headers = headers).json()
            if req["success"] == True:
                stream = req["url"]
            else:
                xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
                xbmcgui.Dialog().notification("TV GO Playlist",req["errorMessage"], xbmcgui.NOTIFICATION_ERROR, 4000, sound = True)
                return
        else:
            params={"service": "TIMESHIFT", "name": dev_name, "devtype": dev_type, "id": ch_id, "prof": qu, "ecid": "", "drm": "verimatrix"}
            headers = {"Content-type": "application/json", "authorization": "Bearer " + accesstoken2, "Host": lng + "go.magio.tv", "User-Agent": UA, "Connection": "Keep-Alive"}
            req = requests.get("https://" + lng + "go.magio.tv/v2/television/stream-url", params = params, headers = headers).json()
            if req["success"] == True:
                url = req["url"]
            else:
                xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
                xbmcgui.Dialog().notification("TV GO Playlist",req["errorMessage"], xbmcgui.NOTIFICATION_ERROR, 4000, sound = True)
                return
            headers = {"Host": urlparse(url).netloc, "User-Agent": "ReactNativeVideo/3.13.2 (Linux;Android 10) ExoPlayerLib/2.10.3", "Connection": "Keep-Alive"}
            req = requests.get(url, headers = headers, allow_redirects=False)
            stream = req.headers["location"]
    xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
    if ".m3u8" in stream:
        download_path = addon.getSetting("record_folder") + file_name + ".mp4"
        download_start = str(int(addon.getSetting("download_start_min"))*60)
        download_end = str(int(addon.getSetting("download_end_min"))*60)
        cmd = ['ffmpeg', '-ss', download_start, '-i', stream , '-t', download_end, '-c:v', 'copy', '-c:a', 'copy', '-map', '0', '-f', 'mpegts', download_path]
        x = 0
        try:
            ff = FfmpegProgress(cmd)
            dialog = xbmcgui.DialogProgressBG()
            dialog.create("TV GO Playlist", "")
            dialog.update(0, "TV GO Playlist", file_name.replace(".mp4", ""))
            for progress in ff.run_command_with_progress():
                if x != progress:
                    dialog.update(int(progress), "TV GO Playlist", file_name.replace(".mp4", ""))
                    x = progress
            dialog.close()
            xbmcgui.Dialog().notification("TV GO Playlist", "Staženo", xbmcgui.NOTIFICATION_INFO, 4000, sound = True)
        except Exception as error:
            dialog.close()
            xbmcgui.Dialog().notification("TV GO Playlist",str(type(error).__name__), xbmcgui.NOTIFICATION_ERROR, 4000, sound = True)
    else:
        xbmcgui.Dialog().notification("TV GO Playlist", "Tento stream nelze stáhnout", xbmcgui.NOTIFICATION_ERROR, 4000, sound = True)