# -*- coding: utf-8 -*-

import xbmc
xbmc.executebuiltin('ShowPicture('+ 'http://saros.wz.cz/repo/PayPal_my_qrcode.jpg'+')')