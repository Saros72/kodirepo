#-*-coding:utf8;-*-
import time, requests, os, json, unicodedata, xbmcaddon, xbmc, sys, xbmcgui, xbmcplugin, xbmcvfs, uuid, time, m3u8
from urllib.parse import urlparse, parse_qsl
from datetime import datetime, timedelta
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry
try:
    from resources.lib import xmltv
except:
    import xmltv


dev_types = {"0": "OTT_TV_WEBOS", "1": "OTT_STB", "2": "OTT_ANDROID"}
dev_names = {"0": "LGG50UP7500", "1": "KSTB6077", "2": "Xiaomi Mi 11"}
service_type = {"0": "LIVE", "1": "TIMESHIFT"}
addon = xbmcaddon.Addon(id='script.tvgo.playlist')
if addon.getSetting("provider") == "0":
    user = addon.getSetting("login_cz")
    password = addon.getSetting("password_cz")
    lng = "cz"
    dev_type = dev_types[addon.getSetting("device_cz")]
    dev_name = dev_names[addon.getSetting("device_cz")]
else:
    user = addon.getSetting("login_sk")
    password = addon.getSetting("password_sk")
    lng = "sk"
    dev_type = dev_types[addon.getSetting("device_sk")]
    dev_name = dev_names[addon.getSetting("device_sk")]
profile = xbmc.translatePath(addon.getAddonInfo('profile')).encode().decode("utf-8")
addon_dir = xbmc.translatePath( addon.getAddonInfo('path') )
addon_icon = os.path.join(addon_dir, "icon.png")
fs = os.path.join(addon.getSetting("playlist_folder"), "tvgo_" + lng + ".m3u")
fcho = os.path.join(profile, "order.json")
fe = os.path.join(addon.getSetting("playlist_folder"), "tvgo_" + lng + ".xml")
tfs = os.path.join(profile, "temp_tvgo.m3u")
tfe = os.path.join(profile, "temp_tvgo.xml")
ft = os.path.join(profile,"token_" + lng + ".json")
UA = "okhttp/3.12.12"
dev_id = str(addon.getSetting("uuid_" + lng))
if dev_id == "":
    dev_id = str(uuid.uuid4())
    addon.setSetting(id='uuid_' + lng, value=dev_id)
qu_d = {"0": "p5", "1": "p4", "2": "p3"}
qu = qu_d[addon.getSetting("quality")]
now = datetime.now()
local_now = now.astimezone()
TimeShift = " " + str(local_now)[-6:].replace(":", "")


def encode(string):
    string = str(unicodedata.normalize('NFKD', string).encode('ascii', 'ignore'), "utf-8")
    return string


def login():
    params={"dsid": dev_id, "deviceName": dev_name, "deviceType": dev_type, "osVersion": "0.0.0", "appVersion": "0.0.0", "language": "EN"}
    headers={"Host": lng + "go.magio.tv", "User-Agent": UA}
    req = requests.post("https://" + lng + "go.magio.tv/v2/auth/init", params=params, headers=headers).json()
    accessToken = req["token"]["accessToken"]
    params = {"loginOrNickname": user, "password": password}
    headers = {"Content-type": "application/json", "authorization": "Bearer " + accessToken, "Host": lng + "go.magio.tv", "User-Agent": UA, "Connection": "Keep-Alive"}
    req = requests.post("https://" + lng + "go.magio.tv/v2/auth/login", json = params, headers = headers).json()
    if req["success"] == True:
        f = open(ft, "w")
        f.write(json.dumps(req))
        f.close()
        accesstoken = req["token"]["accessToken"]
        refreshtoken = req["token"]["refreshToken"]
        return refreshtoken, accesstoken
    else:
        xbmcgui.Dialog().notification("TV GO Playlist",req["errorMessage"], xbmcgui.NOTIFICATION_ERROR, 4000, sound = True)
        return None, None


def delete_device():
    refreshtoken, accesstoken = login()
    if refreshtoken == None:
        return
    f = open(ft, "r")
    data = json.load(f)
    expiresIn = data["token"]["expiresIn"]
    accesstoken = data["token"]["accessToken"]
    refreshtoken = data["token"]["refreshToken"]
    if expiresIn < int(time.time() * 1000):
        refreshtoken, accesstoken = login()
    params={"refreshToken": refreshtoken}
    headers = {"Content-type": "application/json", "Host": lng + "go.magio.tv", "User-Agent": UA, "Connection": "Keep-Alive"}
    req = requests.post("https://" + lng + "go.magio.tv/v2/auth/tokens", json = params, headers = headers).json()
    if req["success"] == True:
        accesstoken2 = req["token"]["accessToken"]
    else:
        xbmcgui.Dialog().notification("TV GO Playlist",req["errorMessage"], xbmcgui.NOTIFICATION_ERROR, 4000, sound = True)
        return
    headers = {"Content-type": "application/json", "authorization": "Bearer " + accesstoken2, "Host": lng + "go.magio.tv", "User-Agent": UA, "Connection": "Keep-Alive"}
    req = requests.get("https://" + lng + "go.magio.tv/v2/home/my-devices", headers = headers).json()
    devices = []
    try:
            devices.append((req["thisDevice"]["name"] + " (Toto zařízení)", req["thisDevice"]["id"]))
    except:
            pass
    try:
        for d in req["smallScreenDevices"]:
            devices.append((d["name"], d["id"]))
    except:
            pass
    try:
        for d in req["stbAndBigScreenDevices"]:
            devices.append((d["name"], d["id"]))
    except:
            pass
    choose = xbmcgui.Dialog().select("Odebrat zařízení", [i[0] for i in devices])

    if choose == -1: return
    else:
        dev_id = devices[choose][1]
    req = requests.get("https://" + lng + "go.magio.tv/home/deleteDevice?id=" + str(dev_id), headers = headers).json()
    if req["success"] == True:
        if choose == 0 and os.path.exists(ft):
            xbmcvfs.delete(ft)
        xbmcgui.Dialog().notification("TV GO Playlist","Odebráno", xbmcgui.NOTIFICATION_INFO, 4000, sound = False)
    else:
        xbmcgui.Dialog().notification("TV GO Playlist",req["errorMessage"], xbmcgui.NOTIFICATION_ERROR, 4000, sound = True)


def epg(dlg, token, channels, tm_ids, d, d_b):
    st = 1
    if dlg == True:
        dialog = xbmcgui.DialogProgressBG()
        dialog.create("TV GO EPG", "")
        dialog.update(0, "TV GO EPG", "Stahování dat...")
    programmes = []
    session = requests.Session()
    retry = Retry(connect=3, backoff_factor=0.5)
    adapter = HTTPAdapter(max_retries=retry)
    session.mount('http://', adapter)
    session.mount('https://', adapter)
    headers = {"Content-type": "application/json", "authorization": "Bearer " + token, "Host": lng + "go.magio.tv", "User-Agent": UA, "Connection": "Keep-Alive"}
    now = datetime.now()
    for i in range(d_b*-1, d):
        next_day = now + timedelta(days = i)
        back_day = (now + timedelta(days = i)) - timedelta(days = 1)
        date_to = next_day.strftime("%Y-%m-%d")
        date_from = back_day.strftime("%Y-%m-%d")
        date_ = next_day.strftime("%d.%m.%Y")
        per = int(int(d) + int(d_b))
        percent = int((float(st*100) / per))
        req = session.get("https://" + lng + "go.magio.tv/v2/television/epg?filter=channel.id=in=(" + str(tm_ids[1:]) + ");endTime=ge=" + date_from + "T23:00:00.000Z;startTime=le=" + date_to + "T23:59:59.999Z&limit=" + str(len(channels)) + "&offset=0&lang=" + lng.upper(), headers=headers).json()["items"]
        for x in range(0, len(req)):
            for y in req[x]["programs"]:
                id = y["channel"]["id"]
                name = y["channel"]["name"]
                channel = "tm-" + str(id) + "-" + encode(name).replace(" HD", "").lower().replace(" ", "-")
                start_time = y["startTime"].replace("-", "").replace("T", "").replace(":", "")
                stop_time = y["endTime"].replace("-", "").replace("T", "").replace(":", "")
                title = y["program"]["title"]
                desc = y["program"]["description"]
                year = y["program"]["programValue"]["creationYear"]
                try:
                    subgenre = y["program"]["programCategory"]["subCategories"][0]["desc"]
                except:
                    subgenre = ''
                try:
                    genre = [(y["program"]["programCategory"]["desc"], u''), (subgenre, u'')]
                except:
                    genre = None
                try:
                    icon = y["program"]["images"][0]
                except:
                    icon = None
                epi = y["program"]["programValue"]["episodeId"]
                if epi != None:
                    title = title + " (" + epi + ")"
                try:
                    programm = {'channel': str(channel), 'start': start_time + TimeShift, 'stop': stop_time + TimeShift, 'title': [(title, u'')],  'desc': [(desc, u'')]}
                    if year != None:
                        programm['date'] = year
                    if genre != None:
                        programm['category'] = genre
                    if icon != None:
                        programm['icon'] = [{"src": icon}]
                except:
                    pass
                if programm not in programmes:
                    programmes.append(programm)
        if dlg == True:
            dialog.update(percent, "TV GO EPG", date_)
        st += 1
    if dlg == True:
        dialog.update(0, "TV GO EPG","")
    session.close()
    w = xmltv.Writer(encoding="utf-8", source_info_url="http://www.funktronics.ca/python-xmltv", source_info_name="Funktronics", generator_info_name="python-xmltv", generator_info_url="http://www.funktronics.ca/python-xmltv")
    for c in channels:
        w.addChannel(c)
        stch = 1
    for p in programmes:
        w.addProgramme(p)
        per = len(programmes)
        percent = int((float(stch*100) / per))
        if dlg == True:
            dialog.update(percent, "Generuji...", p["channel"])
        stch += 1
    if dlg == True:
        dialog.update(0, "TV GO EPG", "Ukládání...")
    w.write(tfe, pretty_print=True)
    xbmcvfs.copy(tfe, fe)
    if dlg == True:
        dialog.close()
    xbmcgui.Dialog().notification("TV GO Playlist","EPG aktualizováno", sound = False, icon = addon_icon)


def groups(lng, ch):
    if lng == "cz":
        if ch in [4468,4469,6079,6108,15,6030,6017,4507,38,6027,6099,4052]:
            group = "Dětské"
        elif ch in [6038,4495,6046,6082,6085,4015,6055,6014,4135,6015,6060,4470,35,6019,6022,6008,6080,6076,4501,4502,4503]:
            group = "Dokumentární"
        elif ch in [6083,44,6009,6010,6018,6100,29,6048,6090,6091,4326,6039,6084,20,6020,6028,6029,6062,6012,6071,6072,4236,6065,4462,4463,6032,6064]:
            group = "Filmové"
        elif ch in [6034,4500,4499,4505,4506,6003,6057,6059,6058,6004,6093,6088,6078,6086,6043,4528,6118,6037,6007,6013,6063,4474,6001]:
            group = "Hudebni, Lifestyle"
        elif ch in [6104,6103,6113,6106,6107,6110,6114,6109,6111]:
            group = "Lokální"
        elif ch in [4492,6097,6021,6047,4491,6061,6098,6056,4487,6051]:
            group = "Pro dospělé"
        elif ch in [4099,4146,4460,4461,4516]:
            group = "Slovenské"
        elif ch in [6102,4504,6105,4446,6016,6040,4465,6033,6042,6073,6096,6050,6041,4466,6120,6121,6122,6123,5000]:
            group = "Sport"
        elif ch in [6066,4456,6054,6053,6116,4494,4453,4455,4454,4451,4452,4338,6031,4459,6092,6087,6119]:
            group = "Všeobecné"
        elif ch in [4478,6067,6068,6069,4475,6115,6070,6024,4130,4285,6081,6026,4486,4527,6011,4508,4482,4480,5,4477,4481,4320,4479,4525,4524,4526]:
            group = "Zprávy, zahraničí"
        else:
            group = "Ostatní"
    elif lng == "sk":
        if ch in [4234,4507,4014,4052,38,15,4513,4467,4092,6079,4100]:
            group = "Detské"
        elif ch in [4495,4502,4501,4503,4327,4135,4138,35,4026,4004,4264,4243,4015,4003,4042,4310,4178,4321]:
            group = "Dokumentárne"
        elif ch in [4236,4326,20,4098,44,120,121,29,4140,4324,4325,3603,4296,4297,4339,4340,4096,4027,4270,4280,4024,4224]:
            group = "Filmové"
        elif ch in [4332,4308,4499,4500,4505,4506,22,4261,4262,4263,23,4510,4312,4328,4330,4147]:
            group = "Hudobné"
        elif ch in [4035,118,4316,45,4272,17,4134,4001,4474]:
            group = "Lifestyle"
        elif ch in [4491,4268,6021,4259,4218,4322,4511,4232]:
            group = "Pre dospelých"
        elif ch in [4162,4517,4011,4142,4230,4143,4144,4298,4106,4504,4529,4465,4466,4125,4464,4446,4531,4535,4537,4533]:
            group = "Športové"
        elif ch in [4099,4146,4516,4044,4221,4111,4070,4222,4223,4240,4239,4522,4334,4530,4514,4456,4281,4338,4458,4278,4165,4470,4333,4329,4459,4523,11,4286,4292,4318,4287,4084,122,4508,4130,4478,4479,4480,4291,10,4481,4102,4101]:
            group = "Všeobecné"
        else:
            group = "Spravodajské"
    return group


def restart_pvr():
    try:
        time.sleep(1)
        addon_pvr = xbmcaddon.Addon('pvr.iptvsimple')
        xbmc.executeJSONRPC('{{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{{"addonid":"{}","enabled":false}}}}'.format('pvr.iptvsimple'))
        addon_pvr.setSetting('m3uPathType', '0')
        addon_pvr.setSetting('m3uPath', fs)
        addon_pvr.setSetting('epgPathType', '0')
        addon_pvr.setSetting('epgPath', fe)
        time.sleep(3)
        xbmc.executeJSONRPC('{{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{{"addonid":"{}","enabled":true}}}}'.format('pvr.iptvsimple'))
    except:
        xbmcgui.Dialog().notification("TV GO Playlist","Nelze nastavit/restartova PVR klienta", xbmcgui.NOTIFICATION_ERROR, 4000, sound = False)


def playlist(dlg, upd):
    if not os.path.exists(ft):
        refreshtoken, accesstoken = login()
        if refreshtoken == None:
            return
    f = open(ft, "r")
    data = json.load(f)
    expiresIn = data["token"]["expiresIn"]
    accesstoken = data["token"]["accessToken"]
    refreshtoken = data["token"]["refreshToken"]
    if expiresIn < int(time.time() * 1000) or dlg == False:
        refreshtoken, accesstoken = login()
    if dlg == True:
        dialog = xbmcgui.DialogProgressBG()
        dialog.create("TV GO Playlist", "")
    params={"refreshToken": refreshtoken}
    headers = {"Content-type": "application/json", "Host": lng + "go.magio.tv", "User-Agent": UA, "Connection": "Keep-Alive"}
    req = requests.post("https://" + lng + "go.magio.tv/v2/auth/tokens", json = params, headers = headers).json()
    if req["success"] == True:
        accesstoken2 = req["token"]["accessToken"]
    else:
        xbmcgui.Dialog().notification("TV GO Playlist",req["errorMessage"], xbmcgui.NOTIFICATION_ERROR, 4000, sound = True)
        if dlg == True:
            dialog.close()
        return
    session = requests.Session()
    retry = Retry(connect=3, backoff_factor=0.5)
    adapter = HTTPAdapter(max_retries=retry)
    session.mount('http://', adapter)
    session.mount('https://', adapter)
    params={"list": "LIVE", "queryScope": "LIVE"}
    headers = {"Content-type": "application/json", "authorization": "Bearer " + accesstoken2, "Host": lng + "go.magio.tv", "User-Agent": UA, "Connection": "Keep-Alive"}
    req = session.get("https://" + lng + "go.magio.tv/v2/television/channels", params = params, headers = headers).json()
    channels = []
    channels2 = []
    ids = ""
    for n in req["items"]:
        name = n["channel"]["name"]
        logo = str(n["channel"]["logoUrl"])
        idd = n["channel"]["channelId"]
        ids = ids + "," + str(idd)
        if idd == 5000:
            idd = 6016
            name = "Eurosport 1"
        id = "tm-" + str(idd) + "-" + encode(name).replace(" HD", "").lower().replace(" ", "-")
        channels2.append(({"display-name": [(name, u"cs")], "id": str(id), "icon": [{"src": logo}]}))
        channels.append((name, idd, logo))
    if os.path.exists(fcho):
        ff = open(fcho).read()
        order = json.loads(ff)
    else:
        order = None
    f = open(tfs, "w", encoding="utf-8")
    f.write("#EXTM3U\n")
    per = len(channels)
    stch = 1
    oo = {}
    for ch in channels:
        percent = int((float(stch*100) / per))
        if addon.getSetting("playlist_vlc") == "true":
            params={"service": service_type[addon.getSetting("service")], "name": dev_name, "devtype": dev_type, "id": ch[1], "prof": qu, "ecid": "", "drm": "verimatrix"}
            headers = {"Content-type": "application/json", "authorization": "Bearer " + accesstoken2, "Host": lng + "go.magio.tv", "User-Agent": UA, "Connection": "Keep-Alive"}
            req = session.get("https://" + lng + "go.magio.tv/v2/television/stream-url", params = params, headers = headers)
            if req.json()["success"] == True:
                url = req.json()["url"]
            else:
                if req.json()["success"] == False and req.json()["errorCode"] == "NO_PACKAGE":
                    url = None
                else:
                    xbmcgui.Dialog().notification("TV GO Playlist",req.json()["errorMessage"], xbmcgui.NOTIFICATION_ERROR, 4000, sound = True)
                    if dlg == True:
                        dialog.close()
                    if "DEVICE_MAX_LIMIT" in str(req.json()):
                        delete_device()
                    return
            id = "tm-" + str(ch[1]) + "-" + encode(ch[0]).replace(" HD", "").lower().replace(" ", "-")
            if ch[1] == 5000:
                id = "tm-6016-eurosport-1"
            group = groups(lng, ch[1])
            if lng == "sk":
                if url is not None:
                    headers = {"Host": urlparse(url).netloc, "User-Agent": "ReactNativeVideo/3.13.2 (Linux;Android 10) ExoPlayerLib/2.10.3", "Connection": "Keep-Alive"}
                    req = session.get(url, headers = headers, allow_redirects=False)
                    url = str(req.headers["location"])
        else:
            id = "tm-" + str(ch[1]) + "-" + encode(ch[0]).replace(" HD", "").lower().replace(" ", "-")
            if ch[1] == 5000:
                id = "tm-6016-eurosport-1"
            group = groups(lng, ch[1])
            url = "plugin://script.tvgo.playlist/play/" + str(ch[1])
        catchup = ' catchup-days="7" catchup-source="plugin://script.tvgo.playlist/catchup/' + str(ch[1]) + '/${start}-${end}"'
        if addon.getSetting("input_stream") == "true" and addon.getSetting("playlist_vlc") == "true" and url is not None:
            if ".m3u8" in url:
                inputstrem = "#KODIPROP:inputstreamaddon=inputstream.adaptive\n#KODIPROP:inputstream.adaptive.manifest_type=hls\n#KODIPROP:mimetype=application/vnd.apple.mpegurl\n"
            else:
                inputstrem = "#KODIPROP:inputstreamaddon=inputstream.adaptive\n#KODIPROP:inputstream.adaptive.manifest_type=mpd\n#KODIPROP:mimetype=application/dash+xml\n"
        else:
            inputstrem = ""
        if url is not None:
            if order is not None:
                try:
                    for key, value in order.items():
                        if value[0] == str(ch[0]):
                            ord = str(int(key) + 1)
                except:
                    ord = str(int(stch) + 1000)
            else:
                ord = str(int(stch) + 1)
            f.write('#EXTINF:-1 tvg-chno="' + str(ord) + '" group-title="' + group + '" tvg-id="' + id +  '"' + catchup + ' tvg-logo="' + ch[2] + '" tvg-name="' + str(ch[0]) + '"' + ',' +str(ch[0]) + '\n' + inputstrem + url + '\n')
#{"0": ["c", "", "", "item", "-"], "1": ["b", "", "", "item", "-"], "2": ["a", "", "", "item", "-"]}
            oo[stch - 1] = [str(ch[0]), ch[2], "", "item", "-"]
        if dlg == True:
            dialog.update(percent, "TV GO Playlist", ch[0])
        stch += 1
    f.close()
    session.close()
    if not os.path.exists(fcho):
        ord = json.dumps(oo)
        ff = open(fcho, "w")
        ff.write(ord)
        ff.close()
    if dlg == True:
        dialog.close()
        xbmcvfs.copy(tfs, fs)
        xbmcgui.Dialog().notification("TV GO Playlist","Playlist aktualizován", sound = False, icon = addon_icon)
    else:
        if addon.getSetting("playlist_vlc") == "true":
            xbmcvfs.copy(tfs, fs)
            xbmcgui.Dialog().notification("TV GO Playlist","Playlist aktualizován", sound = False, icon = addon_icon)
    if upd == True:
        epg(dlg, accesstoken2, channels2, ids, int(addon.getSetting("num_days")), int(addon.getSetting("num_days_back")))
    if addon.getSetting("restart_pvr") == "true":
        if xbmc.getCondVisibility('System.AddonIsEnabled(pvr.iptvsimple)') == False:
            xbmc.executeJSONRPC('{{"jsonrpc":"2.0","id":1,"method":"Addons.SetAddonEnabled","params":{{"addonid":"{}","enabled":true}}}}'.format('pvr.iptvsimple'))
        restart_pvr()


def catchup(ch_id, t):
    timestamp = t.split("-")
    date_time_start = datetime.fromtimestamp(int(timestamp[0]))
    d_start = date_time_start.strftime("%Y-%m-%dT%H:%M:%S")
    date_time_end = datetime.fromtimestamp(int(timestamp[1]))
    d_end = date_time_end.strftime("%Y-%m-%dT%H:%M:%S")
    if not os.path.exists(ft):
        login()
    f = open(ft, "r")
    data = json.load(f)
    expiresIn = data["token"]["expiresIn"]
    accesstoken = data["token"]["accessToken"]
    refreshtoken = data["token"]["refreshToken"]
    if expiresIn < int(time.time() * 1000):
        refreshtoken, accesstoken = login()
    params={"refreshToken": refreshtoken}
    headers = {"Content-type": "application/json", "authorization": "Bearer " + accesstoken, "Host": lng + "go.magio.tv", "User-Agent": UA, "Connection": "Keep-Alive"}
    req = requests.post("https://" + lng + "go.magio.tv/v2/auth/tokens", json = params, headers = headers).json()
    if req["success"] == True:
        accesstoken2 = req["token"]["accessToken"]
    else:
        xbmcgui.Dialog().notification("TV GO Playlist",req["errorMessage"], xbmcgui.NOTIFICATION_ERROR, 4000, sound = True)
        return
    now = datetime.now()
    current_time = now.strftime("%Y-%m-%dT%H:%M:%S")
    date_time_end = date_time_end + timedelta(seconds=15)
    d_end = date_time_end.strftime("%Y-%m-%dT%H:%M:%S")
    headers = {"Content-type": "application/json", "authorization": "Bearer " + accesstoken2, "Host": lng + "go.magio.tv", "User-Agent": UA, "Connection": "Keep-Alive"}
    req = requests.get("https://" + lng + "go.magio.tv/v2/television/epg?filter=channel.id==" + ch_id + "%20and%20startTime=ge=" + d_start + ".000Z%20and%20endTime=le=" + d_end + ".000Z&limit=10&offset=0&lang=" + lng.upper(),headers = headers).json()
    if req["success"] == False:
        xbmcgui.Dialog().notification("TV GO Playlist",req["errorMessage"], xbmcgui.NOTIFICATION_ERROR, 4000, sound = True)
        return        
    else:
        if req["items"] != []:
            scheduleId = str(req["items"][0]["programs"][0]["scheduleId"])
            params={"service": "ARCHIVE", "name": dev_name, "devtype": dev_type, "id": scheduleId, "prof": qu, "ecid": "", "drm": "verimatrix"}
            headers = {"Content-type": "application/json", "authorization": "Bearer " + accesstoken2, "Host": lng + "go.magio.tv", "User-Agent": UA, "Connection": "Keep-Alive"}
            req = requests.get("https://" + lng + "go.magio.tv/v2/television/stream-url", params = params, headers = headers).json()
            if req["success"] == True:
                stream = req["url"]
            else:
                xbmcgui.Dialog().notification("TV GO Playlist",req["errorMessage"], xbmcgui.NOTIFICATION_ERROR, 4000, sound = True)
                return
        else:
            params={"service": "TIMESHIFT", "name": dev_name, "devtype": dev_type, "id": ch_id, "prof": qu, "ecid": "", "drm": "verimatrix"}
            headers = {"Content-type": "application/json", "authorization": "Bearer " + accesstoken2, "Host": lng + "go.magio.tv", "User-Agent": UA, "Connection": "Keep-Alive"}
            req = requests.get("https://" + lng + "go.magio.tv/v2/television/stream-url", params = params, headers = headers).json()
            if req["success"] == True:
                url = req["url"]
            else:
                xbmcgui.Dialog().notification("TV GO Playlist",req["errorMessage"], xbmcgui.NOTIFICATION_ERROR, 4000, sound = True)
                return
            headers = {"Host": urlparse(url).netloc, "User-Agent": "ReactNativeVideo/3.13.2 (Linux;Android 10) ExoPlayerLib/2.10.3", "Connection": "Keep-Alive"}
            req = requests.get(url, headers = headers, allow_redirects=False)
            stream = req.headers["location"]
    listitem = xbmcgui.ListItem(path=stream)
    listitem.setContentLookup(False)
    if ".mpd" in stream:
        listitem.setMimeType('application/xml+dash')
        listitem.setProperty('inputstream', 'inputstream.adaptive')
        listitem.setProperty('inputstream.adaptive.manifest_type', 'mpd')
    _handle = int(sys.argv[1]) if len(sys.argv) > 1 else -1
    xbmcplugin.setResolvedUrl(_handle, True, listitem)


def play_vlc():
    name = xbmc.getInfoLabel('Listitem.ChannelName')
    ind = None
    f = open (fs, encoding='utf-8').read().splitlines()
    for x in f:
        if name in x:
            if addon.getSetting("input_stream") == "true":
                ind = f.index(x) + 3
            else:
                ind = f.index(x) + 1
    if ind is not None:
        stream = f[ind]
    else:
        return
    if addon.getSetting("vlc") == "0":
        url = stream
    else:
        url = fs
#    app = 'org.videolan.vlc'
    app = ''
    intent   = 'android.intent.action.VIEW'
    dataType = 'video/*'
    cmd = 'StartAndroidActivity("%s", "%s", "%s", "%s")' % (app, intent, dataType, url)
    xbmc.executebuiltin(cmd)


def play(ch_id):
    if not os.path.exists(ft):
        refreshtoken, accesstoken = login()
        if refreshtoken == None:
            return
    f = open(ft, "r")
    data = json.load(f)
    expiresIn = data["token"]["expiresIn"]
    accesstoken = data["token"]["accessToken"]
    refreshtoken = data["token"]["refreshToken"]
    if expiresIn < int(time.time() * 1000):
        refreshtoken, accesstoken = login()
    params={"refreshToken": refreshtoken}
    headers = {"Content-type": "application/json", "authorization": "Bearer " + accesstoken, "Host": lng + "go.magio.tv", "User-Agent": UA, "Connection": "Keep-Alive"}
    req = requests.post("https://" + lng + "go.magio.tv/v2/auth/tokens", json = params, headers = headers).json()
    if req["success"] == True:
        accesstoken2 = req["token"]["accessToken"]
    else:
        xbmcgui.Dialog().notification("TV GO Playlist",req["errorMessage"], xbmcgui.NOTIFICATION_ERROR, 4000, sound = True)
        return
    params={"service": service_type[addon.getSetting("service")], "name": dev_name, "devtype": dev_type, "id": ch_id, "prof": qu, "ecid": "", "drm": "verimatrix"}
    headers = {"Content-type": "application/json", "authorization": "Bearer " + accesstoken2, "Host": lng + "go.magio.tv", "User-Agent": UA, "Connection": "Keep-Alive"}
    req = requests.get("https://" + lng + "go.magio.tv/v2/television/stream-url", params = params, headers = headers)
    if req.json()["success"] == True:
        url = req.json()["url"]
    else:
        xbmcgui.Dialog().notification("TV GO Playlist",req.json()["errorMessage"], xbmcgui.NOTIFICATION_ERROR, 4000, sound = True)
        if "DEVICE_MAX_LIMIT" in str(req.json()):
            time.sleep(2)
            delete_device()
        return
    headers = {"Host": urlparse(url).netloc, "User-Agent": "ReactNativeVideo/3.13.2 (Linux;Android 10) ExoPlayerLib/2.10.3", "Connection": "Keep-Alive"}
    req = requests.get(url, headers = headers, allow_redirects=False)
    stream = req.headers["location"]
    listitem = xbmcgui.ListItem(path=stream)
    listitem.setContentLookup(False)
    if ".m3u8" in stream:
        listitem.setMimeType('application/vnd.apple.mpegurl')
        if addon.getSetting("input_stream") == "true":
            listitem.setProperty('inputstream', 'inputstream.adaptive')
            listitem.setProperty('inputstream.adaptive.manifest_type', 'hls')
    else:
        listitem.setMimeType('application/xml+dash')
        if addon.getSetting("input_stream") == "true" or lng == "sk":
            listitem.setProperty('inputstream', 'inputstream.adaptive')
            listitem.setProperty('inputstream.adaptive.manifest_type', 'mpd')
    _handle = int(sys.argv[1]) if len(sys.argv) > 1 else -1
    xbmcplugin.setResolvedUrl(_handle, True, listitem)


def get_real_url(u):
    playlist = m3u8.load(uri=u)
    return playlist.playlists[-1].absolute_uri


def record(ch_id, t, file_name):
    if addon.getSetting("record_folder") == "":
        xbmcgui.Dialog().notification("TV GO Playlist", "Nastavte složku pro stahování", xbmcgui.NOTIFICATION_ERROR, 4000, sound = True)
        return
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    if not os.path.exists(ft):
        refreshtoken, accesstoken = login()
        if refreshtoken == None:
            return
    f = open(ft, "r")
    data = json.load(f)
    expiresIn = data["token"]["expiresIn"]
    accesstoken = data["token"]["accessToken"]
    refreshtoken = data["token"]["refreshToken"]
    if expiresIn < int(time.time() * 1000):
        refreshtoken, accesstoken = login()
    params={"refreshToken": refreshtoken}
    headers = {"Content-type": "application/json", "Host": lng + "go.magio.tv", "User-Agent": UA, "Connection": "Keep-Alive"}
    req = requests.post("https://" + lng + "go.magio.tv/v2/auth/tokens", json = params, headers = headers).json()
    if req["success"] == True:
        accesstoken2 = req["token"]["accessToken"]
    else:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        xbmcgui.Dialog().notification("TV GO Playlist",req["errorMessage"], xbmcgui.NOTIFICATION_ERROR, 4000, sound = True)
        return
    params={"list": "LIVE", "queryScope": "LIVE"}
    headers = {"Content-type": "application/json", "authorization": "Bearer " + accesstoken2, "Host": lng + "go.magio.tv", "User-Agent": UA, "Connection": "Keep-Alive"}
    req = requests.get("https://" + lng + "go.magio.tv/v2/television/channels", params = params, headers = headers).json()
    channel = {}
    for n in req["items"]:
        channel[n["channel"]["name"]] = n["channel"]["channelId"]
    ch_id = str(channel[ch_id])
    timestamp = t.split("-")
    date_time_start = datetime.fromtimestamp(int(timestamp[0]))
    d_start = date_time_start.strftime("%Y-%m-%dT%H:%M:%S")
    date_time_end = datetime.fromtimestamp(int(timestamp[1]))
    d_end = date_time_end.strftime("%Y-%m-%dT%H:%M:%S")
    now = datetime.now()
    current_time = now.strftime("%Y-%m-%dT%H:%M:%S")
    date_time_end = date_time_end + timedelta(seconds=15)
    d_end = date_time_end.strftime("%Y-%m-%dT%H:%M:%S")
    headers = {"Content-type": "application/json", "authorization": "Bearer " + accesstoken2, "Host": lng + "go.magio.tv", "User-Agent": UA, "Connection": "Keep-Alive"}
    req = requests.get("https://" + lng + "go.magio.tv/v2/television/epg?filter=channel.id==" + ch_id + "%20and%20startTime=ge=" + d_start + ".000Z%20and%20endTime=le=" + d_end + ".000Z&limit=10&offset=0&lang=" + lng.upper(),headers = headers).json()
    if req["success"] == False:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
        xbmcgui.Dialog().notification("TV GO Playlist",req["errorMessage"], xbmcgui.NOTIFICATION_ERROR, 4000, sound = True)
        return        
    else:
        if req["items"] != []:
            scheduleId = str(req["items"][0]["programs"][0]["scheduleId"])
            params={"service": "ARCHIVE", "name": dev_name, "devtype": dev_type, "id": scheduleId, "prof": qu, "ecid": "", "drm": "verimatrix"}
            headers = {"Content-type": "application/json", "authorization": "Bearer " + accesstoken2, "Host": lng + "go.magio.tv", "User-Agent": UA, "Connection": "Keep-Alive"}
            req = requests.get("https://" + lng + "go.magio.tv/v2/television/stream-url", params = params, headers = headers).json()
            if req["success"] == True:
                stream = req["url"]
            else:
                xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
                xbmcgui.Dialog().notification("TV GO Playlist",req["errorMessage"], xbmcgui.NOTIFICATION_ERROR, 4000, sound = True)
                return
        else:
            params={"service": "TIMESHIFT", "name": dev_name, "devtype": dev_type, "id": ch_id, "prof": qu, "ecid": "", "drm": "verimatrix"}
            headers = {"Content-type": "application/json", "authorization": "Bearer " + accesstoken2, "Host": lng + "go.magio.tv", "User-Agent": UA, "Connection": "Keep-Alive"}
            req = requests.get("https://" + lng + "go.magio.tv/v2/television/stream-url", params = params, headers = headers).json()
            if req["success"] == True:
                url = req["url"]
            else:
                xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
                xbmcgui.Dialog().notification("TV GO Playlist",req["errorMessage"], xbmcgui.NOTIFICATION_ERROR, 4000, sound = True)
                return
            headers = {"Host": urlparse(url).netloc, "User-Agent": "ReactNativeVideo/3.13.2 (Linux;Android 10) ExoPlayerLib/2.10.3", "Connection": "Keep-Alive"}
            req = requests.get(url, headers = headers, allow_redirects=False)
            stream = req.headers["location"]
    xbmc.executebuiltin('Dialog.Close(busydialognocancel)')
    if ".m3u8" in stream:
        real_url = get_real_url(stream)
        playlist = m3u8.load(uri=real_url)
        dialog = xbmcgui.DialogProgressBG()
        dialog.create("TV GO Playlist", "")
        n = len(playlist.segments)
        size = 0
        stch = 1
        start = time.time()
        fs = os.path.join(addon.getSetting("record_folder"), file_name + ".ts")
        f = xbmcvfs.File(fs, 'w')
        for i, seg in enumerate(playlist.segments, 1):
            percent = int((float(stch*100) / n))
            r = requests.get(seg.absolute_uri)
            data = r.content
            size += len(data)
            stch += 1
            f.write(data)
            dialog.update(percent, "TV GO Playlist", file_name)
        dialog.close()
        f.close()
        xbmcgui.Dialog().notification("TV GO Playlist", "Staženo", xbmcgui.NOTIFICATION_INFO, 4000, sound = True)
    else:
        xbmcgui.Dialog().notification("TV GO Playlist", "Tento stream nelze stáhnout", xbmcgui.NOTIFICATION_ERROR, 4000, sound = True)