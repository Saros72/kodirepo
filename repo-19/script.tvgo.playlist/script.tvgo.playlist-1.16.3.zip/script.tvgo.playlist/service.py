# -*- coding: utf-8 -*-

import xbmcaddon, sys, xbmc, os
from resources.lib import schedule
from resources.lib import tvgo
import xbmcvfs


addon = xbmcaddon.Addon(id='script.tvgo.playlist')
profile = xbmcvfs.translatePath(addon.getAddonInfo('profile')).encode().decode("utf-8")
if addon.getSetting("provider") == "0":
    lng = "cz"
else:
    lng = "sk"
ft = os.path.join(profile,"token_" + lng + ".json")
monitor = xbmc.Monitor()


def start():
    if os.path.exists(ft):
        tvgo.playlist(False, True)


schedule.every(int(addon.getSetting("interval_update"))).hours.do(start)


def update():
    if addon.getSetting("start_update") == "true":
        start()
    while not monitor.abortRequested():
        monitor.waitForAbort(1)
        schedule.run_pending()


if __name__ == '__main__':
    update()