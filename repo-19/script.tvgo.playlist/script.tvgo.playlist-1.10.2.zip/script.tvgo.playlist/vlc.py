from resources.lib import tvgo

tvgo.play_vlc()
